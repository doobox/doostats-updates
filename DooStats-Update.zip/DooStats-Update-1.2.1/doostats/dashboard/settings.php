<?php

declare(strict_types=1);

require_once __DIR__ . '/_layout.php';
require_once __DIR__ . '/../lib/config-write.php';
require_once __DIR__ . '/../lib/brand-palette.php';
require_once __DIR__ . '/../lib/update-check.php';
require_once __DIR__ . '/../lib/digest.php';

/**
 * Store an uploaded image as a small square avatar. When GD is available the
 * image is centre-cropped and downscaled to at most $size px (so the served
 * file stays a few KB, whatever the source); otherwise the original bytes are
 * stored as-is. Returns the saved basename, or null on failure.
 */
function doostats_store_avatar(string $tmpPath, string $ext, string $destDir, int $size = 256): ?string
{
    $name = 'avatar-' . bin2hex(random_bytes(6)) . '.' . $ext;
    $dest = rtrim($destDir, '/\\') . '/' . $name;

    $loaders = [
        'png' => 'imagecreatefrompng',
        'jpg' => 'imagecreatefromjpeg',
        'gif' => 'imagecreatefromgif',
        'webp' => 'imagecreatefromwebp',
    ];

    if (function_exists('imagecreatetruecolor') && isset($loaders[$ext]) && function_exists($loaders[$ext])) {
        $src = @($loaders[$ext])($tmpPath);
        if ($src !== false) {
            $sw = imagesx($src);
            $sh = imagesy($src);
            $side = min($sw, $sh);
            $sx = (int) (($sw - $side) / 2);
            $sy = (int) (($sh - $side) / 2);
            $out = min($size, $side); // never upscale
            $dst = imagecreatetruecolor($out, $out);
            imagealphablending($dst, false);
            imagesavealpha($dst, true);
            imagecopyresampled($dst, $src, 0, 0, $sx, $sy, $out, $out, $side, $side);

            $ok = match ($ext) {
                'png' => imagepng($dst, $dest, 6),
                'jpg' => imagejpeg($dst, $dest, 82),
                'gif' => imagegif($dst, $dest),
                'webp' => imagewebp($dst, $dest, 82),
                default => false,
            };
            imagedestroy($src);
            imagedestroy($dst);

            if ($ok) {
                @chmod($dest, 0644);
                return $name;
            }
        }
    }

    // No GD (or decode failed): keep the original upload within the size cap.
    if (@move_uploaded_file($tmpPath, $dest)) {
        @chmod($dest, 0644);
        return $name;
    }
    return null;
}

$ctx = dashboard_guard();
$cfg = $ctx['cfg'];

$errors = [];
$notice = '';
$reportsErrors = [];
$reportsNotice = '';
$updateResult = null;
$availableLanguages = i18n_available_languages();

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $form = (string) ($_POST['form'] ?? '');

    if (!auth_check_csrf($_POST['csrf'] ?? null)) {
        $errors[] = t('settings.error.csrf');
    } elseif ($form === 'update_check') {
        // Result is shown in the Updates card (not the top flash) so it stays next to the button.
        $updateResult = doostats_public_update_result(doostats_check_for_updates());
    } elseif ($form === 'general') {
        $siteName = trim((string) ($_POST['site_name'] ?? ''));
        $siteUrl = trim((string) ($_POST['site_url'] ?? ''));
        $installPath = doostats_normalize_install_path((string) ($_POST['install_path'] ?? ''));
        $brand = trim((string) ($_POST['brand_hex'] ?? ''));
        $timezone = trim((string) ($_POST['timezone'] ?? 'UTC'));
        if (count($availableLanguages) === 1) {
            $uiLanguage = (string) array_key_first($availableLanguages);
        } else {
            $uiLanguage = strtolower(trim((string) ($_POST['ui_language'] ?? 'en')));
        }
        $retention = (int) ($_POST['retention_days'] ?? 45);
        $dashboardRefresh = (int) ($_POST['dashboard_refresh_seconds'] ?? 0);
        $uiTheme = strtolower(trim((string) ($_POST['ui_theme'] ?? doostats_ui_theme_default())));

        if ($siteName === '') {
            $errors[] = t('settings.error.site_name_required');
        }
        if ($siteUrl === '' || !filter_var($siteUrl, FILTER_VALIDATE_URL)) {
            $errors[] = t('settings.error.site_url_required');
        }
        if (!preg_match('/^#[0-9a-fA-F]{6}$/', $brand)) {
            $errors[] = t('settings.error.brand_hex');
        }
        if (!in_array($timezone, timezone_identifiers_list(), true)) {
            $errors[] = t('settings.error.timezone');
        }
        if (!isset($availableLanguages[$uiLanguage])) {
            $errors[] = t('settings.error.language');
        }
        if (!in_array($uiTheme, doostats_ui_theme_values(), true)) {
            $errors[] = t('settings.error.theme');
        }
        if ($retention < 1 || $retention > 90) {
            $errors[] = t('settings.error.retention');
        }
        if (!in_array($dashboardRefresh, [0, 30, 60, 300, 600, 1200], true)) {
            $errors[] = t('settings.error.refresh');
        }

        if ($errors === []) {
            $new = $cfg;
            $new['site_name'] = $siteName;
            $new['site_url'] = $siteUrl;
            $new['install_path'] = $installPath;
            $new['brand_hex'] = strtolower($brand);
            $new['timezone'] = $timezone;
            $new['ui_language'] = $uiLanguage;
            $new['ui_theme'] = $uiTheme;
            $new['retention_days'] = $retention;
            $new['dashboard_refresh_seconds'] = $dashboardRefresh;

            if (doostats_write_config($new)) {
                $cfg = $new;
                $ctx['brand'] = (string) $new['brand_hex'];
                $ctx['site_name'] = (string) $new['site_name'];
                i18n_reset();
                $GLOBALS['__doostats_i18n_lang'] = $uiLanguage;
                $notice = t('settings.notice.saved');
            } else {
                $errors[] = t('settings.error.config_write');
            }
        }
    } elseif ($form === 'advanced') {
        $ignoreLocalhost = !empty($_POST['ignore_localhost']);
        $filterBots = !empty($_POST['filter_bots']);
        $trustProxy = !empty($_POST['trust_proxy']);
        $processVisitorIp = !empty($_POST['process_visitor_ip']);
        $ignoreIps = array_values(array_filter(
            array_map('trim', preg_split('/[\r\n,]+/', (string) ($_POST['ignore_ips'] ?? '')) ?: []),
            static fn (string $v): bool => $v !== ''
        ));

        $splitLines = static fn (string $raw): array => array_values(array_filter(
            array_map('trim', preg_split('/[\r\n,]+/', $raw) ?: []),
            static fn (string $v): bool => $v !== ''
        ));
        $referrerBlock = array_values(array_filter(
            array_map(static fn (string $h): string => analytics_normalize_host($h), $splitLines((string) ($_POST['referrer_blocklist'] ?? ''))),
            static fn (string $v): bool => $v !== ''
        ));
        $excludedPaths = array_values(array_filter(
            array_map(static function (string $p): string {
                $p = trim($p);
                return ($p === '' || $p[0] === '/') ? $p : '/' . $p;
            }, $splitLines((string) ($_POST['excluded_paths'] ?? ''))),
            static fn (string $v): bool => $v !== ''
        ));

        foreach ($ignoreIps as $ip) {
            if (!filter_var($ip, FILTER_VALIDATE_IP)) {
                $errors[] = t('settings.error.invalid_ip', ['ip' => $ip]);
            }
        }

        if ($errors === []) {
            $new = $cfg;
            $new['ignore_localhost'] = $ignoreLocalhost;
            $new['ignore_ips'] = $ignoreIps;
            $new['filter_bots'] = $filterBots;
            $new['trust_proxy'] = $trustProxy;
            $new['process_visitor_ip'] = $processVisitorIp;
            unset($new['country_detection']);
            $new['excluded_paths'] = $excludedPaths;
            $new['referrer_blocklist'] = $referrerBlock;

            if (doostats_write_config($new)) {
                $notice = t('settings.notice.advanced_saved');
                $cfg = $new;
            } else {
                $errors[] = t('settings.error.config_write');
            }
        }
    } elseif ($form === 'password') {
        $current = (string) ($_POST['current_password'] ?? '');
        $pass = (string) ($_POST['new_password'] ?? '');
        $pass2 = (string) ($_POST['new_password2'] ?? '');

        if (!auth_verify_password($current)) {
            $errors[] = t('settings.error.current_password');
        }
        if (strlen($pass) < 8) {
            $errors[] = t('settings.error.new_password_len');
        }
        if ($pass !== $pass2) {
            $errors[] = t('settings.error.passwords_mismatch');
        }

        if ($errors === []) {
            $new = $cfg;
            $new['admin_password_hash'] = password_hash($pass, PASSWORD_DEFAULT);
            if (doostats_write_config($new)) {
                $notice = t('settings.notice.password_updated');
                $cfg = $new;
            } else {
                $errors[] = t('settings.error.config_write');
            }
        }
    } elseif ($form === 'profile') {
        $userName = trim((string) ($_POST['user_name'] ?? ''));
        $userName = mb_substr($userName, 0, 20);
        if ($userName === '') {
            $userName = 'Admin';
        }
        $dataDir = rtrim((string) ($cfg['data_dir'] ?? dirname(__DIR__) . '/data'), '/\\');

        $new = $cfg;
        $new['user_name'] = $userName;

        // The avatar is optional: only validate/store a file when one was sent.
        $upload = $_FILES['avatar'] ?? null;
        $hasUpload = is_array($upload) && (int) ($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;
        $movedDest = null;

        if ($hasUpload) {
            if ((int) $upload['error'] !== UPLOAD_ERR_OK) {
                $errors[] = t('settings.error.upload_failed');
            } elseif ((int) ($upload['size'] ?? 0) > 1024 * 1024) {
                $errors[] = t('settings.error.image_too_large');
            } elseif (!is_uploaded_file((string) $upload['tmp_name'])) {
                $errors[] = t('settings.error.invalid_upload');
            } else {
                $info = @getimagesize((string) $upload['tmp_name']);
                $mime = is_array($info) ? (string) ($info['mime'] ?? '') : '';
                $extByMime = ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/gif' => 'gif', 'image/webp' => 'webp'];
                if (!isset($extByMime[$mime])) {
                    $errors[] = t('settings.error.unsupported_image');
                } elseif ((int) ($info[0] ?? 0) > 6000 || (int) ($info[1] ?? 0) > 6000) {
                    $errors[] = t('settings.error.image_dimensions');
                } else {
                    $stored = doostats_store_avatar((string) $upload['tmp_name'], $extByMime[$mime], $dataDir);
                    if ($stored !== null) {
                        $movedDest = $dataDir . '/' . $stored;
                        $new['avatar'] = $stored;
                    } else {
                        $errors[] = t('settings.error.store_image');
                    }
                }
            }
        }

        if ($errors === []) {
            if (doostats_write_config($new)) {
                if ($movedDest !== null) {
                    $old = basename((string) ($cfg['avatar'] ?? ''));
                    if ($old !== '' && $old !== basename($movedDest) && is_file($dataDir . '/' . $old)) {
                        @unlink($dataDir . '/' . $old);
                    }
                }
                $notice = t('settings.notice.profile_saved');
                $cfg = $new;
                $ctx['user_name'] = (string) $new['user_name'];
            } else {
                if ($movedDest !== null) {
                    @unlink($movedDest);
                }
                $errors[] = t('settings.error.config_write');
            }
        } elseif ($movedDest !== null) {
            @unlink($movedDest);
        }
    } elseif ($form === 'avatar_remove') {
        $dataDir = rtrim((string) ($cfg['data_dir'] ?? dirname(__DIR__) . '/data'), '/\\');
        $old = basename((string) ($cfg['avatar'] ?? ''));
        if ($old !== '' && is_file($dataDir . '/' . $old)) {
            @unlink($dataDir . '/' . $old);
        }
        $new = $cfg;
        $new['avatar'] = '';
        if (doostats_write_config($new)) {
            $notice = t('settings.notice.avatar_removed');
            $cfg = $new;
        } else {
            $errors[] = t('settings.error.config_update');
        }
    } elseif ($form === 'reset_stats') {
        $password = (string) ($_POST['confirm_password'] ?? '');
        if ($password === '') {
            $errors[] = t('settings.error.reset_password_required');
        } elseif (!auth_verify_password($password)) {
            $errors[] = t('settings.error.reset_password_wrong');
        } elseif (!analytics_reset_stats()) {
            $errors[] = t('settings.error.reset_failed');
        } else {
            $notice = t('settings.notice.stats_reset');
        }
    } elseif ($form === 'reports') {
        $digestEnabled = !empty($_POST['digest_enabled']);
        $digestEmail = trim((string) ($_POST['digest_email'] ?? ''));

        if ($digestEnabled && ($digestEmail === '' || !filter_var($digestEmail, FILTER_VALIDATE_EMAIL))) {
            $reportsErrors[] = t('settings.reports.error.email');
        } elseif ($digestEmail !== '' && !filter_var($digestEmail, FILTER_VALIDATE_EMAIL)) {
            $reportsErrors[] = t('settings.reports.error.email');
        }

        if ($reportsErrors === []) {
            $new = $cfg;
            $new['digest_enabled'] = $digestEnabled;
            $new['digest_email'] = $digestEmail;
            if (doostats_write_config($new)) {
                $cfg = $new;
                $reportsNotice = t('settings.reports.notice.saved');
            } else {
                $reportsErrors[] = t('settings.error.config_write');
            }
        }
    }
}

$esc = static fn ($v): string => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$selectedTz = (string) ($cfg['timezone'] ?? 'UTC');
$selectedLang = (string) ($cfg['ui_language'] ?? 'en');
if (!isset($availableLanguages[$selectedLang])) {
    $selectedLang = 'en';
}
$ignoreIpsText = implode("\n", (array) ($cfg['ignore_ips'] ?? []));
$excludedPathsText = implode("\n", (array) ($cfg['excluded_paths'] ?? []));
$referrerBlockText = implode("\n", (array) ($cfg['referrer_blocklist'] ?? []));
$filterBots = !array_key_exists('filter_bots', $cfg) || !empty($cfg['filter_bots']);
$processVisitorIp = analytics_process_visitor_ip();
$csrf = auth_csrf_token();

// Resolve the avatar from the (possibly just-updated) local config, so both the
// preview and the top-bar reflect a fresh upload/removal within this request.
$avatarFile = null;
$avatarName = basename((string) ($cfg['avatar'] ?? ''));
if ($avatarName !== '') {
    $avatarDir = rtrim((string) ($cfg['data_dir'] ?? dirname(__DIR__) . '/data'), '/\\');
    if (is_file($avatarDir . '/' . $avatarName)) {
        $avatarFile = $avatarDir . '/' . $avatarName;
    }
}

$installed = doostats_installed_version();
$builtAt = doostats_format_built_at($installed['built']);
$updatesIntro = $builtAt !== ''
    ? t('settings.updates.installed_built', ['version' => $installed['version'], 'built' => $builtAt])
    : t('settings.updates.installed', ['version' => $installed['version']]);

$jsI18n = i18n_js_dict([
    'js.avatar.preview_alt',
    'js.updates.checking',
    'js.updates.download',
    'js.updates.install',
    'js.updates.installing',
    'js.updates.install_failed',
    'js.updates.failed',
    'js.updates.unreachable',
    'js.updates.fallback_help',
    'js.updates.fallback_link',
    'js.reports.sending',
    'js.reports.failed',
    'js.reports.unreachable',
]);

dashboard_layout_start([
    'title' => t('settings.title'),
    'active' => 'settings',
    'brand' => $ctx['brand'],
    'site_name' => $ctx['site_name'],
    'user_name' => $ctx['user_name'],
    'subtitle' => t('settings.subtitle'),
    'avatar_file' => $avatarFile,
]);
?>

  <?php if ($notice !== ''): ?>
    <div class="alert alert-success" role="alert"><?= $esc($notice) ?></div>
  <?php endif; ?>
  <?php if ($errors !== []): ?>
    <div class="alert alert-danger" role="alert">
      <?php foreach ($errors as $e): ?><div><?= $esc($e) ?></div><?php endforeach; ?>
    </div>
  <?php endif; ?>

  <div class="settings-forms">
  <div class="row g-4 settings-top align-items-stretch">
    <div class="col-lg-6 d-lg-flex">
      <section class="card flex-grow-1 w-100">
        <div class="card-body p-4">
          <h2 class="card-title h5 mb-1"><?= $esc(t('settings.general.title')) ?></h2>
          <p class="text-secondary mb-4"><?= $esc(t('settings.general.intro')) ?></p>
          <form method="post">
            <input type="hidden" name="csrf" value="<?= $esc($csrf) ?>" />
            <input type="hidden" name="form" value="general" />
            <div class="mb-3">
              <label class="form-label" for="site_name"><?= $esc(t('settings.general.site_name')) ?></label>
              <input id="site_name" class="form-control" type="text" name="site_name" value="<?= $esc($cfg['site_name'] ?? '') ?>" required />
            </div>
            <div class="mb-3">
              <label class="form-label" for="site_url"><?= $esc(t('settings.general.site_url')) ?></label>
              <input id="site_url" class="form-control" type="url" name="site_url" placeholder="<?= $esc(t('settings.general.site_url_placeholder')) ?>" value="<?= $esc($cfg['site_url'] ?? '') ?>" required />
            </div>
            <div class="mb-3">
              <label class="form-label" for="install_path"><?= $esc(t('settings.general.install_path')) ?></label>
              <?php
                $savedInstall = array_key_exists('install_path', $cfg)
                  ? doostats_normalize_install_path((string) $cfg['install_path'])
                  : '';
              ?>
              <input id="install_path" class="form-control font-monospace" type="text" name="install_path" placeholder="<?= $esc(t('settings.general.install_path_placeholder')) ?>" value="<?= $esc($savedInstall) ?>" />
            </div>
            <div class="mb-3">
              <label class="form-label" for="brand_hex_btn"><?= $esc(t('settings.general.brand_colour')) ?></label>
              <?= doostats_brand_select_html((string) ($cfg['brand_hex'] ?? doostats_brand_default())) ?>
            </div>
            <div class="mb-3">
              <label class="form-label" for="timezone"><?= $esc(t('settings.general.timezone')) ?></label>
              <select id="timezone" class="form-select" name="timezone">
                <?php foreach (timezone_identifiers_list() as $tz): ?>
                  <option value="<?= $esc($tz) ?>"<?= $tz === $selectedTz ? ' selected' : '' ?>><?= $esc($tz) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <?php if (count($availableLanguages) > 1): ?>
            <div class="mb-3">
              <label class="form-label" for="ui_language"><?= $esc(t('settings.general.language')) ?></label>
              <select id="ui_language" class="form-select" name="ui_language">
                <?php foreach ($availableLanguages as $code => $name): ?>
                  <option value="<?= $esc($code) ?>"<?= $code === $selectedLang ? ' selected' : '' ?>><?= $esc($name) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <?php endif; ?>
            <div class="mb-3">
              <label class="form-label" for="ui_theme"><?= $esc(t('settings.general.theme')) ?></label>
              <?php $selectedTheme = doostats_ui_theme($cfg); ?>
              <select id="ui_theme" class="form-select" name="ui_theme">
                <option value="light"<?= $selectedTheme === 'light' ? ' selected' : '' ?>><?= $esc(t('settings.general.theme_light')) ?></option>
                <option value="dark"<?= $selectedTheme === 'dark' ? ' selected' : '' ?>><?= $esc(t('settings.general.theme_dark')) ?></option>
                <option value="system"<?= $selectedTheme === 'system' ? ' selected' : '' ?>><?= $esc(t('settings.general.theme_system')) ?></option>
              </select>
            </div>
            <div class="mb-3">
              <label class="form-label" for="retention_days"><?= $esc(t('settings.general.retention')) ?></label>
              <input id="retention_days" class="form-control" type="number" name="retention_days" min="1" max="90" value="<?= $esc((int) ($cfg['retention_days'] ?? 45)) ?>" />
            </div>
            <div class="mb-3">
              <label class="form-label" for="dashboard_refresh_seconds"><?= $esc(t('settings.general.auto_refresh')) ?></label>
              <?php $dashRefresh = (int) ($cfg['dashboard_refresh_seconds'] ?? 0); ?>
              <select id="dashboard_refresh_seconds" class="form-select" name="dashboard_refresh_seconds">
                <option value="0"<?= $dashRefresh === 0 ? ' selected' : '' ?>><?= $esc(t('settings.general.refresh_off')) ?></option>
                <option value="30"<?= $dashRefresh === 30 ? ' selected' : '' ?>><?= $esc(t('settings.general.refresh_30')) ?></option>
                <option value="60"<?= $dashRefresh === 60 ? ' selected' : '' ?>><?= $esc(t('settings.general.refresh_60')) ?></option>
                <option value="300"<?= $dashRefresh === 300 ? ' selected' : '' ?>><?= $esc(t('settings.general.refresh_300')) ?></option>
                <option value="600"<?= $dashRefresh === 600 ? ' selected' : '' ?>><?= $esc(t('settings.general.refresh_600')) ?></option>
                <option value="1200"<?= $dashRefresh === 1200 ? ' selected' : '' ?>><?= $esc(t('settings.general.refresh_1200')) ?></option>
              </select>
            </div>
            <div class="pt-2">
              <button class="btn btn-primary" type="submit"><?= $esc(t('settings.general.save')) ?></button>
            </div>
          </form>
        </div>
      </section>
    </div>

    <div class="col-lg-6 d-lg-flex">
      <div class="settings-stack">
      <section class="card">
        <div class="card-body p-4">
          <h2 class="card-title h5 mb-1"><?= $esc(t('settings.profile.title')) ?></h2>
          <p class="text-secondary mb-4"><?= $esc(t('settings.profile.intro')) ?></p>
          <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="csrf" value="<?= $esc($csrf) ?>" />
            <input type="hidden" name="form" value="profile" />
            <div class="mb-3">
              <label class="form-label" for="user_name"><?= $esc(t('settings.profile.user_name')) ?></label>
              <input id="user_name" class="form-control" type="text" name="user_name" value="<?= $esc((string) (($cfg['user_name'] ?? '') !== '' ? $cfg['user_name'] : t('nav.user_fallback'))) ?>" maxlength="20" required autocomplete="nickname" />
            </div>
            <div class="mb-3">
              <label class="form-label" for="avatar"><?= $esc(t('settings.profile.avatar')) ?></label>
              <div class="d-flex align-items-start gap-3 flex-wrap">
                <div class="avatar-preview" id="avatarPreview">
                  <?php if ($avatarFile !== null): ?>
                    <img src="avatar.php?v=<?= (int) @filemtime($avatarFile) ?>" alt="<?= $esc(t('settings.profile.avatar_current_alt')) ?>" />
                  <?php else: ?>
                    <?= DASHBOARD_AVATAR_SVG ?>
                  <?php endif; ?>
                </div>
                <div class="flex-grow-1" style="min-width:200px">
                  <input id="avatar" class="form-control" type="file" name="avatar" accept="image/png,image/jpeg,image/gif,image/webp" />
                  <div class="form-text"><?= $esc(t('settings.profile.avatar_help')) ?></div>
                </div>
              </div>
            </div>
            <div class="pt-2 d-flex gap-2">
              <button class="btn btn-primary" type="submit"><?= $esc(t('settings.profile.save')) ?></button>
              <?php if ($avatarFile !== null): ?>
                <button class="btn btn-outline-secondary" type="submit" form="avatar-remove-form"><?= $esc(t('settings.profile.remove_avatar')) ?></button>
              <?php endif; ?>
            </div>
          </form>
          <?php if ($avatarFile !== null): ?>
            <form id="avatar-remove-form" method="post" hidden>
              <input type="hidden" name="csrf" value="<?= $esc($csrf) ?>" />
              <input type="hidden" name="form" value="avatar_remove" />
            </form>
          <?php endif; ?>
        </div>
      </section>

      <section class="card">
        <div class="card-body p-4">
          <h2 class="card-title h5 mb-1"><?= $esc(t('settings.password.title')) ?></h2>
          <p class="text-secondary mb-4"><?= $esc(t('settings.password.intro')) ?></p>
          <form method="post" autocomplete="off">
            <input type="hidden" name="csrf" value="<?= $esc($csrf) ?>" />
            <input type="hidden" name="form" value="password" />
            <div class="mb-3">
              <label class="form-label" for="current_password"><?= $esc(t('settings.password.current')) ?></label>
              <input id="current_password" class="form-control" type="password" name="current_password" required />
            </div>
            <div class="mb-3">
              <label class="form-label" for="new_password"><?= $esc(t('settings.password.new')) ?></label>
              <input id="new_password" class="form-control" type="password" name="new_password" required />
            </div>
            <div class="mb-3">
              <label class="form-label" for="new_password2"><?= $esc(t('settings.password.confirm')) ?></label>
              <input id="new_password2" class="form-control" type="password" name="new_password2" required />
            </div>
            <div class="pt-2">
              <button class="btn btn-primary" type="submit"><?= $esc(t('settings.password.update')) ?></button>
            </div>
          </form>
        </div>
      </section>
      </div>
    </div>
  </div>

  <div class="row g-4 settings-top align-items-stretch mt-4">
    <div class="col-lg-6 d-lg-flex">
      <section class="card flex-grow-1 w-100">
        <div class="card-body p-4">
          <h2 class="card-title h5 mb-1"><?= $esc(t('settings.advanced.title')) ?></h2>
          <p class="text-secondary mb-4"><?= $esc(t('settings.advanced.intro')) ?></p>
          <form method="post">
            <input type="hidden" name="csrf" value="<?= $esc($csrf) ?>" />
            <input type="hidden" name="form" value="advanced" />
            <div class="form-check form-switch mb-3">
              <input id="filter_bots" class="form-check-input" type="checkbox" role="switch" name="filter_bots" value="1"<?= $filterBots ? ' checked' : '' ?> />
              <label class="form-check-label" for="filter_bots"><?= $esc(t('settings.advanced.filter_bots')) ?></label>
            </div>
            <div class="form-check form-switch mb-3">
              <input id="ignore_localhost" class="form-check-input" type="checkbox" role="switch" name="ignore_localhost" value="1"<?= !empty($cfg['ignore_localhost']) ? ' checked' : '' ?> />
              <label class="form-check-label" for="ignore_localhost"><?= $esc(t('settings.advanced.ignore_localhost')) ?></label>
            </div>
            <div class="form-check form-switch mb-3">
              <input id="trust_proxy" class="form-check-input" type="checkbox" role="switch" name="trust_proxy" value="1"<?= !empty($cfg['trust_proxy']) ? ' checked' : '' ?> />
              <label class="form-check-label" for="trust_proxy"><?= $esc(t('settings.advanced.trust_proxy')) ?></label>
              <div class="form-text"><?= $esc(t('settings.advanced.trust_proxy_help')) ?></div>
            </div>
            <div class="form-check form-switch mb-3">
              <input id="process_visitor_ip" class="form-check-input" type="checkbox" role="switch" name="process_visitor_ip" value="1"<?= $processVisitorIp ? ' checked' : '' ?> />
              <label class="form-check-label" for="process_visitor_ip"><?= $esc(t('settings.advanced.process_ip')) ?></label>
              <div class="form-text"><?= $esc(t('settings.advanced.process_ip_help')) ?></div>
            </div>
            <div class="mb-3">
              <label class="form-label" for="excluded_paths"><?= $esc(t('settings.advanced.excluded_paths')) ?></label>
              <textarea id="excluded_paths" class="form-control font-monospace" name="excluded_paths" rows="3" placeholder="<?= $esc(t('settings.advanced.excluded_paths_placeholder')) ?>"><?= $esc($excludedPathsText) ?></textarea>
              <div class="form-text"><?= $esc(t('settings.advanced.excluded_paths_help')) ?></div>
            </div>
            <div class="mb-3">
              <label class="form-label" for="ignore_ips"><?= $esc(t('settings.advanced.ignore_ips')) ?></label>
              <textarea id="ignore_ips" class="form-control font-monospace" name="ignore_ips" rows="3" placeholder="<?= $esc(t('settings.advanced.ignore_ips_placeholder')) ?>"><?= $esc($ignoreIpsText) ?></textarea>
              <div class="form-text"><?= $esc(t('settings.advanced.ignore_ips_help')) ?></div>
            </div>
            <div class="mb-3">
              <label class="form-label" for="referrer_blocklist"><?= $esc(t('settings.advanced.blocked_referrers')) ?></label>
              <textarea id="referrer_blocklist" class="form-control font-monospace" name="referrer_blocklist" rows="3" placeholder="<?= $esc(t('settings.advanced.blocked_referrers_placeholder')) ?>"><?= $esc($referrerBlockText) ?></textarea>
              <div class="form-text"><?= $esc(t('settings.advanced.blocked_referrers_help')) ?></div>
            </div>
            <div class="pt-2">
              <button class="btn btn-primary" type="submit"><?= $esc(t('settings.advanced.save')) ?></button>
            </div>
          </form>
        </div>
      </section>
    </div>

    <div class="col-lg-6 d-lg-flex">
      <div class="settings-stack">
      <section class="card" id="reports">
        <div class="card-body p-4">
          <h2 class="card-title h5 mb-1"><?= $esc(t('settings.reports.title')) ?></h2>
          <p class="text-secondary mb-4"><?= $esc(t('settings.reports.intro')) ?></p>
          <div id="reports-result">
            <?php if ($reportsNotice !== ''): ?>
              <div class="alert alert-success py-2" role="status"><?= $esc($reportsNotice) ?></div>
            <?php endif; ?>
            <?php if ($reportsErrors !== []): ?>
              <div class="alert alert-danger py-2" role="alert">
                <?php foreach ($reportsErrors as $e): ?><div><?= $esc($e) ?></div><?php endforeach; ?>
              </div>
            <?php endif; ?>
          </div>
          <form id="reports-form" method="post" action="#reports">
            <input type="hidden" name="csrf" value="<?= $esc($csrf) ?>" />
            <input type="hidden" name="form" value="reports" />
            <div class="form-check form-switch mb-3">
              <input id="digest_enabled" class="form-check-input" type="checkbox" role="switch" name="digest_enabled" value="1"<?= !empty($cfg['digest_enabled']) ? ' checked' : '' ?> />
              <label class="form-check-label" for="digest_enabled"><?= $esc(t('settings.reports.enabled')) ?></label>
            </div>
            <div id="reports-details"<?= empty($cfg['digest_enabled']) ? ' hidden' : '' ?>>
              <div class="mb-3">
                <label class="form-label" for="digest_email"><?= $esc(t('settings.reports.email')) ?></label>
                <input id="digest_email" class="form-control" type="email" name="digest_email" value="<?= $esc((string) ($cfg['digest_email'] ?? '')) ?>" autocomplete="email" placeholder="<?= $esc(t('settings.reports.email_placeholder')) ?>" />
                <div class="form-text"><?= $esc(t('settings.reports.email_help')) ?></div>
              </div>
              <p id="reports-status" class="small text-secondary mb-3"><?= $esc(doostats_digest_status_label()) ?></p>
            </div>
            <div class="d-flex flex-wrap gap-2 pt-2">
              <button class="btn btn-primary" type="submit"><?= $esc(t('settings.reports.save')) ?></button>
              <button id="reports-test-btn" class="btn btn-outline-secondary" type="button" hidden><?= $esc(t('settings.reports.send_test')) ?></button>
            </div>
          </form>
        </div>
      </section>

      <section class="card" id="updates">
        <div class="card-body p-4">
          <h2 class="card-title h5 mb-1"><?= $esc(t('settings.updates.title')) ?></h2>
          <p class="text-secondary mb-3"><?= $esc($updatesIntro) ?></p>

          <div id="update-check-result">
          <?php if (is_array($updateResult)): ?>
            <?php
              $updateAlert = match ((string) ($updateResult['status'] ?? '')) {
                  'update_available' => 'alert-info',
                  'up_to_date' => 'alert-success',
                  default => 'alert-danger',
              };
            ?>
            <div class="alert <?= $esc($updateAlert) ?> py-2">
              <div><?= $esc($updateResult['message']) ?></div>
              <?php if ($updateResult['status'] === 'update_available' && $updateResult['notes'] !== ''): ?>
                <div class="small mt-1"><?= $esc($updateResult['notes']) ?></div>
              <?php endif; ?>
              <?php if ($updateResult['status'] === 'update_available'): ?>
                <div class="mt-2 d-flex flex-wrap gap-2">
                  <?php if (!empty($updateResult['can_apply'])): ?>
                    <button type="button" class="btn btn-sm btn-primary js-update-install" data-csrf="<?= $esc($csrf) ?>"><?= $esc(t('settings.updates.install')) ?></button>
                  <?php else: ?>
                    <a class="btn btn-sm btn-primary" href="<?= $esc(doostats_update_fallback_page_url()) ?>" target="_blank" rel="noopener"><?= $esc(t('settings.updates.download')) ?></a>
                  <?php endif; ?>
                </div>
              <?php elseif (($updateResult['status'] ?? '') === 'error'): ?>
                <div class="small mt-2">
                  <?= $esc(t('settings.updates.fallback_help')) ?>
                  <a href="<?= $esc(doostats_update_fallback_page_url()) ?>" target="_blank" rel="noopener"><?= $esc(t('settings.updates.fallback_link')) ?></a>
                </div>
              <?php endif; ?>
            </div>
          <?php endif; ?>
          </div>

          <div class="d-flex flex-wrap align-items-center gap-2">
            <form id="update-check-form" method="post" action="#updates">
              <input type="hidden" name="csrf" value="<?= $esc($csrf) ?>" />
              <input type="hidden" name="form" value="update_check" />
              <button id="update-check-btn" class="btn btn-outline-secondary" type="submit"><?= $esc(t('settings.updates.check')) ?></button>
            </form>
            <a class="btn btn-outline-secondary" href="<?= $esc(doostats_update_changelog_url()) ?>" target="_blank" rel="noopener"><?= $esc(t('settings.updates.release_notes')) ?></a>
          </div>
        </div>
      </section>

      <section class="card border-danger-subtle bg-danger-subtle" id="danger-zone">
        <div class="card-body p-4">
          <h2 class="card-title h5 text-danger-emphasis mb-1"><?= $esc(t('settings.danger.title')) ?></h2>
          <p class="text-body-secondary mb-3"><?= $esc(t('settings.danger.intro')) ?></p>
          <form method="post" action="#danger-zone" autocomplete="off">
            <input type="hidden" name="csrf" value="<?= $esc($csrf) ?>" />
            <input type="hidden" name="form" value="reset_stats" />
            <div class="mb-3" style="max-width: 22rem">
              <label class="form-label" for="confirm_password"><?= $esc(t('settings.danger.password')) ?></label>
              <input id="confirm_password" class="form-control" type="password" name="confirm_password" required />
            </div>
            <button class="btn btn-danger" type="submit"><?= $esc(t('settings.danger.reset')) ?></button>
          </form>
        </div>
      </section>
      </div>
    </div>
  </div>
  </div>

<?php
$avatarPreviewScript = '<script>const I18N = ' . json_encode($jsI18n, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . ';'
    . 'var UPDATE_FALLBACK_PAGE = ' . json_encode(doostats_update_fallback_page_url(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . ';</script>' . <<<'HTML'
<script>
(function () {
  var input = document.getElementById('avatar');
  var preview = document.getElementById('avatarPreview');
  if (!input || !preview) return;
  input.addEventListener('change', function () {
    var file = input.files && input.files[0];
    if (!file || file.type.indexOf('image/') !== 0) return;
    var reader = new FileReader();
    reader.onload = function (e) {
      var img = document.createElement('img');
      img.alt = I18N['js.avatar.preview_alt'];
      img.src = e.target.result;
      preview.innerHTML = '';
      preview.appendChild(img);
    };
    reader.readAsDataURL(file);
  });
})();
</script>
<script>
(function () {
  var form = document.getElementById('reports-form');
  var enabled = document.getElementById('digest_enabled');
  var email = document.getElementById('digest_email');
  var details = document.getElementById('reports-details');
  var testBtn = document.getElementById('reports-test-btn');
  var box = document.getElementById('reports-result');
  var status = document.getElementById('reports-status');
  if (!form || !enabled || !email || !testBtn || !box) return;

  function emailLooksValid(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || '').trim());
  }

  function syncReportsUi() {
    if (details) details.hidden = !enabled.checked;
    var show = enabled.checked && emailLooksValid(email.value);
    testBtn.hidden = !show;
    if (!show) testBtn.disabled = false;
  }

  function showMessage(ok, message) {
    box.textContent = '';
    var alert = document.createElement('div');
    alert.className = ok ? 'alert alert-success py-2' : 'alert alert-danger py-2';
    alert.setAttribute('role', ok ? 'status' : 'alert');
    alert.textContent = message || (ok ? '' : (I18N['js.reports.failed'] || 'Failed.'));
    box.appendChild(alert);
  }

  enabled.addEventListener('change', syncReportsUi);
  email.addEventListener('input', syncReportsUi);
  email.addEventListener('change', syncReportsUi);
  syncReportsUi();

  if (!window.fetch) return;

  testBtn.addEventListener('click', function () {
    if (testBtn.disabled || testBtn.hidden) return;
    if (!enabled.checked || !emailLooksValid(email.value)) {
      syncReportsUi();
      return;
    }
    testBtn.disabled = true;
    var label = testBtn.textContent;
    testBtn.textContent = I18N['js.reports.sending'] || 'Sending…';

    var data = new FormData(form);
    data.set('digest_enabled', '1');

    fetch('digest-test.php', {
      method: 'POST',
      credentials: 'same-origin',
      cache: 'no-store',
      body: data
    })
      .then(function (r) { return r.json().then(function (payload) { return { httpOk: r.ok, data: payload }; }); })
      .then(function (res) {
        var data = res.data || {};
        showMessage(!!data.ok, data.message || I18N['js.reports.failed']);
        if (data.status && status) status.textContent = data.status;
      })
      .catch(function () {
        showMessage(false, I18N['js.reports.unreachable'] || I18N['js.reports.failed']);
      })
      .finally(function () {
        testBtn.disabled = false;
        testBtn.textContent = label;
        syncReportsUi();
      });
  });
})();
</script>
<script>
(function () {
  var form = document.getElementById('update-check-form');
  var btn = document.getElementById('update-check-btn');
  var box = document.getElementById('update-check-result');
  if (!form || !btn || !box || !window.fetch) return;

  function alertClass(status) {
    if (status === 'update_available') return 'alert alert-info py-2';
    if (status === 'up_to_date') return 'alert alert-success py-2';
    return 'alert alert-danger py-2';
  }

  function appendFallback(alert) {
    var help = document.createElement('div');
    help.className = 'small mt-2';
    help.appendChild(document.createTextNode((I18N['js.updates.fallback_help'] || '') + ' '));
    var a = document.createElement('a');
    a.href = window.UPDATE_FALLBACK_PAGE || '#';
    a.target = '_blank';
    a.rel = 'noopener';
    a.textContent = I18N['js.updates.fallback_link'] || 'Download page';
    help.appendChild(a);
    alert.appendChild(help);
  }

  function csrfToken() {
    var input = form.querySelector('input[name="csrf"]');
    return input ? input.value : '';
  }

  function bindInstallButton(root) {
    var installBtn = root.querySelector('.js-update-install');
    if (!installBtn) return;
    installBtn.addEventListener('click', function () {
      if (installBtn.disabled) return;
      installBtn.disabled = true;
      if (btn) btn.disabled = true;
      var label = installBtn.textContent;
      installBtn.textContent = I18N['js.updates.installing'] || 'Installing…';

      var data = new FormData();
      data.set('csrf', installBtn.getAttribute('data-csrf') || csrfToken());

      fetch('update-apply.php', {
        method: 'POST',
        credentials: 'same-origin',
        cache: 'no-store',
        body: data
      })
        .then(function (r) { return r.json().then(function (payload) { return { httpOk: r.ok, data: payload }; }); })
        .then(function (res) {
          var data = res.data || {};
          if (data.ok) {
            renderResult({
              status: 'up_to_date',
              message: data.message || I18N['js.updates.install']
            });
            window.setTimeout(function () { window.location.reload(); }, 900);
            return;
          }
          renderResult({
            status: 'error',
            message: data.message || I18N['js.updates.install_failed']
          });
        })
        .catch(function () {
          renderResult({
            status: 'error',
            message: I18N['js.updates.unreachable'] || I18N['js.updates.install_failed']
          });
        })
        .finally(function () {
          if (btn) btn.disabled = false;
          // Button may have been replaced by renderResult.
        });
    });
  }

  function renderResult(data) {
    box.textContent = '';
    var alert = document.createElement('div');
    alert.className = alertClass(data && data.status);
    alert.setAttribute('role', 'status');

    var msg = document.createElement('div');
    msg.textContent = (data && data.message) ? data.message : I18N['js.updates.failed'];
    alert.appendChild(msg);

    if (data && data.status === 'update_available') {
      if (data.notes) {
        var notes = document.createElement('div');
        notes.className = 'small mt-1';
        notes.textContent = data.notes;
        alert.appendChild(notes);
      }
      var actions = document.createElement('div');
      actions.className = 'mt-2 d-flex flex-wrap gap-2';
      if (data.can_apply) {
        var install = document.createElement('button');
        install.type = 'button';
        install.className = 'btn btn-sm btn-primary js-update-install';
        install.setAttribute('data-csrf', csrfToken());
        install.textContent = I18N['js.updates.install'] || 'Install update';
        actions.appendChild(install);
      } else {
        var dlOnly = document.createElement('a');
        dlOnly.className = 'btn btn-sm btn-primary';
        dlOnly.href = window.UPDATE_FALLBACK_PAGE || '#';
        dlOnly.target = '_blank';
        dlOnly.rel = 'noopener';
        dlOnly.textContent = I18N['js.updates.download'];
        actions.appendChild(dlOnly);
      }
      alert.appendChild(actions);
    } else if (!data || data.status === 'error' || data.ok === false) {
      appendFallback(alert);
    }

    box.appendChild(alert);
    bindInstallButton(box);
  }

  bindInstallButton(box);

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (btn.disabled) return;
    btn.disabled = true;
    var label = btn.textContent;
    btn.textContent = I18N['js.updates.checking'];

    fetch('update-check.php', {
      method: 'POST',
      credentials: 'same-origin',
      cache: 'no-store',
      body: new FormData(form)
    })
      .then(function (r) { return r.json().then(function (data) { return { ok: r.ok, data: data }; }); })
      .then(function (res) {
        renderResult(res.data || { status: 'error', message: I18N['js.updates.failed'] });
      })
      .catch(function () {
        renderResult({ status: 'error', message: I18N['js.updates.unreachable'] });
      })
      .finally(function () {
        btn.disabled = false;
        btn.textContent = label;
      });
  });
})();
</script>
HTML;
dashboard_layout_end($avatarPreviewScript . doostats_brand_select_script());
?>
