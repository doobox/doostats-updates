<?php

declare(strict_types=1);

/**
 * Optional server-side pageview tracking for PHP sites.
 *
 * Include this near the top of a page (before output) to record a pageview
 * without any JavaScript:
 *
 *   require __DIR__ . '/stats/track.php';
 *
 * Use either this OR tracker.js, not both, or pageviews will be double counted.
 */

require_once __DIR__ . '/lib/analytics.php';

(static function (): void {
    try {
        $ua = strtolower((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''));
        $device = 'desktop';
        if (preg_match('/ipad|tablet|playbook|silk|kindle/', $ua) || preg_match('/android(?!.*mobile)/', $ua)) {
            $device = 'tablet';
        } elseif (preg_match('/mobile|iphone|ipod|android|blackberry|iemobile|opera mini|windows phone/', $ua)) {
            $device = 'mobile';
        }

        $path = parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH) ?: '/';
        $referrer = (string) ($_SERVER['HTTP_REFERER'] ?? '');

        analytics_record_pageview($path, $device, $referrer);
    } catch (Throwable $e) {
        // Never break the host page.
    }
})();
