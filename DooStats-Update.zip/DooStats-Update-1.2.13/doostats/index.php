<?php

declare(strict_types=1);

// Entry point: send people to setup on first run, otherwise the dashboard.
$configPath = __DIR__ . '/config.php';
$configured = false;
if (is_file($configPath)) {
    $cfg = require $configPath;
    $configured = is_array($cfg) && !empty($cfg['admin_password_hash']);
}

header('Location: ' . ($configured ? 'dashboard/' : 'setup.php'));
exit;
