<?php

declare(strict_types=1);

/**
 * AJAX: save one Settings section without a full page reload.
 */

require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/settings-save.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$json = static function (array $payload, int $code = 200): void {
    http_response_code($code);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
};

if (!auth_is_logged_in()) {
    $json(['ok' => false, 'message' => t('updates.error.not_signed_in'), 'errors' => [t('updates.error.not_signed_in')]], 403);
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    $json(['ok' => false, 'message' => t('updates.error.post_required'), 'errors' => [t('updates.error.post_required')]], 405);
}

if (!auth_check_csrf($_POST['csrf'] ?? null)) {
    $json(['ok' => false, 'message' => t('updates.error.csrf'), 'errors' => [t('updates.error.csrf')]], 403);
}

$form = trim((string) ($_POST['form'] ?? ''));
$allowed = ['general', 'advanced', 'password', 'profile', 'avatar_remove', 'reports', 'updates_auto', 'reset_stats'];
if (!in_array($form, $allowed, true)) {
    $json(['ok' => false, 'message' => t('settings.error.config_update'), 'errors' => [t('settings.error.config_update')]], 400);
}

$result = doostats_settings_save($form, analytics_config(), $_POST, $_FILES);

$json([
    'ok' => $result['ok'],
    'message' => $result['message'],
    'errors' => $result['errors'],
    'reload' => $result['reload'],
    'ui' => $result['ui'],
]);
