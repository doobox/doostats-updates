<?php

declare(strict_types=1);

require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/update-check.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if (!auth_is_logged_in()) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'status' => 'error', 'message' => t('updates.error.not_signed_in')]);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'status' => 'error', 'message' => t('updates.error.post_required')]);
    exit;
}

if (!auth_check_csrf($_POST['csrf'] ?? null)) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'status' => 'error', 'message' => t('updates.error.csrf')]);
    exit;
}

// Drop the session lock before the outbound HTTPS call so other dashboard
// requests are not blocked for the duration of the feed fetch.
auth_release_session();

$result = doostats_check_for_updates();
doostats_update_store_check_result($result);

echo json_encode(
    doostats_public_update_result($result),
    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
);
