<?php

declare(strict_types=1);

require_once __DIR__ . '/../lib/auth.php';

header('Content-Type: application/json');
header('Cache-Control: no-store');

if (!auth_is_logged_in()) {
    http_response_code(403);
    echo json_encode(['ok' => false]);
    exit;
}

// Read-only endpoint: drop the session lock so polls never block a page reload.
auth_release_session();

try {
    $summary = analytics_active_visitors_summary();
    echo json_encode([
        'ok' => true,
        'active_visitors_map' => analytics_active_visitors_map(),
        'active_visitors_total' => $summary['total'],
        'active_visitors_unknown_or_unmapped' => $summary['unknown_or_unmapped'],
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false]);
}
