<?php

declare(strict_types=1);

/**
 * Locked-out helper. Generates a bcrypt hash for a new password and shows it on
 * screen so the admin can paste it into config.php. It deliberately does NOT
 * write config.php: applying the hash requires file access, which is the only
 * thing that authorises the change. A stranger who reaches this page can only
 * compute a hash (already trivial to do anywhere) and gains nothing.
 */

require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/brand-palette.php';

auth_boot();

if (!auth_is_configured()) {
    header('Location: ../setup.php');
    exit;
}

$errors = [];
$hash = '';
$csrf = auth_csrf_token();

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    if (!auth_check_csrf($_POST['csrf'] ?? null)) {
        $errors[] = t('auth.forgot.error.csrf');
    }

    $pass = (string) ($_POST['password'] ?? '');
    $pass2 = (string) ($_POST['password2'] ?? '');

    if (strlen($pass) < 8) {
        $errors[] = t('auth.forgot.error.password_len');
    }
    if ($pass !== $pass2) {
        $errors[] = t('auth.forgot.error.mismatch');
    }
    if ($errors === []) {
        $hash = password_hash($pass, PASSWORD_DEFAULT);
    }
}

$cfg = analytics_config();
$brand = (string) ($cfg['brand_hex'] ?? doostats_brand_default());
$esc = static fn (string $v): string => htmlspecialchars($v, ENT_QUOTES, 'UTF-8');
?>
<!doctype html>
<html lang="<?= $esc(i18n_html_lang()) ?>"<?= doostats_ui_theme_html_attrs() ?>>
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="robots" content="noindex, nofollow" />
<title><?= $esc(t('auth.forgot.title')) ?></title>
<link rel="stylesheet" href="../assets/vendor/bootstrap/bootstrap.min.css" />
<link rel="stylesheet" href="../assets/app.css?v=<?= (int) @filemtime(__DIR__ . '/../assets/app.css') ?>" />
<?= doostats_brand_css_vars($brand) ?>
<?= doostats_ui_theme_boot_script() ?>
</head>
<body>
<div class="min-vh-100 d-flex align-items-center justify-content-center p-3">
  <div class="card shadow-sm w-100" style="max-width:480px">
    <div class="card-body p-4">
      <h1 class="h4 mb-1"><?= $esc(t('auth.forgot.heading')) ?></h1>
      <p class="text-secondary"><?= $esc(t('auth.forgot.intro')) ?></p>

      <?php if ($hash !== ''): ?>
        <div class="alert alert-success py-2"><?= $esc(t('auth.forgot.success')) ?></div>

        <p class="fw-semibold mb-1"><?= $esc(t('auth.forgot.step1')) ?></p>
        <div class="codebox">
          <pre><code><?= $esc("'admin_password_hash' => '" . $hash . "',") ?></code></pre>
          <button type="button" class="codebox-copy" data-copy aria-label="<?= $esc(t('auth.forgot.copy_clipboard')) ?>">
            <svg class="ic-copy" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path fill-rule="evenodd" d="M4 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1zM2 5a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1v-1h1v1a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h1v1z"/></svg>
            <svg class="ic-check" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0"/></svg>
          </button>
        </div>

        <p class="mt-3 mb-0"><?= $esc(t('auth.forgot.step2')) ?></p>
        <?php
          $step3 = t('auth.forgot.step3');
          $linkWord = t('auth.forgot.step3_link');
          $pos = mb_strpos($step3, $linkWord);
        ?>
        <p class="mt-2 mb-0"><?php
          if ($pos !== false) {
              echo $esc(mb_substr($step3, 0, $pos));
              echo '<a href="login.php">' . $esc($linkWord) . '</a>';
              echo $esc(mb_substr($step3, $pos + mb_strlen($linkWord)));
          } else {
              echo $esc($step3);
          }
        ?></p>

        <p class="text-secondary small mt-3 mb-0"><?= $esc(t('auth.forgot.security_note')) ?></p>

      <?php else: ?>
        <?php if ($errors !== []): ?>
          <div class="alert alert-danger py-2">
            <?php foreach ($errors as $e): ?><div><?= $esc($e) ?></div><?php endforeach; ?>
          </div>
        <?php endif; ?>
        <form method="post">
          <input type="hidden" name="csrf" value="<?= $esc($csrf) ?>" />
          <div class="mb-3">
            <label class="form-label" for="password"><?= $esc(t('auth.forgot.new_password')) ?></label>
            <input id="password" class="form-control" type="password" name="password" autofocus required />
          </div>
          <div class="mb-3">
            <label class="form-label" for="password2"><?= $esc(t('auth.forgot.confirm_password')) ?></label>
            <input id="password2" class="form-control" type="password" name="password2" required />
          </div>
          <button class="btn btn-primary w-100" type="submit"><?= $esc(t('auth.forgot.generate')) ?></button>
        </form>
      <?php endif; ?>

      <p class="mt-3 mb-0 small"><a href="login.php"><?= $esc(t('auth.forgot.back')) ?></a></p>
    </div>
  </div>
</div>
<?php if ($hash !== ''): ?>
<script>
  document.querySelectorAll('[data-copy]').forEach(function (btn) {
    var timer;
    function done() {
      btn.classList.add('is-copied');
      clearTimeout(timer);
      timer = setTimeout(function () { btn.classList.remove('is-copied'); }, 1500);
    }
    btn.addEventListener('click', function () {
      var pre = btn.closest('.codebox').querySelector('pre');
      var text = pre ? pre.innerText : '';
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(done).catch(function () {});
      } else {
        var ta = document.createElement('textarea');
        ta.value = text; document.body.appendChild(ta); ta.select();
        try { document.execCommand('copy'); done(); } catch (e) {}
        document.body.removeChild(ta);
      }
    });
  });
</script>
<?php endif; ?>
</body>
</html>
