<?php

declare(strict_types=1);

require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/update-apply.php';

/**
 * AJAX: download and apply the latest update package from the feed.
 */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$json = static function (array $payload, int $code = 200): void {
    http_response_code($code);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
};

if (!auth_is_logged_in()) {
    $json(['ok' => false, 'message' => t('updates.error.not_signed_in')], 403);
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    $json(['ok' => false, 'message' => t('updates.error.post_required')], 405);
}

if (!auth_check_csrf($_POST['csrf'] ?? null)) {
    $json(['ok' => false, 'message' => t('updates.error.csrf')], 403);
}

// Drop the session lock before the long download/apply so other tabs stay responsive.
auth_release_session();

$result = doostats_update_apply_now();
$json([
    'ok' => !empty($result['ok']),
    'message' => (string) ($result['message'] ?? ''),
    'version' => (string) ($result['version'] ?? ''),
]);
