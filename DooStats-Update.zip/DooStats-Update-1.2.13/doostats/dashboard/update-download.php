<?php

declare(strict_types=1);

require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/update-check.php';

/**
 * Logged-in redirect to the current update zip. Keeps the real download URL
 * out of Settings HTML/JSON; the browser only sees this local path.
 */

auth_require_login();
auth_release_session();

$result = doostats_check_for_updates();
$url = trim((string) ($result['download_url'] ?? ''));

if (
    ($result['status'] ?? '') === 'update_available'
    && $url !== ''
    && filter_var($url, FILTER_VALIDATE_URL)
    && preg_match('#^https://#i', $url)
) {
    header('Cache-Control: no-store');
    header('Location: ' . $url, true, 302);
    exit;
}

http_response_code(404);
header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-store');
echo t('updates.error.no_download') . "\n";
