<?php

declare(strict_types=1);

require_once __DIR__ . '/_layout.php';
require_once __DIR__ . '/../lib/install-path.php';

$ctx = dashboard_guard();
$cfg = $ctx['cfg'];
// Read-only page: release the session lock immediately.
auth_release_session();

$esc = static fn ($v): string => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');

$trackerSrc = doostats_tracker_src();
$pulseSrc = doostats_install_path() . '/pulse.js';

$jsSnippet = '<script src="' . $trackerSrc . '" defer></script>';
$js404Snippet = '<script src="' . $trackerSrc . '" data-doostats-404 defer></script>';
$js404MarkerSnippet = '<div data-doostats-404-page hidden></div>';

$pulseLoadSnippet = '<script src="' . $pulseSrc . '" defer></script>';
$pulseOnlineSnippet = '<span data-pulse-online data-pulse-label="visitors online"></span>';
$pulseTodaySnippet = '<span data-pulse-today data-pulse-label="visits today"></span>';
$pulseWeekSnippet = '<span data-pulse-week data-pulse-label="visits this week"></span>';

$eventAttrButtonSnippet = '<button data-doostats-event="New Signup">Sign up</button>';
$eventAttrFormSnippet = "<form data-doostats-event=\"Contact\">\n  <!-- your fields -->\n  <button type=\"submit\">Send</button>\n</form>";
$eventAttrLinkSnippet = '<a href="/brochure.pdf" data-doostats-event="Brochure download">Download</a>';
$eventPageSnippet = "<script>\n  doostats.event('New Signup');\n</script>";
$eventFetchSnippet = "fetch('/api/signup').then(function () {\n  doostats.event('New Signup');\n});";
$eventGuardSnippet = "if (window.doostats) {\n  doostats.event('Video Play');\n}";

dashboard_layout_start([
    'title' => t('snippets.title'),
    'active' => 'snippets',
    'brand' => $ctx['brand'],
    'site_name' => $ctx['site_name'],
    'subtitle' => t('snippets.subtitle'),
    'head' => '<link rel="stylesheet" href="../assets/vendor/highlight/github-dark.min.css" />',
]);

/**
 * Render one snippet block with a copy button. $lang is a highlight.js
 * language hint (e.g. "xml" for HTML markup, "javascript" for scripts).
 */
$snippet = static function (string $heading, string $code, string $desc = '', string $lang = 'xml') use ($esc): void {
    ?>
    <div class="mb-4">
      <h3 class="h6 mb-1"><?= $esc($heading) ?></h3>
      <?php if ($desc !== ''): ?><p class="text-secondary mb-2"><?= $esc($desc) ?></p><?php endif; ?>
      <div class="codebox">
        <pre><code class="language-<?= $esc($lang) ?>"><?= $esc($code) ?></code></pre>
      </div>
    </div>
    <?php
};
?>

  <div class="card mb-4">
    <div class="card-body p-4">
      <h2 class="card-title h5 mb-1"><?= $esc(t('snippets.tracking.title')) ?></h2>
      <p class="text-secondary mb-4"><?= $esc(t('snippets.tracking.intro')) ?></p>
      <?php
      $snippet(
          t('snippets.tracking.pageview'),
          $jsSnippet,
          t('snippets.tracking.pageview_help')
      );
      $snippet(
          t('snippets.tracking.404'),
          $js404Snippet,
          t('snippets.tracking.404_help')
      );
      $snippet(
          t('snippets.tracking.global_404'),
          $js404MarkerSnippet,
          t('snippets.tracking.global_404_help')
      );
      ?>
    </div>
  </div>

  <div class="card mb-4">
    <div class="card-body p-4">
      <h2 class="card-title h5 mb-1"><?= $esc(t('snippets.pulse.title')) ?></h2>
      <p class="text-secondary mb-4"><?= $esc(t('snippets.pulse.intro')) ?></p>
      <?php
      $snippet(
          t('snippets.pulse.load'),
          $pulseLoadSnippet,
          t('snippets.pulse.load_help')
      );
      $snippet(
          t('snippets.pulse.online'),
          $pulseOnlineSnippet,
          t('snippets.pulse.online_help')
      );
      $snippet(
          t('snippets.pulse.today'),
          $pulseTodaySnippet,
          t('snippets.pulse.today_help')
      );
      $snippet(
          t('snippets.pulse.week'),
          $pulseWeekSnippet,
          t('snippets.pulse.week_help')
      );
      ?>
    </div>
  </div>

  <div class="card mb-4">
    <div class="card-body p-4">
      <h2 class="card-title h5 mb-1"><?= $esc(t('snippets.events_nocode.title')) ?></h2>
      <p class="text-secondary mb-4"><?= $esc(t('snippets.events_nocode.intro')) ?></p>
      <?php
      $snippet(
          t('snippets.events_nocode.button'),
          $eventAttrButtonSnippet,
          t('snippets.events_nocode.button_help')
      );
      $snippet(
          t('snippets.events_nocode.form'),
          $eventAttrFormSnippet,
          t('snippets.events_nocode.form_help')
      );
      $snippet(
          t('snippets.events_nocode.link'),
          $eventAttrLinkSnippet,
          t('snippets.events_nocode.link_help')
      );
      ?>
    </div>
  </div>

  <div class="card">
    <div class="card-body p-4">
      <h2 class="card-title h5 mb-1"><?= $esc(t('snippets.events_adv.title')) ?></h2>
      <p class="text-secondary mb-4"><?= $esc(t('snippets.events_adv.intro')) ?></p>
      <?php
      $snippet(
          t('snippets.events_adv.page'),
          $eventPageSnippet,
          t('snippets.events_adv.page_help')
      );
      $snippet(
          t('snippets.events_adv.fetch'),
          $eventFetchSnippet,
          t('snippets.events_adv.fetch_help'),
          'javascript'
      );
      $snippet(
          t('snippets.events_adv.guard'),
          $eventGuardSnippet,
          t('snippets.events_adv.guard_help'),
          'javascript'
      );
      ?>
    </div>
  </div>

<?php
$scripts = <<<'HTML'
<script src="../assets/vendor/highlight/highlight.min.js"></script>
<script>
  if (window.hljs) {
    document.querySelectorAll('.codebox pre code').forEach(function (el) {
      hljs.highlightElement(el);
    });
  }
</script>
HTML;

dashboard_layout_end($scripts);
