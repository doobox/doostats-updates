<?php

declare(strict_types=1);

require_once __DIR__ . '/_layout.php';

auth_boot();

if (!auth_is_configured()) {
    header('Location: ../setup.php');
    exit;
}

if (auth_is_logged_in()) {
    header('Location: index.php');
    exit;
}

$error = '';
$rateLimited = false;
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    if (!auth_check_csrf($_POST['csrf'] ?? null)) {
        $error = t('auth.login.error.csrf');
    } elseif (!auth_login_rate_ok()) {
        $rateLimited = true;
        $error = t('auth.login.error.rate_limit');
    } elseif (auth_attempt((string) ($_POST['password'] ?? ''))) {
        header('Location: index.php');
        exit;
    } else {
        $error = t('auth.login.error.incorrect');
    }
}

$cfg = analytics_config();
$brand = (string) ($cfg['brand_hex'] ?? doostats_brand_default());
$siteName = (string) ($cfg['site_name'] ?? t('nav.brand_fallback'));
$userName = trim((string) ($cfg['user_name'] ?? ''));
if ($userName === '') {
    $userName = t('nav.user_fallback');
}
$userName = mb_substr($userName, 0, 20);
$avatar = dashboard_avatar_file();
$avatarSrc = $avatar !== null ? 'avatar.php?v=' . (int) @filemtime($avatar) : '';
$csrf = auth_csrf_token();
$esc = static fn (string $v): string => htmlspecialchars($v, ENT_QUOTES, 'UTF-8');
?>
<!doctype html>
<html lang="<?= $esc(i18n_html_lang()) ?>"<?= doostats_ui_theme_html_attrs() ?>>
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="robots" content="noindex, nofollow" />
<title><?= $esc(t('auth.login.title')) ?></title>
<link rel="stylesheet" href="../assets/vendor/bootstrap/bootstrap.min.css" />
<link rel="stylesheet" href="../assets/app.css?v=<?= (int) @filemtime(__DIR__ . '/../assets/app.css') ?>" />
<?= doostats_brand_css_vars($brand) ?>
<?= doostats_ui_theme_boot_script() ?>
</head>
<body>
<div class="min-vh-100 d-flex align-items-center justify-content-center p-3">
  <div class="card shadow-sm w-100" style="max-width:360px">
    <div class="card-body p-4">
      <div class="d-flex align-items-center gap-3">
        <span class="avatar-badge login-avatar">
          <?php if ($avatarSrc !== ''): ?>
            <img src="<?= $esc($avatarSrc) ?>" alt="" />
          <?php else: ?>
            <?= DASHBOARD_AVATAR_SVG ?>
          <?php endif; ?>
        </span>
        <div class="lh-sm min-w-0">
          <h1 class="h4 mb-0"><?= $esc($userName) ?></h1>
          <p class="text-secondary small mb-0 text-truncate"><?= $esc($siteName) ?> <?= $esc(t('auth.login.subtitle_suffix')) ?></p>
        </div>
      </div>
      <?php if ($error !== ''): ?>
        <div class="alert alert-danger py-2 mt-4 mb-0"><?= $esc($error) ?></div>
      <?php endif; ?>
      <form class="my-4" method="post">
        <input type="hidden" name="csrf" value="<?= $esc($csrf) ?>" />
        <div class="mb-3">
          <label class="form-label" for="password"><?= $esc(t('auth.login.password')) ?></label>
          <input id="password" class="form-control" type="password" name="password" autofocus required<?= $rateLimited ? ' disabled' : '' ?> />
        </div>
        <button class="btn btn-primary w-100" type="submit"<?= $rateLimited ? ' disabled' : '' ?>><?= $esc(t('auth.login.submit')) ?></button>
      </form>
      <p class="text-center mb-0 small">
        <a href="forgot.php"><?= $esc(t('auth.login.forgot')) ?></a>
      </p>
    </div>
  </div>
</div>
</body>
</html>
