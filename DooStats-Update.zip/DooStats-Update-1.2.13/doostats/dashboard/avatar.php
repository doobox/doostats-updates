<?php

declare(strict_types=1);

/**
 * Streams the admin's custom avatar image. Available without login so the
 * sign-in screen can show it; the file is always a validated raster image and
 * is served with a fixed image content-type and nosniff, so it can never be
 * executed.
 */

require_once __DIR__ . '/_layout.php';

auth_boot();
if (!auth_is_configured()) {
    http_response_code(404);
    exit;
}

$path = dashboard_avatar_file();

// Release the session lock early so this image request never blocks page loads.
session_write_close();

if ($path === null) {
    http_response_code(404);
    exit;
}

$info = @getimagesize($path);
$mime = is_array($info) ? (string) ($info['mime'] ?? '') : '';
if (!in_array($mime, ['image/png', 'image/jpeg', 'image/gif', 'image/webp'], true)) {
    http_response_code(404);
    exit;
}

header('Content-Type: ' . $mime);
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, max-age=60');
header('Content-Length: ' . (string) filesize($path));
readfile($path);
