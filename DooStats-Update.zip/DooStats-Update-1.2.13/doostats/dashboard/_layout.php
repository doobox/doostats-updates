<?php

declare(strict_types=1);

/**
 * Shared dashboard chrome: <head>, top bar and account menu.
 *
 * To add a new page: create dashboard/yourpage.php, then add one line to
 * dashboard_nav_items() below and call dashboard_layout_start()/_end() around
 * your content. That is all the wiring a new page needs.
 */

require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/brand-palette.php';

// First-party inline icons (Bootstrap Icons, MIT). No icon font, no CDN.
const DASHBOARD_AVATAR_SVG = '<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 16 16" aria-hidden="true"><path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/><path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"/></svg>';
const DASHBOARD_ICON_DASHBOARD = '<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 16 16" aria-hidden="true"><path d="M4 11H2v3h2zm5-4H7v7h2zm5-5v12h-2V2zm-2-1a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1zM6 7a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v7a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1zm-5 4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1z"/></svg>';
const DASHBOARD_ICON_SNIPPETS = '<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 16 16" aria-hidden="true"><path d="M10.478 1.647a.5.5 0 1 0-.956-.294l-4 13a.5.5 0 0 0 .956.294zM4.854 4.146a.5.5 0 0 1 0 .708L1.707 8l3.147 3.146a.5.5 0 0 1-.708.708l-3.5-3.5a.5.5 0 0 1 0-.708l3.5-3.5a.5.5 0 0 1 .708 0m6.292 0a.5.5 0 0 0 0 .708L14.293 8l-3.147 3.146a.5.5 0 0 0 .708.708l3.5-3.5a.5.5 0 0 0 0-.708l-3.5-3.5a.5.5 0 0 0-.708 0"/></svg>';
const DASHBOARD_ICON_SETTINGS = '<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 16 16" aria-hidden="true"><path fill-rule="evenodd" d="M11.5 2a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3M9.05 3a2.5 2.5 0 0 1 4.9 0H16v1h-2.05a2.5 2.5 0 0 1-4.9 0H0V3zM4.5 7a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3M2.05 8a2.5 2.5 0 0 1 4.9 0H16v1H6.95a2.5 2.5 0 0 1-4.9 0H0V8zm9.45 4a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3m-2.45 1a2.5 2.5 0 0 1 4.9 0H16v1h-2.05a2.5 2.5 0 0 1-4.9 0H0v-1z"/></svg>';
const DASHBOARD_ICON_LOGOUT = '<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 16 16" aria-hidden="true"><path fill-rule="evenodd" d="M10 12.5a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v2a.5.5 0 0 0 1 0v-2A1.5 1.5 0 0 0 9.5 2h-8A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-2a.5.5 0 0 0-1 0z"/><path fill-rule="evenodd" d="M15.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 0 0-.708.708L14.293 7.5H5.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708z"/></svg>';

/**
 * Account-menu pages above Settings. Order here is the order shown. The array
 * key is the page's "active" identifier passed to dashboard_layout_start().
 *
 * @return array<string, array{label: string, href: string, icon: string}>
 */
function dashboard_nav_items(): array
{
    return [
        'dashboard' => ['label' => t('nav.dashboard'), 'href' => 'index.php', 'icon' => DASHBOARD_ICON_DASHBOARD],
        'snippets'  => ['label' => t('nav.snippets'),  'href' => 'snippets.php', 'icon' => DASHBOARD_ICON_SNIPPETS],
    ];
}

/**
 * Full filesystem path to the current custom avatar image, or null when none
 * is set (or the file is missing). basename() guards against path traversal.
 */
function dashboard_avatar_file(): ?string
{
    $cfg = analytics_config();
    $file = basename((string) ($cfg['avatar'] ?? ''));
    if ($file === '') {
        return null;
    }
    $dir = (string) ($cfg['data_dir'] ?? dirname(__DIR__) . '/data');
    $full = rtrim($dir, '/\\') . '/' . $file;
    return is_file($full) ? $full : null;
}

/**
 * Boot auth, bounce to setup/login when needed, and return common view data.
 *
 * @return array{cfg: array<string,mixed>, brand: string, site_name: string}
 */
function dashboard_guard(): array
{
    auth_boot();
    if (!auth_is_configured()) {
        header('Location: ../setup.php');
        exit;
    }
    auth_require_login();

    $cfg = analytics_config();
    $userName = trim((string) ($cfg['user_name'] ?? ''));
    return [
        'cfg' => $cfg,
        'brand' => (string) ($cfg['brand_hex'] ?? doostats_brand_default()),
        'site_name' => (string) ($cfg['site_name'] ?? t('nav.brand_fallback')),
        'user_name' => $userName !== '' ? $userName : t('nav.user_fallback'),
    ];
}

/**
 * Open the page: doctype, head, top bar with nav. Print your content after
 * this call, then finish with dashboard_layout_end().
 *
 * @param array{
 *   title?: string, active?: string, brand?: string, site_name?: string,
 *   subtitle?: string, actions?: string, head?: string
 * } $o
 */
function dashboard_layout_start(array $o): void
{
    $esc = static fn (string $v): string => htmlspecialchars($v, ENT_QUOTES, 'UTF-8');

    $title = (string) ($o['title'] ?? t('nav.brand_fallback'));
    $active = (string) ($o['active'] ?? '');
    $brand = (string) ($o['brand'] ?? doostats_brand_default());
    $siteName = (string) ($o['site_name'] ?? t('nav.brand_fallback'));
    $subtitle = (string) ($o['subtitle'] ?? '');
    $headExtra = (string) ($o['head'] ?? '');
    $avatar = array_key_exists('avatar_file', $o) ? $o['avatar_file'] : dashboard_avatar_file();
    $avatarSrc = is_string($avatar) && $avatar !== '' ? 'avatar.php?v=' . (int) @filemtime($avatar) : '';
    $userName = array_key_exists('user_name', $o)
        ? (string) $o['user_name']
        : trim((string) (analytics_config()['user_name'] ?? ''));
    if ($userName === '') {
        $userName = t('nav.user_fallback');
    }
    $userName = mb_substr($userName, 0, 20);

    $cssVer = (int) @filemtime(__DIR__ . '/../assets/app.css');
    ?>
<!doctype html>
<html lang="<?= $esc(i18n_html_lang()) ?>"<?= doostats_ui_theme_html_attrs() ?>>
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="robots" content="noindex, nofollow" />
<title><?= $esc(t('nav.title_suffix', ['title' => $title])) ?></title>
<link rel="stylesheet" href="../assets/vendor/bootstrap/bootstrap.min.css" />
<link rel="stylesheet" href="../assets/app.css?v=<?= $cssVer ?>" />
<?= doostats_brand_css_vars($brand) ?>
<?= doostats_ui_theme_boot_script() ?>
<?= $headExtra ?>
</head>
<body>
<nav class="navbar app-navbar mb-4">
  <div class="container app-container">
    <div class="navbar-brand d-flex flex-column lh-1 me-3 py-0">
      <span class="navbar-brand-title"><?= $esc($title) ?></span>
      <?php if ($subtitle !== ''): ?><small class="text-secondary mt-1"><?= $esc($subtitle) ?></small><?php endif; ?>
    </div>
    <div class="dropdown navbar-account ms-auto">
      <button class="btn usermenu-trigger d-inline-flex align-items-center gap-2 px-2" type="button" data-bs-toggle="dropdown" aria-expanded="false" aria-label="<?= $esc(t('nav.account_menu')) ?>">
        <span class="avatar-badge">
        <?php if ($avatarSrc !== ''): ?>
          <img src="<?= $esc($avatarSrc) ?>" alt="" />
        <?php else: ?>
          <?= DASHBOARD_AVATAR_SVG ?>
        <?php endif; ?>
        </span>
        <span class="usermenu-meta text-start lh-sm">
          <span class="usermenu-name d-block"><?= $esc($userName) ?></span>
          <span class="usermenu-sub d-block text-secondary small"><?= $esc(t('nav.account')) ?></span>
        </span>
      </button>
      <ul class="dropdown-menu dropdown-menu-end">
        <?php foreach (dashboard_nav_items() as $key => $item): ?>
          <li>
            <a class="dropdown-item d-flex align-items-center gap-2<?= $key === $active ? ' active' : '' ?>" href="<?= $esc($item['href']) ?>"<?= $key === $active ? ' aria-current="page"' : '' ?>>
              <?= $item['icon'] ?><span><?= $esc($item['label']) ?></span>
            </a>
          </li>
        <?php endforeach; ?>
        <li>
          <a class="dropdown-item d-flex align-items-center gap-2<?= $active === 'settings' ? ' active' : '' ?>" href="settings.php"<?= $active === 'settings' ? ' aria-current="page"' : '' ?>>
            <?= DASHBOARD_ICON_SETTINGS ?><span><?= $esc(t('nav.settings')) ?></span>
          </a>
        </li>
        <li><hr class="dropdown-divider"></li>
        <li>
          <a class="dropdown-item d-flex align-items-center gap-2" href="logout.php">
            <?= DASHBOARD_ICON_LOGOUT ?><span><?= $esc(t('nav.sign_out')) ?></span>
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<main class="container app-container pb-5">
<?php
}

/**
 * Close the page. Pass any page-specific <script> markup to have it emitted
 * just before </body>.
 */
function dashboard_layout_end(string $scripts = ''): void
{
    echo "</main>\n";
    ?>
<script src="../assets/vendor/bootstrap/bootstrap.bundle.min.js"></script>
<script>
(function () {
  var bar = document.querySelector('.app-navbar');
  if (!bar) return;
  function onScroll() { bar.classList.toggle('is-stuck', window.scrollY > 4); }
  onScroll();
  window.addEventListener('scroll', onScroll, { passive: true });
})();
</script>
<?php
    if ($scripts !== '') {
        echo $scripts . "\n";
    }
    echo "</body>\n</html>\n";
}
