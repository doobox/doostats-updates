<?php

declare(strict_types=1);

require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/update-check.php';

auth_boot();
if (!auth_is_configured()) {
    header('Location: ../setup.php');
    exit;
}
auth_require_login();

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    header('Location: index.php');
    exit;
}

if (!auth_check_csrf($_POST['csrf'] ?? null)) {
    header('Location: index.php');
    exit;
}

doostats_update_snooze();
header('Location: index.php');
exit;
