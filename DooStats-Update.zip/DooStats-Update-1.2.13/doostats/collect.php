<?php

declare(strict_types=1);

/**
 * Tracking beacon endpoint. Receives pageviews and events from tracker.js.
 * Always returns 204 and never throws, so it can never break a host page.
 */

require_once __DIR__ . '/lib/analytics.php';
require_once __DIR__ . '/lib/digest.php';

header('Cache-Control: no-store');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    http_response_code(405);
    exit;
}

$raw = file_get_contents('php://input') ?: '';
$data = json_decode($raw, true);
if (!is_array($data)) {
    $data = $_POST;
}

$type = (string) ($data['type'] ?? 'pageview');
$device = doostats_detect_device((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''));

try {
    if ($type === 'event') {
        analytics_record_event((string) ($data['name'] ?? ''));
    } elseif ($type === 'notfound') {
        analytics_record_not_found((string) ($data['path'] ?? '/'));
    } else {
        analytics_record_pageview(
            (string) ($data['path'] ?? '/'),
            $device,
            (string) ($data['referrer'] ?? '')
        );
    }
} catch (Throwable $e) {
    // Never surface tracking errors to the visitor.
}

// Finish the beacon first so digest mail never slows the visitor's page.
http_response_code(204);
header('Content-Length: 0');
header('Connection: close');
if (function_exists('fastcgi_finish_request')) {
    @fastcgi_finish_request();
} else {
    ignore_user_abort(true);
    while (ob_get_level() > 0) {
        @ob_end_flush();
    }
    @flush();
}

try {
    doostats_digest_maybe_send();
} catch (Throwable $e) {
    // Digest must never affect tracking.
}

function doostats_detect_device(string $ua): string
{
    $ua = strtolower($ua);
    if (preg_match('/ipad|tablet|playbook|silk|kindle/', $ua)) {
        return 'tablet';
    }
    if (preg_match('/android(?!.*mobile)/', $ua)) {
        return 'tablet';
    }
    if (preg_match('/mobile|iphone|ipod|android|blackberry|iemobile|opera mini|windows phone/', $ua)) {
        return 'mobile';
    }
    return 'desktop';
}
