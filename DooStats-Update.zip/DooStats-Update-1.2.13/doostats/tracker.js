/*
 * DooStats tracker. Add to any page, just before </body>:
 *   <script src="/stats/tracker.js" defer></script>
 *
 * Sends an anonymous pageview on load. For custom events, either add an
 * attribute to the element (no code) ...
 *   <button data-doostats-event="Signup">Sign up</button>
 *   <form data-doostats-event="Contact">...</form>   (records on submit)
 * ... or call the API from your own JavaScript:
 *   window.doostats.event('Signup');
 *
 * To track 404s, put the tracker on your custom error page with a data flag:
 *   <script src="/stats/tracker.js" data-doostats-404 defer></script>
 * Or keep the normal tracker in a shared template and mark the 404 page:
 *   <div data-doostats-404-page hidden></div>
 * Either way records the missing URL in the "Not found" report instead of a pageview.
 *
 * No cookies, no fingerprinting. The endpoint is resolved relative to this
 * script, so it works wherever you host the stats folder.
 */
(function () {
  'use strict';

  var script = document.currentScript;
  if (!script || !script.src) {
    return;
  }
  var base = script.src.replace(/tracker\.js(?:\?.*)?$/, '');
  var endpoint = base + 'collect.php';
  var isNotFound = script.hasAttribute('data-doostats-404')
    || !!document.querySelector('[data-doostats-404-page]');

  function send(payload) {
    try {
      var body = JSON.stringify(payload);
      if (navigator.sendBeacon) {
        navigator.sendBeacon(endpoint, new Blob([body], { type: 'application/json' }));
      } else {
        fetch(endpoint, {
          method: 'POST',
          body: body,
          headers: { 'Content-Type': 'application/json' },
          keepalive: true,
          credentials: 'omit',
        });
      }
    } catch (e) {
      // ignore
    }
  }

  function pageview() {
    send({ type: 'pageview', path: location.pathname, referrer: document.referrer || '' });
  }

  function notFound() {
    send({ type: 'notfound', path: location.pathname });
  }

  window.doostats = {
    pageview: pageview,
    notFound: notFound,
    event: function (name) {
      if (name) {
        send({ type: 'event', name: String(name) });
      }
    },
  };

  // Declarative events — no JavaScript to write. Add data-doostats-event="Name"
  // to any element and DooStats records that event automatically: forms record
  // on submit, everything else (links, buttons, ...) on click. Listeners are
  // delegated on the document, so elements added later still work.
  document.addEventListener('submit', function (evt) {
    var form = evt.target;
    if (form && form.getAttribute) {
      var name = form.getAttribute('data-doostats-event');
      if (name) {
        window.doostats.event(name);
      }
    }
  }, true);

  document.addEventListener('click', function (evt) {
    if (!evt.target || !evt.target.closest) {
      return;
    }
    var el = evt.target.closest('[data-doostats-event]');
    // Forms are handled by the submit listener above, so ignore them here to
    // avoid counting a submit-button click twice.
    if (el && el.tagName !== 'FORM') {
      window.doostats.event(el.getAttribute('data-doostats-event'));
    }
  }, true);

  if (isNotFound) {
    notFound();
  } else {
    pageview();
  }
})();
