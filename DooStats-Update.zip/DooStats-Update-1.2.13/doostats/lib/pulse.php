<?php

declare(strict_types=1);

/**
 * Public pulse counts for embeddable page markers (pulse.js).
 * Modes: online (≈5 min live), today, week. Aggregates only — no PII.
 */

require_once __DIR__ . '/analytics.php';
require_once __DIR__ . '/brand-palette.php';

const DOOSTATS_PULSE_LIVE_WINDOW = 300;
const DOOSTATS_PULSE_CACHE_ONLINE = 15;
const DOOSTATS_PULSE_CACHE_PERIOD = 60;
const DOOSTATS_PULSE_RATE_MAX = 120;
const DOOSTATS_PULSE_RATE_WINDOW = 60;

/**
 * @return 'online'|'today'|'week'
 */
function doostats_pulse_normalize_mode(string $mode): string
{
    $mode = strtolower(trim($mode));
    if ($mode === 'live' || $mode === 'online') {
        return 'online';
    }
    return in_array($mode, ['today', 'week'], true) ? $mode : 'online';
}

function doostats_pulse_data_dir(): string
{
    $cfg = analytics_config();
    return rtrim((string) ($cfg['data_dir'] ?? dirname(__DIR__) . '/data'), '/\\');
}

function doostats_pulse_cache_path(): string
{
    return doostats_pulse_data_dir() . '/pulse-cache.json';
}

function doostats_pulse_rate_path(): string
{
    return doostats_pulse_data_dir() . '/pulse-rate.json';
}

/**
 * @return array{count:int, mode:string, color:string}
 */
function doostats_pulse_payload(string $mode): array
{
    $mode = doostats_pulse_normalize_mode($mode);
    $cfg = analytics_config();
    $color = doostats_brand_normalize_hex((string) ($cfg['brand_hex'] ?? doostats_brand_default()));

    return [
        'count' => doostats_pulse_count($mode),
        'mode' => $mode,
        'color' => $color,
    ];
}

function doostats_pulse_count(string $mode): int
{
    $mode = doostats_pulse_normalize_mode($mode);
    if ($mode === 'online') {
        return (int) (analytics_active_visitors_summary(DOOSTATS_PULSE_LIVE_WINDOW)['total'] ?? 0);
    }
    $days = $mode === 'today' ? 1 : 7;
    $summary = analytics_dashboard_summary($days);
    return (int) ($summary['total_views'] ?? 0);
}

function doostats_pulse_cache_ttl(string $mode): int
{
    return doostats_pulse_normalize_mode($mode) === 'online'
        ? DOOSTATS_PULSE_CACHE_ONLINE
        : DOOSTATS_PULSE_CACHE_PERIOD;
}

/**
 * @return array{count:int, mode:string, color:string}|null
 */
function doostats_pulse_cache_read(string $mode): ?array
{
    $mode = doostats_pulse_normalize_mode($mode);
    $path = doostats_pulse_cache_path();
    if (!is_file($path)) {
        return null;
    }
    $raw = @file_get_contents($path);
    if ($raw === false || $raw === '') {
        return null;
    }
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        return null;
    }
    $entry = $data[$mode] ?? null;
    if (!is_array($entry)) {
        return null;
    }
    $at = (int) ($entry['at'] ?? 0);
    if ($at < 1 || (time() - $at) >= doostats_pulse_cache_ttl($mode)) {
        return null;
    }
    return [
        'count' => max(0, (int) ($entry['count'] ?? 0)),
        'mode' => $mode,
        'color' => (string) ($entry['color'] ?? doostats_brand_default()),
    ];
}

/**
 * @param array{count:int, mode:string, color:string} $payload
 */
function doostats_pulse_cache_write(array $payload): void
{
    $mode = doostats_pulse_normalize_mode((string) ($payload['mode'] ?? 'online'));
    $dir = doostats_pulse_data_dir();
    if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
        return;
    }
    $path = doostats_pulse_cache_path();
    $data = [];
    if (is_file($path)) {
        $raw = @file_get_contents($path);
        $decoded = is_string($raw) ? json_decode($raw, true) : null;
        if (is_array($decoded)) {
            $data = $decoded;
        }
    }
    $data[$mode] = [
        'at' => time(),
        'count' => max(0, (int) ($payload['count'] ?? 0)),
        'color' => (string) ($payload['color'] ?? doostats_brand_default()),
    ];
    $json = json_encode($data, JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        return;
    }
    $tmp = $path . '.' . bin2hex(random_bytes(4)) . '.tmp';
    if (@file_put_contents($tmp, $json) === false) {
        return;
    }
    @rename($tmp, $path);
}

function doostats_pulse_client_ip(): string
{
    return analytics_client_ip();
}

function doostats_pulse_rate_allow(?string $ip = null): bool
{
    $ip = $ip ?? doostats_pulse_client_ip();
    if ($ip === '') {
        $ip = 'unknown';
    }
    $bucket = hash('sha256', 'pulse|' . $ip);
    $dir = doostats_pulse_data_dir();
    if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
        return true;
    }
    $path = doostats_pulse_rate_path();
    $now = time();
    $data = [];
    if (is_file($path)) {
        $raw = @file_get_contents($path);
        $decoded = is_string($raw) ? json_decode($raw, true) : null;
        if (is_array($decoded)) {
            $data = $decoded;
        }
    }

    foreach ($data as $k => $row) {
        if (!is_array($row) || ($now - (int) ($row['start'] ?? 0)) >= DOOSTATS_PULSE_RATE_WINDOW * 2) {
            unset($data[$k]);
        }
    }

    $row = is_array($data[$bucket] ?? null) ? $data[$bucket] : ['start' => $now, 'count' => 0];
    $start = (int) ($row['start'] ?? $now);
    $count = (int) ($row['count'] ?? 0);
    if (($now - $start) >= DOOSTATS_PULSE_RATE_WINDOW) {
        $start = $now;
        $count = 0;
    }
    $count++;
    $data[$bucket] = ['start' => $start, 'count' => $count];

    $json = json_encode($data, JSON_UNESCAPED_SLASHES);
    if ($json !== false) {
        $tmp = $path . '.' . bin2hex(random_bytes(4)) . '.tmp';
        if (@file_put_contents($tmp, $json) !== false) {
            @rename($tmp, $path);
        }
    }

    return $count <= DOOSTATS_PULSE_RATE_MAX;
}

function doostats_pulse_apply_cors(): void
{
    $origin = trim((string) ($_SERVER['HTTP_ORIGIN'] ?? ''));
    if ($origin === '' || !analytics_host_allowed()) {
        return;
    }
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Vary: Origin');
    header('Access-Control-Allow-Methods: GET, OPTIONS');
    header('Access-Control-Allow-Headers: Accept');
    header('Access-Control-Max-Age: 600');
}
