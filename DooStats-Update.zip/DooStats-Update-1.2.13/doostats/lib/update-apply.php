<?php

declare(strict_types=1);

/**
 * One-click update: download the update zip from the feed URL, extract, and
 * merge product files over the install. Never writes config.php, data/, or
 * setup.php. Triggered only by a logged-in admin from Settings.
 */

require_once __DIR__ . '/analytics.php';
require_once __DIR__ . '/i18n.php';
require_once __DIR__ . '/update-check.php';

/** Fixed zip name published to the GitHub feed repo (latest only on main). */
const DOOSTATS_UPDATE_ZIP_FEED_NAME = 'DooStats-Update.zip';

function doostats_update_install_root(): string
{
    return dirname(__DIR__);
}

function doostats_update_data_dir(): string
{
    $cfg = analytics_config();
    return rtrim((string) ($cfg['data_dir'] ?? doostats_update_install_root() . '/data'), '/\\');
}

function doostats_update_work_dir(): string
{
    return doostats_update_data_dir() . '/updates';
}

function doostats_update_backup_dir(): string
{
    return doostats_update_data_dir() . '/backups';
}

/**
 * Whether this install can apply an update package in-place.
 *
 * @return array{ok: bool, message: string}
 */
function doostats_update_can_apply(): array
{
    if (!class_exists('ZipArchive')) {
        return ['ok' => false, 'message' => t('updates.apply.error.no_zip')];
    }
    $root = doostats_update_install_root();
    if (!is_dir($root) || !is_writable($root)) {
        return ['ok' => false, 'message' => t('updates.apply.error.not_writable')];
    }
    $data = doostats_update_data_dir();
    if (!is_dir($data) && !@mkdir($data, 0755, true) && !is_dir($data)) {
        return ['ok' => false, 'message' => t('updates.apply.error.not_writable')];
    }
    if (!is_writable($data)) {
        return ['ok' => false, 'message' => t('updates.apply.error.not_writable')];
    }
    return ['ok' => true, 'message' => ''];
}

/**
 * Download the latest update zip and merge it into the install.
 *
 * @return array{ok: bool, message: string, version: string}
 */
function doostats_update_apply_now(): array
{
    @set_time_limit(180);
    @ini_set('memory_limit', '256M');

    $empty = ['ok' => false, 'message' => '', 'version' => ''];

    $can = doostats_update_can_apply();
    if (!$can['ok']) {
        $empty['message'] = $can['message'];
        return $empty;
    }

    $check = doostats_check_for_updates();
    if (($check['status'] ?? '') !== 'update_available') {
        if (($check['status'] ?? '') === 'up_to_date') {
            $empty['message'] = $check['message'];
            $empty['version'] = (string) ($check['installed'] ?? '');
            return $empty;
        }
        $empty['message'] = (string) ($check['message'] ?: t('updates.apply.error.no_update'));
        return $empty;
    }

    $latest = trim((string) ($check['latest'] ?? ''));
    $url = trim((string) ($check['download_url'] ?? ''));
    if ($latest === '' || $url === '' || !preg_match('#^https://#i', $url)) {
        $empty['message'] = t('updates.error.no_download');
        return $empty;
    }

    $lock = doostats_update_acquire_lock();
    if ($lock === null) {
        $empty['message'] = t('updates.apply.error.busy');
        return $empty;
    }

    $work = null;
    $backup = null;
    try {
        $work = doostats_update_prepare_work_dir();
        if ($work === null) {
            return ['ok' => false, 'message' => t('updates.apply.error.workdir'), 'version' => ''];
        }

        $zipPath = $work . '/package.zip';
        if (!doostats_http_download($url, $zipPath)) {
            return ['ok' => false, 'message' => t('updates.apply.error.download'), 'version' => ''];
        }

        $extractDir = $work . '/extract';
        if (!@mkdir($extractDir, 0755, true) && !is_dir($extractDir)) {
            return ['ok' => false, 'message' => t('updates.apply.error.extract'), 'version' => ''];
        }

        $zip = new ZipArchive();
        $opened = $zip->open($zipPath);
        if ($opened !== true) {
            return ['ok' => false, 'message' => t('updates.apply.error.extract'), 'version' => ''];
        }
        if (!$zip->extractTo($extractDir)) {
            $zip->close();
            return ['ok' => false, 'message' => t('updates.apply.error.extract'), 'version' => ''];
        }
        $zip->close();

        $payload = doostats_update_find_payload($extractDir);
        if ($payload === null) {
            return ['ok' => false, 'message' => t('updates.apply.error.bad_package'), 'version' => ''];
        }

        $pkgVersion = doostats_update_read_payload_version($payload);
        if ($pkgVersion === '' || !preg_match('/^\d+\.\d+\.\d+/', $pkgVersion)) {
            return ['ok' => false, 'message' => t('updates.apply.error.bad_package'), 'version' => ''];
        }
        // Package should match the feed (allow equal or newer than announced).
        if (version_compare($pkgVersion, $latest) < 0) {
            return ['ok' => false, 'message' => t('updates.apply.error.version_mismatch'), 'version' => ''];
        }

        $files = doostats_update_list_payload_files($payload);
        if ($files === []) {
            return ['ok' => false, 'message' => t('updates.apply.error.bad_package'), 'version' => ''];
        }

        $root = doostats_update_install_root();
        $preflight = doostats_update_preflight($root, $files);
        if ($preflight !== null) {
            return ['ok' => false, 'message' => $preflight, 'version' => ''];
        }

        $from = doostats_installed_version()['version'];
        $backup = doostats_update_backup_dir() . '/' . preg_replace('/[^0-9A-Za-z._-]+/', '-', $from . '-to-' . $pkgVersion)
            . '-' . gmdate('Ymd\THis\Z');
        if (!doostats_update_backup_existing($root, $files, $backup)) {
            return ['ok' => false, 'message' => t('updates.apply.error.backup'), 'version' => ''];
        }

        $written = doostats_update_copy_payload($payload, $root, $files);
        if ($written === null) {
            doostats_update_restore_backup($backup, $root);
            return ['ok' => false, 'message' => t('updates.apply.error.copy'), 'version' => ''];
        }

        $installed = doostats_installed_version()['version'];
        if (version_compare($installed, $pkgVersion) < 0) {
            // VERSION.txt missing or stale — write the stamp the package should have left.
            $stamp = $pkgVersion . "\n" . gmdate('Y-m-d\TH:i:s\Z') . "\nupdate\n";
            if (@file_put_contents($root . '/VERSION.txt', $stamp) === false) {
                doostats_update_restore_backup($backup, $root);
                return ['ok' => false, 'message' => t('updates.apply.error.copy'), 'version' => ''];
            }
            $installed = $pkgVersion;
        }

        doostats_update_clear_opcache();
        doostats_update_prune_old_backups($backup);

        return [
            'ok' => true,
            'message' => t('updates.apply.ok', ['version' => $installed]),
            'version' => $installed,
        ];
    } finally {
        if (is_string($work) && $work !== '') {
            doostats_update_rm_tree($work);
        }
        doostats_update_release_lock($lock);
    }
}

/**
 * @return resource|null
 */
function doostats_update_acquire_lock()
{
    $dir = doostats_update_work_dir();
    if (!doostats_update_ensure_dir($dir)) {
        return null;
    }
    $path = $dir . '/apply.lock';
    $fh = @fopen($path, 'c+');
    if ($fh === false) {
        return null;
    }
    if (!flock($fh, LOCK_EX | LOCK_NB)) {
        fclose($fh);
        return null;
    }
    ftruncate($fh, 0);
    fwrite($fh, (string) getmypid());
    fflush($fh);
    return $fh;
}

/**
 * @param resource|null $fh
 */
function doostats_update_release_lock($fh): void
{
    if (!is_resource($fh)) {
        return;
    }
    flock($fh, LOCK_UN);
    fclose($fh);
}

function doostats_update_ensure_dir(string $dir): bool
{
    if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
        return false;
    }
    // Soften accidental web access on Apache hosts.
    if (!is_file($dir . '/.htaccess')) {
        @file_put_contents($dir . '/.htaccess', "Require all denied\n");
    }
    if (!is_file($dir . '/index.html')) {
        @file_put_contents($dir . '/index.html', '');
    }
    return is_writable($dir);
}

function doostats_update_prepare_work_dir(): ?string
{
    $base = doostats_update_work_dir();
    if (!doostats_update_ensure_dir($base)) {
        return null;
    }
    $dir = $base . '/job-' . bin2hex(random_bytes(6));
    if (!@mkdir($dir, 0755, true) && !is_dir($dir)) {
        return null;
    }
    return $dir;
}

/** Stream an HTTPS URL to a local file. Returns true on HTTP 2xx with a non-empty file. */
function doostats_http_download(string $url, string $destPath): bool
{
    if (!filter_var($url, FILTER_VALIDATE_URL) || !preg_match('#^https://#i', $url)) {
        return false;
    }

    $ua = 'DooStats/' . doostats_installed_version()['version'];

    if (function_exists('curl_init')) {
        $fh = @fopen($destPath, 'wb');
        if ($fh === false) {
            return false;
        }
        $ch = curl_init($url);
        if ($ch === false) {
            fclose($fh);
            @unlink($destPath);
            return false;
        }
        curl_setopt_array($ch, [
            CURLOPT_FILE => $fh,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT => 120,
            CURLOPT_USERAGENT => $ua,
        ]);
        if (defined('CURLPROTO_HTTPS')) {
            curl_setopt($ch, CURLOPT_PROTOCOLS, CURLPROTO_HTTPS);
            curl_setopt($ch, CURLOPT_REDIR_PROTOCOLS, CURLPROTO_HTTPS);
        }
        $ok = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        fclose($fh);
        if ($ok === false || $code < 200 || $code >= 300 || !is_file($destPath) || filesize($destPath) < 64) {
            @unlink($destPath);
            return false;
        }
        return true;
    }

    if (!ini_get('allow_url_fopen')) {
        return false;
    }

    $ctx = stream_context_create([
        'http' => [
            'method' => 'GET',
            'timeout' => 120,
            'header' => "User-Agent: {$ua}\r\n",
            'follow_location' => 1,
            'max_redirects' => 5,
        ],
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
        ],
    ]);
    $in = @fopen($url, 'rb', false, $ctx);
    if ($in === false) {
        return false;
    }
    $out = @fopen($destPath, 'wb');
    if ($out === false) {
        fclose($in);
        return false;
    }
    $copied = stream_copy_to_stream($in, $out);
    fclose($in);
    fclose($out);
    if ($copied === false || $copied < 64 || !is_file($destPath)) {
        @unlink($destPath);
        return false;
    }
    return true;
}

/** Locate the product folder inside an extracted update zip. */
function doostats_update_find_payload(string $extractDir): ?string
{
    $extractDir = rtrim($extractDir, '/\\');
    if (is_file($extractDir . '/VERSION.txt') && is_file($extractDir . '/index.php') && is_dir($extractDir . '/lib')) {
        return $extractDir;
    }

    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($extractDir, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    foreach ($it as $file) {
        if (!$file->isFile() || $file->getFilename() !== 'VERSION.txt') {
            continue;
        }
        $dir = $file->getPath();
        if (basename($dir) !== 'doostats') {
            continue;
        }
        if (is_file($dir . '/index.php') && is_dir($dir . '/lib')) {
            return $dir;
        }
    }
    return null;
}

function doostats_update_read_payload_version(string $payloadDir): string
{
    $path = $payloadDir . '/VERSION.txt';
    if (!is_file($path)) {
        return '';
    }
    $lines = preg_split("/\r\n|\n|\r/", trim((string) file_get_contents($path))) ?: [];
    $ver = trim((string) ($lines[0] ?? ''));
    return preg_match('/^\d+\.\d+\.\d+/', $ver) ? $ver : '';
}

/**
 * Relative file paths under the payload that are safe to install.
 *
 * @return list<string>
 */
function doostats_update_list_payload_files(string $payloadDir): array
{
    $payloadDir = rtrim($payloadDir, '/\\');
    $out = [];
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($payloadDir, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::LEAVES_ONLY
    );
    foreach ($it as $file) {
        if (!$file->isFile()) {
            continue;
        }
        $full = $file->getPathname();
        $rel = substr($full, strlen($payloadDir) + 1);
        $rel = str_replace('\\', '/', $rel);
        if ($rel === '' || !doostats_update_path_allowed($rel)) {
            continue;
        }
        $out[] = $rel;
    }
    sort($out);
    return $out;
}

/** Reject traversal, config/data/setup, and anything outside the product tree. */
function doostats_update_path_allowed(string $rel): bool
{
    $rel = str_replace('\\', '/', $rel);
    if ($rel === '' || str_starts_with($rel, '/') || str_contains($rel, "\0")) {
        return false;
    }
    $parts = explode('/', $rel);
    foreach ($parts as $part) {
        if ($part === '' || $part === '.' || $part === '..') {
            return false;
        }
    }
    $base = $parts[0];
    if ($base === 'data' || $base === 'config.php' || $base === 'setup.php') {
        return false;
    }
    if ($rel === 'config.php' || $rel === 'setup.php') {
        return false;
    }
    // Runtime / host-only files that must never be replaced from a package.
    if (preg_match('#(^|/)(config\.php|setup\.php)$#', $rel)) {
        return false;
    }
    if (str_starts_with($rel, 'data/')) {
        return false;
    }
    return true;
}

/**
 * @param list<string> $files
 */
function doostats_update_preflight(string $root, array $files): ?string
{
    $root = rtrim($root, '/\\');
    if (!is_writable($root)) {
        return t('updates.apply.error.not_writable');
    }
    foreach ($files as $rel) {
        $dest = $root . '/' . $rel;
        $dir = dirname($dest);
        if (is_file($dest)) {
            if (!is_writable($dest)) {
                return t('updates.apply.error.not_writable');
            }
            continue;
        }
        // Need to create parents — walk up until an existing dir.
        $check = $dir;
        while ($check !== $root && $check !== dirname($check) && !is_dir($check)) {
            $check = dirname($check);
        }
        if (!is_dir($check) || !is_writable($check)) {
            return t('updates.apply.error.not_writable');
        }
    }
    return null;
}

/**
 * @param list<string> $files
 */
function doostats_update_backup_existing(string $root, array $files, string $backupDir): bool
{
    $root = rtrim($root, '/\\');
    if (!doostats_update_ensure_dir(dirname($backupDir)) || !@mkdir($backupDir, 0755, true) && !is_dir($backupDir)) {
        return false;
    }
    foreach ($files as $rel) {
        $src = $root . '/' . $rel;
        if (!is_file($src)) {
            continue;
        }
        $dest = $backupDir . '/' . $rel;
        $dir = dirname($dest);
        if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
            return false;
        }
        if (!@copy($src, $dest)) {
            return false;
        }
    }
    @file_put_contents($backupDir . '/MANIFEST.txt', implode("\n", $files) . "\n");
    return true;
}

function doostats_update_restore_backup(string $backupDir, string $root): void
{
    $backupDir = rtrim($backupDir, '/\\');
    $root = rtrim($root, '/\\');
    if ($backupDir === '' || !is_dir($backupDir)) {
        return;
    }
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($backupDir, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::LEAVES_ONLY
    );
    foreach ($it as $file) {
        if (!$file->isFile()) {
            continue;
        }
        $full = $file->getPathname();
        $rel = substr($full, strlen($backupDir) + 1);
        $rel = str_replace('\\', '/', $rel);
        if ($rel === 'MANIFEST.txt' || !doostats_update_path_allowed($rel)) {
            continue;
        }
        $dest = $root . '/' . $rel;
        $dir = dirname($dest);
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        @copy($full, $dest);
    }
}

/**
 * Copy payload files into the install. Returns the count written, or null on failure.
 *
 * @param list<string> $files
 */
function doostats_update_copy_payload(string $payloadDir, string $root, array $files): ?int
{
    $payloadDir = rtrim($payloadDir, '/\\');
    $root = rtrim($root, '/\\');
    $count = 0;
    foreach ($files as $rel) {
        $src = $payloadDir . '/' . $rel;
        $dest = $root . '/' . $rel;
        if (!is_file($src)) {
            return null;
        }
        $dir = dirname($dest);
        if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
            return null;
        }
        $tmp = $dest . '.' . bin2hex(random_bytes(4)) . '.tmp';
        if (!@copy($src, $tmp)) {
            @unlink($tmp);
            return null;
        }
        if (!@rename($tmp, $dest)) {
            // Windows may need unlink-first when replacing.
            if (is_file($dest)) {
                @unlink($dest);
            }
            if (!@rename($tmp, $dest)) {
                @unlink($tmp);
                return null;
            }
        }
        $count++;
    }
    return $count;
}

function doostats_update_clear_opcache(): void
{
    if (function_exists('opcache_reset')) {
        @opcache_reset();
    }
}

function doostats_update_prune_old_backups(string $keepDir): void
{
    $base = doostats_update_backup_dir();
    if (!is_dir($base)) {
        return;
    }
    $keep = realpath($keepDir) ?: $keepDir;
    foreach (scandir($base) ?: [] as $name) {
        if ($name === '.' || $name === '..' || $name === '.htaccess' || $name === 'index.html') {
            continue;
        }
        $path = $base . '/' . $name;
        if (!is_dir($path)) {
            continue;
        }
        $real = realpath($path) ?: $path;
        if ($real === $keep) {
            continue;
        }
        doostats_update_rm_tree($path);
    }
}

function doostats_update_rm_tree(string $dir): void
{
    if ($dir === '' || !is_dir($dir)) {
        return;
    }
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($it as $file) {
        if ($file->isDir()) {
            @rmdir($file->getPathname());
        } else {
            @unlink($file->getPathname());
        }
    }
    @rmdir($dir);
}

/**
 * Default raw URL for the update zip on the public feed repo.
 * Override per-release via appcast downloads.update.
 */
function doostats_update_zip_feed_url(): string
{
    return 'https://raw.githubusercontent.com/doobox/doostats-updates/main/' . DOOSTATS_UPDATE_ZIP_FEED_NAME;
}
