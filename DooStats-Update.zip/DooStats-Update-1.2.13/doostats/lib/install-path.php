<?php

declare(strict_types=1);

/**
 * URL path of the uploaded DooStats folder (e.g. "/doostats" or "" at domain root).
 *
 * Site URL is the website being tracked (https://example.com). This path is
 * where the DooStats folder was uploaded. Default snippets use a same-origin
 * relative URL so www / non-www never cross origins:
 *   /doostats/tracker.js
 *
 * By default the path is detected from the current request (setup, dashboard,
 * collect). Optional override: set install_path in config.php (not shown in
 * Settings — auto-detect covers normal installs and renames).
 */

function doostats_normalize_install_path(string $path): string
{
    $path = trim($path);
    if ($path === '' || $path === '/') {
        return '';
    }
    if ($path[0] !== '/') {
        $path = '/' . $path;
    }

    return rtrim($path, '/');
}

/**
 * Infer the install path from a script URL path.
 *
 * Returns null when there is nothing to detect (e.g. CLI with no SCRIPT_NAME).
 * Returns "" when DooStats is at the domain root.
 */
function doostats_detect_install_path(?string $scriptName = null): ?string
{
    $scriptName = str_replace('\\', '/', trim((string) ($scriptName ?? ($_SERVER['SCRIPT_NAME'] ?? ''))));
    if ($scriptName === '') {
        return null;
    }

    // dashboard/*.php → install root is one level up
    if (str_contains($scriptName, '/dashboard/')) {
        $path = dirname(dirname($scriptName));
    } else {
        // setup.php, collect.php, index.php, track.php, notfound.php, pulse.php at install root
        $path = dirname($scriptName);
    }

    if ($path === '.' || $path === '/' || $path === '\\') {
        return '';
    }

    return doostats_normalize_install_path($path);
}

/**
 * Install path for snippets and docs.
 * Prefer a non-empty Settings override; otherwise use live detection; else /doostats.
 */
function doostats_install_path(): string
{
    $cfg = analytics_config();
    if (!empty($cfg['install_path'])) {
        return doostats_normalize_install_path((string) $cfg['install_path']);
    }

    $detected = doostats_detect_install_path();
    if ($detected !== null) {
        return $detected;
    }

    return '/doostats';
}

/**
 * Best-effort public site origin from the current request (scheme + host).
 * Used to pre-fill setup. Does not include the DooStats folder path.
 */
function doostats_detect_site_url(): string
{
    $host = trim((string) ($_SERVER['HTTP_HOST'] ?? ''));
    if ($host === '') {
        $host = trim((string) ($_SERVER['SERVER_NAME'] ?? ''));
    }
    if ($host === '') {
        return '';
    }

    $forwarded = strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? ''));
    $https = $forwarded === 'https'
        || (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || ((string) ($_SERVER['SERVER_PORT'] ?? '') === '443');

    return ($https ? 'https' : 'http') . '://' . $host;
}

/**
 * Same-origin relative URL to tracker.js for snippet copy/paste.
 * Matches the page host automatically (www vs apex).
 */
function doostats_tracker_src(): string
{
    return doostats_install_path() . '/tracker.js';
}
