<?php

declare(strict_types=1);

require_once __DIR__ . '/i18n.php';

/**
 * Installed version + update check against a public appcast JSON.
 * Manual check from Settings, plus a quiet cached check for the dashboard banner.
 */

/**
 * Default feed URL. Hosted on GitHub raw so the check never touches the doobox
 * host (whose Imunify360 bot-protection can block shared-hosting IPs). A copy is
 * still published to doobox for installs shipped before the feed moved.
 * Override with update_feed_url in config.php if needed.
 */
const DOOSTATS_UPDATE_FEED_DEFAULT = 'https://raw.githubusercontent.com/doobox/doostats-updates/main/appcast.json';

/**
 * Stable download page when the feed check fails (opens in the admin's browser).
 * Built as Updates/download.html next to the versioned update zip.
 */
const DOOSTATS_UPDATE_FALLBACK_PAGE = 'https://www.doobox.co.uk/sparkle/doostats/Updates/download.html';

/** Public changelog always linked from Settings → Updates. */
const DOOSTATS_UPDATE_CHANGELOG_URL = 'https://www.doobox.co.uk/sparkle/doostats/Updates/CHANGELOG.html';

/** How often the background / Settings cache may hit the feed (seconds). */
const DOOSTATS_UPDATE_CHECK_INTERVAL = 86400;

/** “Remind me later” snooze length (seconds). */
const DOOSTATS_UPDATE_SNOOZE_SECONDS = 86400;

/**
 * Whether quiet dashboard/Settings checks may hit the feed.
 * Default on when the config key is missing (existing installs).
 */
function doostats_auto_check_updates_enabled(?array $cfg = null): bool
{
    $cfg = $cfg ?? (function_exists('analytics_config') ? analytics_config() : []);
    if (!array_key_exists('auto_check_updates', $cfg)) {
        return true;
    }
    return !empty($cfg['auto_check_updates']);
}

function doostats_version_file(): string
{
    return dirname(__DIR__) . '/VERSION.txt';
}

function doostats_update_fallback_page_url(): string
{
    return DOOSTATS_UPDATE_FALLBACK_PAGE;
}

function doostats_update_changelog_url(): string
{
    return DOOSTATS_UPDATE_CHANGELOG_URL;
}

/**
 * @return array{version: string, built: string, kind: string}
 */
function doostats_installed_version(): array
{
    $path = doostats_version_file();
    $version = '0.0.0';
    $built = '';
    $kind = 'install';

    if (is_file($path)) {
        $lines = preg_split("/\r\n|\n|\r/", trim((string) file_get_contents($path))) ?: [];
        if (isset($lines[0]) && preg_match('/^\d+\.\d+\.\d+/', trim($lines[0]))) {
            $version = trim($lines[0]);
        }
        if (isset($lines[1])) {
            $built = trim($lines[1]);
        }
        if (isset($lines[2]) && strtolower(trim($lines[2])) === 'update') {
            $kind = 'update';
        }
    }

    return [
        'version' => $version,
        'built' => $built,
        'kind' => $kind,
    ];
}

/**
 * Format a VERSION.txt build stamp for display only.
 * Storage stays ISO-8601 UTC (e.g. 2026-07-20T18:43:00Z); display uses the site timezone.
 */
function doostats_format_built_at(string $built): string
{
    $built = trim($built);
    if ($built === '') {
        return '';
    }

    try {
        $dt = new DateTimeImmutable($built);
    } catch (Exception $e) {
        return $built;
    }

    $tz = function_exists('analytics_timezone')
        ? analytics_timezone()
        : new DateTimeZone('UTC');

    // Midnight UTC stamps are date-only; check before converting to the site zone.
    $utcMidnight = $dt->setTimezone(new DateTimeZone('UTC'))->format('H:i:s') === '00:00:00';
    $dt = $dt->setTimezone($tz);

    if ($utcMidnight) {
        return i18n_format_date($dt, 'date', $tz);
    }

    return i18n_format_date($dt, 'datetime', $tz);
}

function doostats_update_feed_url(): string
{
    $cfg = function_exists('analytics_config') ? analytics_config() : [];
    $url = trim((string) ($cfg['update_feed_url'] ?? ''));
    if ($url !== '' && filter_var($url, FILTER_VALIDATE_URL)) {
        return $url;
    }

    return DOOSTATS_UPDATE_FEED_DEFAULT;
}

/**
 * Fetch the appcast and compare with the installed version.
 *
 * @return array{
 *   ok: bool,
 *   status: 'up_to_date'|'update_available'|'error',
 *   message: string,
 *   installed: string,
 *   latest: string,
 *   notes: string,
 *   download_url: string,
 *   changelog_url: string
 * }
 */
function doostats_check_for_updates(): array
{
    $installed = doostats_installed_version();
    $empty = [
        'ok' => false,
        'status' => 'error',
        'message' => '',
        'installed' => $installed['version'],
        'latest' => '',
        'notes' => '',
        'download_url' => '',
        'changelog_url' => '',
    ];

    $feedUrl = doostats_update_feed_url();
    $raw = doostats_http_get($feedUrl);
    if ($raw === null) {
        $empty['message'] = t('updates.error.unreachable');
        return $empty;
    }

    $data = json_decode($raw, true);
    if (!is_array($data)) {
        $empty['message'] = t('updates.error.invalid_json');
        return $empty;
    }

    $stable = $data['channels']['stable'] ?? null;
    if (!is_array($stable)) {
        // Allow a flat feed: { "version": "1.1.0", "downloads": { "update": "…" } }
        $stable = $data;
    }

    $latest = trim((string) ($stable['version'] ?? $data['latest'] ?? ''));
    if ($latest === '' || !preg_match('/^\d+\.\d+\.\d+/', $latest)) {
        $empty['message'] = t('updates.error.no_version');
        return $empty;
    }

    $downloads = is_array($stable['downloads'] ?? null) ? $stable['downloads'] : [];
    $downloadUrl = trim((string) ($downloads['update'] ?? $downloads['install'] ?? ''));
    $notes = trim((string) ($stable['notes'] ?? ''));
    $changelogUrl = trim((string) ($stable['changelog_url'] ?? ''));

    $cmp = version_compare($installed['version'], $latest);
    if ($cmp >= 0) {
        return [
            'ok' => true,
            'status' => 'up_to_date',
            'message' => t('updates.up_to_date', ['version' => $installed['version']]),
            'installed' => $installed['version'],
            'latest' => $latest,
            'notes' => $notes,
            'download_url' => $downloadUrl,
            'changelog_url' => $changelogUrl,
        ];
    }

    return [
        'ok' => true,
        'status' => 'update_available',
        'message' => t('updates.available', [
            'latest' => $latest,
            'installed' => $installed['version'],
        ]),
        'installed' => $installed['version'],
        'latest' => $latest,
        'notes' => $notes,
        'download_url' => $downloadUrl,
        'changelog_url' => $changelogUrl,
    ];
}

/**
 * Client-facing update result: same as doostats_check_for_updates() but the
 * real zip URL is replaced with has_download so it never appears in HTML/JSON.
 * can_apply is true when this host can run the in-app installer.
 *
 * @param array{
 *   ok: bool,
 *   status: string,
 *   message: string,
 *   installed: string,
 *   latest: string,
 *   notes: string,
 *   download_url: string,
 *   changelog_url: string
 * } $result
 * @return array{
 *   ok: bool,
 *   status: string,
 *   message: string,
 *   installed: string,
 *   latest: string,
 *   notes: string,
 *   changelog_url: string,
 *   has_download: bool,
 *   can_apply: bool
 * }
 */
function doostats_public_update_result(array $result): array
{
    $out = $result;
    $out['has_download'] = trim((string) ($result['download_url'] ?? '')) !== '';
    unset($out['download_url']);

    $canApply = false;
    if (($out['status'] ?? '') === 'update_available' && $out['has_download']) {
        if (!function_exists('doostats_update_can_apply')) {
            require_once __DIR__ . '/update-apply.php';
        }
        $canApply = doostats_update_can_apply()['ok'];
    }
    $out['can_apply'] = $canApply;
    return $out;
}

/** Best-effort GET with a short timeout. Returns body or null. */
function doostats_http_get(string $url): ?string
{
    if (!filter_var($url, FILTER_VALIDATE_URL) || !preg_match('#^https?://#i', $url)) {
        return null;
    }

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        if ($ch === false) {
            return null;
        }
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 3,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_USERAGENT => 'DooStats/' . doostats_installed_version()['version'],
            CURLOPT_HTTPHEADER => ['Accept: application/json'],
        ]);
        $body = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($body === false || $code < 200 || $code >= 300) {
            return null;
        }
        return (string) $body;
    }

    if (!ini_get('allow_url_fopen')) {
        return null;
    }

    $ctx = stream_context_create([
        'http' => [
            'method' => 'GET',
            'timeout' => 10,
            'header' => "Accept: application/json\r\nUser-Agent: DooStats/" . doostats_installed_version()['version'] . "\r\n",
        ],
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
        ],
    ]);
    $body = @file_get_contents($url, false, $ctx);
    return $body === false ? null : (string) $body;
}

function doostats_update_status_path(): string
{
    $cfg = function_exists('analytics_config') ? analytics_config() : [];
    $dir = rtrim((string) ($cfg['data_dir'] ?? dirname(__DIR__) . '/data'), '/\\');
    return $dir . '/update-status.json';
}

/**
 * @return array{checked_at: string, remind_after: string, result: ?array<string, mixed>}
 */
function doostats_update_status_read(): array
{
    $empty = [
        'checked_at' => '',
        'remind_after' => '',
        'result' => null,
    ];
    $path = doostats_update_status_path();
    if (!is_file($path)) {
        return $empty;
    }
    $raw = @file_get_contents($path);
    if ($raw === false || $raw === '') {
        return $empty;
    }
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        return $empty;
    }
    $result = $data['result'] ?? null;
    return [
        'checked_at' => trim((string) ($data['checked_at'] ?? '')),
        'remind_after' => trim((string) ($data['remind_after'] ?? '')),
        'result' => is_array($result) ? $result : null,
    ];
}

/**
 * @param array{checked_at?: string, remind_after?: string, result?: ?array<string, mixed>} $state
 */
function doostats_update_status_write(array $state): bool
{
    $path = doostats_update_status_path();
    $dir = dirname($path);
    if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
        return false;
    }
    $payload = [
        'checked_at' => trim((string) ($state['checked_at'] ?? '')),
        'remind_after' => trim((string) ($state['remind_after'] ?? '')),
        'result' => is_array($state['result'] ?? null) ? $state['result'] : null,
    ];
    $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    if ($json === false) {
        return false;
    }
    $tmp = $path . '.' . bin2hex(random_bytes(4)) . '.tmp';
    if (file_put_contents($tmp, $json . "\n", LOCK_EX) === false) {
        @unlink($tmp);
        return false;
    }
    if (!@rename($tmp, $path)) {
        @unlink($tmp);
        return false;
    }
    return true;
}

/**
 * Persist a fresh check result. Clears snooze when no update is available.
 *
 * @param array<string, mixed> $result from doostats_check_for_updates()
 */
function doostats_update_store_check_result(array $result): void
{
    $state = doostats_update_status_read();
    $state['checked_at'] = gmdate('c');
    $state['result'] = [
        'ok' => !empty($result['ok']),
        'status' => (string) ($result['status'] ?? 'error'),
        'message' => (string) ($result['message'] ?? ''),
        'installed' => (string) ($result['installed'] ?? ''),
        'latest' => (string) ($result['latest'] ?? ''),
        'notes' => (string) ($result['notes'] ?? ''),
        'download_url' => (string) ($result['download_url'] ?? ''),
        'changelog_url' => (string) ($result['changelog_url'] ?? ''),
    ];
    if (($state['result']['status'] ?? '') !== 'update_available') {
        $state['remind_after'] = '';
    }
    doostats_update_status_write($state);
}

function doostats_update_is_snoozed(?array $state = null): bool
{
    $state = $state ?? doostats_update_status_read();
    $until = trim((string) ($state['remind_after'] ?? ''));
    if ($until === '') {
        return false;
    }
    try {
        $dt = new DateTimeImmutable($until);
    } catch (Exception $e) {
        return false;
    }
    return $dt->getTimestamp() > time();
}

/** Snooze the dashboard banner for DOOSTATS_UPDATE_SNOOZE_SECONDS. */
function doostats_update_snooze(int $seconds = DOOSTATS_UPDATE_SNOOZE_SECONDS): bool
{
    if ($seconds < 60) {
        $seconds = DOOSTATS_UPDATE_SNOOZE_SECONDS;
    }
    $state = doostats_update_status_read();
    $state['remind_after'] = gmdate('c', time() + $seconds);
    return doostats_update_status_write($state);
}

function doostats_update_cache_is_fresh(?array $state = null): bool
{
    $state = $state ?? doostats_update_status_read();
    $checked = trim((string) ($state['checked_at'] ?? ''));
    $result = $state['result'] ?? null;
    if ($checked === '' || !is_array($result)) {
        return false;
    }
    // VERSION.txt changed since the last check (e.g. local test rollback) — refresh.
    $cachedInstalled = trim((string) ($result['installed'] ?? ''));
    if ($cachedInstalled !== '' && $cachedInstalled !== doostats_installed_version()['version']) {
        return false;
    }
    try {
        $dt = new DateTimeImmutable($checked);
    } catch (Exception $e) {
        return false;
    }
    return (time() - $dt->getTimestamp()) < DOOSTATS_UPDATE_CHECK_INTERVAL;
}

/**
 * Return a cached check as a public result, or null.
 *
 * @return array<string, mixed>|null
 */
function doostats_update_cached_public_result(): ?array
{
    $state = doostats_update_status_read();
    $result = $state['result'] ?? null;
    if (!is_array($result) || ($result['status'] ?? '') === '') {
        return null;
    }
    return doostats_public_update_result($result);
}

/**
 * Refresh the feed when the cache is stale (or $force). Never throws.
 *
 * @return array<string, mixed> public update result
 */
function doostats_update_refresh_if_stale(bool $force = false): array
{
    $state = doostats_update_status_read();
    if (!$force && doostats_update_cache_is_fresh($state)) {
        $cached = doostats_update_cached_public_result();
        if ($cached !== null) {
            return $cached;
        }
    }

    try {
        $result = doostats_check_for_updates();
        doostats_update_store_check_result($result);
        return doostats_public_update_result($result);
    } catch (Throwable $e) {
        $cached = doostats_update_cached_public_result();
        if ($cached !== null) {
            return $cached;
        }
        return doostats_public_update_result([
            'ok' => false,
            'status' => 'error',
            'message' => t('updates.error.failed'),
            'installed' => doostats_installed_version()['version'],
            'latest' => '',
            'notes' => '',
            'download_url' => '',
            'changelog_url' => '',
        ]);
    }
}

/**
 * Dashboard banner payload when an update is available and not snoozed.
 *
 * @return array{latest: string, installed: string, message: string, notes: string}|null
 */
function doostats_update_banner(): ?array
{
    if (!doostats_auto_check_updates_enabled()) {
        return null;
    }
    try {
        $public = doostats_update_refresh_if_stale(false);
    } catch (Throwable $e) {
        return null;
    }
    if (($public['status'] ?? '') !== 'update_available') {
        return null;
    }
    if (doostats_update_is_snoozed()) {
        return null;
    }
    return [
        'latest' => (string) ($public['latest'] ?? ''),
        'installed' => (string) ($public['installed'] ?? ''),
        'message' => (string) ($public['message'] ?? ''),
        'notes' => (string) ($public['notes'] ?? ''),
    ];
}
