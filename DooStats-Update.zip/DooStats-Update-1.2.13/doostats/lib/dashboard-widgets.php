<?php

declare(strict_types=1);

/**
 * Dashboard card visibility. Cards default to visible; Settings stores a list
 * of hidden ids in config.php as dashboard_hidden.
 */

/**
 * Ordered registry of hideable dashboard cards.
 * label_key → i18n string for Settings checkboxes.
 *
 * @return list<array{id:string,label_key:string}>
 */
function doostats_dashboard_widgets(): array
{
    return [
        ['id' => 'summary_metrics', 'label_key' => 'settings.general.widget.summary_metrics'],
        ['id' => 'daily_traffic', 'label_key' => 'settings.general.widget.daily_traffic'],
        ['id' => 'devices', 'label_key' => 'settings.general.widget.devices'],
        ['id' => 'performance', 'label_key' => 'settings.general.widget.performance'],
        ['id' => 'pages_per_visitor', 'label_key' => 'settings.general.widget.pages_per_visitor'],
        ['id' => 'top_browsers', 'label_key' => 'settings.general.widget.top_browsers'],
        ['id' => 'peak_times', 'label_key' => 'settings.general.widget.peak_times'],
        ['id' => 'live_visitors', 'label_key' => 'settings.general.widget.live_visitors'],
        ['id' => 'visitors_by_country', 'label_key' => 'settings.general.widget.visitors_by_country'],
        ['id' => 'top_pages', 'label_key' => 'settings.general.widget.top_pages'],
        ['id' => 'top_referrers', 'label_key' => 'settings.general.widget.top_referrers'],
        ['id' => 'events', 'label_key' => 'settings.general.widget.events'],
        ['id' => 'not_found', 'label_key' => 'settings.general.widget.not_found'],
    ];
}

/** @return list<string> */
function doostats_dashboard_widget_ids(): array
{
    return array_column(doostats_dashboard_widgets(), 'id');
}

/**
 * Cards that only appear when Process visitor IP is on.
 *
 * @return list<string>
 */
function doostats_dashboard_widgets_require_ip(): array
{
    return ['pages_per_visitor', 'live_visitors', 'visitors_by_country'];
}

/**
 * Widgets offered in Settings for the current config (IP-only cards omitted
 * when visitor IP processing is off — those panels are already unavailable).
 *
 * @param array<string, mixed>|null $cfg
 * @return list<array{id:string,label_key:string}>
 */
function doostats_dashboard_widgets_for_settings(?array $cfg = null): array
{
    $cfg ??= function_exists('analytics_config') ? analytics_config() : [];
    $needIp = array_flip(doostats_dashboard_widgets_require_ip());
    $ipOn = function_exists('analytics_process_visitor_ip')
        ? analytics_process_visitor_ip()
        : !empty($cfg['process_visitor_ip']);

    $out = [];
    foreach (doostats_dashboard_widgets() as $widget) {
        if (!$ipOn && isset($needIp[$widget['id']])) {
            continue;
        }
        $out[] = $widget;
    }

    return $out;
}

/**
 * @param array<string, mixed>|null $cfg
 * @return list<string>
 */
function doostats_dashboard_hidden(?array $cfg = null): array
{
    $cfg ??= function_exists('analytics_config') ? analytics_config() : [];
    $raw = $cfg['dashboard_hidden'] ?? [];
    if (!is_array($raw)) {
        return [];
    }
    $allowed = array_flip(doostats_dashboard_widget_ids());
    $hidden = [];
    foreach ($raw as $id) {
        $id = trim((string) $id);
        if ($id !== '' && isset($allowed[$id])) {
            $hidden[] = $id;
        }
    }

    return array_values(array_unique($hidden));
}

function doostats_dashboard_widget_visible(string $id, ?array $cfg = null): bool
{
    return !in_array($id, doostats_dashboard_hidden($cfg), true);
}

/**
 * Normalize a posted list of visible widget ids into dashboard_hidden.
 * Only ids offered in Settings are updated; others keep their previous state
 * (so IP-only cards are not wiped when Process visitor IP is off).
 *
 * @param mixed $postedVisible checkbox values (widget ids that should stay visible)
 * @param array<string, mixed>|null $cfg
 * @return list<string>
 */
function doostats_dashboard_hidden_from_visible_post(mixed $postedVisible, ?array $cfg = null): array
{
    $cfg ??= function_exists('analytics_config') ? analytics_config() : [];
    $offered = array_column(doostats_dashboard_widgets_for_settings($cfg), 'id');
    $offeredFlip = array_flip($offered);

    $visible = [];
    if (is_array($postedVisible)) {
        foreach ($postedVisible as $id) {
            $id = trim((string) $id);
            if ($id !== '' && isset($offeredFlip[$id])) {
                $visible[$id] = true;
            }
        }
    }

    $prevHidden = array_flip(doostats_dashboard_hidden($cfg));
    $hidden = [];
    foreach (doostats_dashboard_widget_ids() as $id) {
        if (isset($offeredFlip[$id])) {
            if (!isset($visible[$id])) {
                $hidden[] = $id;
            }
        } elseif (isset($prevHidden[$id])) {
            $hidden[] = $id;
        }
    }

    return $hidden;
}
