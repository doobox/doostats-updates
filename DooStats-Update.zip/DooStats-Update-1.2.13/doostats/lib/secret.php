<?php

declare(strict_types=1);

/**
 * Reversible secrets for values that must be recovered at runtime (e.g. SMTP
 * password). Dashboard passwords stay one-way hashed elsewhere.
 *
 * Stored form: enc:v1:<base64(iv + tag + ciphertext)> using AES-256-GCM.
 * Key is derived from the install salt. Anyone who can read config.php can
 * still decrypt; this mainly stops casual plaintext exposure in the file.
 */

const DOOSTATS_SECRET_PREFIX = 'enc:v1:';

function doostats_secret_key(): string
{
    $salt = '';
    if (function_exists('analytics_salt')) {
        $salt = analytics_salt();
    } elseif (function_exists('analytics_config')) {
        $salt = (string) (analytics_config()['salt'] ?? '');
    }
    if ($salt === '') {
        $salt = 'change-me-in-config';
    }
    return hash('sha256', 'doostats-secret|' . $salt, true);
}

function doostats_secret_is_encrypted(string $stored): bool
{
    return str_starts_with($stored, DOOSTATS_SECRET_PREFIX);
}

/**
 * Encrypt a plaintext secret for storage. Empty string stays empty.
 */
function doostats_secret_encrypt(string $plain): string
{
    if ($plain === '') {
        return '';
    }
    if (!function_exists('openssl_encrypt')) {
        return $plain;
    }

    $iv = random_bytes(12);
    $tag = '';
    $cipher = openssl_encrypt(
        $plain,
        'aes-256-gcm',
        doostats_secret_key(),
        OPENSSL_RAW_DATA,
        $iv,
        $tag,
        '',
        16
    );
    if ($cipher === false || $tag === '') {
        return $plain;
    }

    return DOOSTATS_SECRET_PREFIX . base64_encode($iv . $tag . $cipher);
}

/**
 * Decrypt a stored secret. Legacy plaintext (no enc:v1: prefix) is returned as-is.
 */
function doostats_secret_decrypt(string $stored): string
{
    if ($stored === '' || !doostats_secret_is_encrypted($stored)) {
        return $stored;
    }
    if (!function_exists('openssl_decrypt')) {
        return '';
    }

    $raw = base64_decode(substr($stored, strlen(DOOSTATS_SECRET_PREFIX)), true);
    if ($raw === false || strlen($raw) < 28) {
        return '';
    }

    $iv = substr($raw, 0, 12);
    $tag = substr($raw, 12, 16);
    $cipher = substr($raw, 28);
    $plain = openssl_decrypt(
        $cipher,
        'aes-256-gcm',
        doostats_secret_key(),
        OPENSSL_RAW_DATA,
        $iv,
        $tag
    );

    return $plain === false ? '' : $plain;
}
