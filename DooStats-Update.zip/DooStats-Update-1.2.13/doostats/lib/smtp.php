<?php

declare(strict_types=1);

require_once __DIR__ . '/i18n.php';

/**
 * Minimal SMTP client for digest emails. No Composer — stream sockets only.
 * Supports AUTH LOGIN, STARTTLS (tls), implicit SSL (ssl), and plain (none).
 */

/**
 * @return array{ok: bool, message: string}
 */
function doostats_smtp_send(
    string $host,
    int $port,
    string $encryption,
    string $username,
    string $password,
    string $from,
    string $to,
    string $subject,
    string $headers,
    string $body,
    int $timeout = 20
): array {
    $host = trim($host);
    $encryption = strtolower(trim($encryption));
    if (!in_array($encryption, ['tls', 'ssl', 'none'], true)) {
        $encryption = 'tls';
    }
    $from = trim($from);
    $to = trim($to);
    $username = trim($username);

    if ($host === '' || $port < 1 || $port > 65535) {
        return ['ok' => false, 'message' => t('settings.reports.error.smtp_host')];
    }
    if ($from === '' || !filter_var($from, FILTER_VALIDATE_EMAIL)) {
        return ['ok' => false, 'message' => t('settings.reports.error.smtp_from')];
    }
    if ($to === '' || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
        return ['ok' => false, 'message' => t('settings.reports.error.email')];
    }
    if ($username === '' || $password === '') {
        return ['ok' => false, 'message' => t('settings.reports.error.smtp_auth')];
    }
    if ($encryption !== 'none' && !extension_loaded('openssl')) {
        return ['ok' => false, 'message' => t('settings.reports.error.smtp_openssl')];
    }

    $remote = ($encryption === 'ssl' ? 'ssl://' : 'tcp://') . $host . ':' . $port;
    $errno = 0;
    $errstr = '';
    $ctx = stream_context_create([
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
            'SNI_enabled' => true,
            'peer_name' => $host,
        ],
    ]);
    $fp = @stream_socket_client($remote, $errno, $errstr, $timeout, STREAM_CLIENT_CONNECT, $ctx);
    if ($fp === false) {
        return [
            'ok' => false,
            'message' => t('settings.reports.error.smtp_connect', [
                'detail' => trim($errstr !== '' ? $errstr : ('#' . $errno)),
            ]),
        ];
    }
    stream_set_timeout($fp, $timeout);

    try {
        $greet = doostats_smtp_expect($fp, [220]);
        if ($greet['ok'] === false) {
            return $greet;
        }

        $ehloHost = doostats_smtp_ehlo_name();
        $ehlo = doostats_smtp_command($fp, 'EHLO ' . $ehloHost, [250]);
        if ($ehlo['ok'] === false) {
            $ehlo = doostats_smtp_command($fp, 'HELO ' . $ehloHost, [250]);
            if ($ehlo['ok'] === false) {
                return $ehlo;
            }
        }

        if ($encryption === 'tls') {
            $start = doostats_smtp_command($fp, 'STARTTLS', [220]);
            if ($start['ok'] === false) {
                return $start;
            }
            $crypto = @stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
            if ($crypto !== true) {
                return ['ok' => false, 'message' => t('settings.reports.error.smtp_tls')];
            }
            $ehlo = doostats_smtp_command($fp, 'EHLO ' . $ehloHost, [250]);
            if ($ehlo['ok'] === false) {
                return $ehlo;
            }
        }

        $auth = doostats_smtp_command($fp, 'AUTH LOGIN', [334]);
        if ($auth['ok'] === false) {
            return ['ok' => false, 'message' => t('settings.reports.error.smtp_auth_failed')];
        }
        $userResp = doostats_smtp_command($fp, base64_encode($username), [334]);
        if ($userResp['ok'] === false) {
            return ['ok' => false, 'message' => t('settings.reports.error.smtp_auth_failed')];
        }
        $passResp = doostats_smtp_command($fp, base64_encode($password), [235]);
        if ($passResp['ok'] === false) {
            return ['ok' => false, 'message' => t('settings.reports.error.smtp_auth_failed')];
        }

        $mailFrom = doostats_smtp_command($fp, 'MAIL FROM:<' . $from . '>', [250]);
        if ($mailFrom['ok'] === false) {
            return $mailFrom;
        }
        $rcpt = doostats_smtp_command($fp, 'RCPT TO:<' . $to . '>', [250, 251]);
        if ($rcpt['ok'] === false) {
            return $rcpt;
        }
        $data = doostats_smtp_command($fp, 'DATA', [354]);
        if ($data['ok'] === false) {
            return $data;
        }

        $subjectSafe = str_replace(["\r", "\n"], '', $subject);
        $message = 'Subject: ' . $subjectSafe . "\r\n"
            . 'To: <' . $to . ">\r\n"
            . rtrim(doostats_smtp_normalize_crlf($headers), "\r\n") . "\r\n"
            . "\r\n"
            . doostats_smtp_dot_stuff($body)
            . "\r\n.";

        $sent = doostats_smtp_command($fp, $message, [250]);
        if ($sent['ok'] === false) {
            return $sent;
        }

        doostats_smtp_command($fp, 'QUIT', [221]);
        return ['ok' => true, 'message' => ''];
    } finally {
        fclose($fp);
    }
}

function doostats_smtp_ehlo_name(): string
{
    $host = trim((string) ($_SERVER['SERVER_NAME'] ?? ''));
    if ($host === '' || filter_var($host, FILTER_VALIDATE_IP)) {
        $host = 'localhost';
    }
    return preg_replace('/[^\w.\-]/', '', $host) ?: 'localhost';
}

/** Normalise any newline style to CRLF without doubling existing CRLFs. */
function doostats_smtp_normalize_crlf(string $text): string
{
    $text = str_replace(["\r\n", "\r"], "\n", $text);
    return str_replace("\n", "\r\n", $text);
}

/** Dot-stuff lines that begin with "." per RFC 5321. */
function doostats_smtp_dot_stuff(string $body): string
{
    $body = doostats_smtp_normalize_crlf($body);
    return (string) preg_replace('/^\./m', '..', $body);
}

/**
 * @param resource $fp
 * @param list<int> $expect
 * @return array{ok: bool, message: string, code?: int, text?: string}
 */
function doostats_smtp_command($fp, string $command, array $expect): array
{
    if (@fwrite($fp, $command . "\r\n") === false) {
        return ['ok' => false, 'message' => t('settings.reports.error.smtp_io')];
    }
    return doostats_smtp_expect($fp, $expect);
}

/**
 * @param resource $fp
 * @param list<int> $expect
 * @return array{ok: bool, message: string, code?: int, text?: string}
 */
function doostats_smtp_expect($fp, array $expect): array
{
    $text = '';
    $code = 0;
    while (($line = @fgets($fp, 515)) !== false) {
        $text .= $line;
        if (preg_match('/^(\d{3})([\- ])/', $line, $m) !== 1) {
            continue;
        }
        $code = (int) $m[1];
        if ($m[2] === ' ') {
            break;
        }
    }
    if ($code === 0) {
        $meta = stream_get_meta_data($fp);
        if (!empty($meta['timed_out'])) {
            return ['ok' => false, 'message' => t('settings.reports.error.smtp_timeout')];
        }
        return ['ok' => false, 'message' => t('settings.reports.error.smtp_io')];
    }
    if (!in_array($code, $expect, true)) {
        $detail = trim(preg_replace('/^\d{3}[\- ]?/m', '', $text) ?? '');
        if (strlen($detail) > 160) {
            $detail = substr($detail, 0, 157) . '…';
        }
        return [
            'ok' => false,
            'message' => t('settings.reports.error.smtp_reject', [
                'code' => (string) $code,
                'detail' => $detail !== '' ? $detail : (string) $code,
            ]),
            'code' => $code,
            'text' => $text,
        ];
    }
    return ['ok' => true, 'message' => '', 'code' => $code, 'text' => $text];
}
