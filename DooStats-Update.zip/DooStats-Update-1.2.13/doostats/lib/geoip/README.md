# IP-to-country database

`ip-country.dat` is a compact binary IP-to-country lookup, and `countries.php`
holds country names and approximate centroids used to place dots on the map.

## Source and licence

`ip-country.dat` is built from the five Regional Internet Registry (RIR)
"delegated extended" statistics files (ARIN, RIPE NCC, APNIC, LACNIC, AFRINIC).
These are free public data with no attribution requirement, which is why
DooStats can ship a country-level GeoIP database with no third-party licence
obligation and make zero external calls at runtime.

Accuracy is country-level only, which is all the dashboard needs.

## Rebuilding

To refresh the data (the RIRs publish daily):

```bash
php scripts/build-geoip-rir.php
```

That downloads the current RIR files and overwrites `ip-country.dat`. To build
from files you have already downloaded, pass a directory containing
`delegated-<rir>-extended-latest`:

```bash
php scripts/build-geoip-rir.php /path/to/rir-files
```

`countries.php` ships with the package and rarely needs changing.
