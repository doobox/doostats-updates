<?php
declare(strict_types=1);

/**
 * Resolve the visitor IP and whether the request is from local dev (Cursor / php -S).
 *
 * By default only REMOTE_ADDR is used. Set trust_proxy in config.php when the
 * site runs behind Cloudflare, nginx, or another reverse proxy that sets
 * X-Forwarded-For / CF-Connecting-IP correctly.
 */
function request_client_ip(): string
{
    if (!request_trust_proxy()) {
        return request_first_valid_ip((string) ($_SERVER['REMOTE_ADDR'] ?? ''));
    }

    $directHeaders = [
        'HTTP_CF_CONNECTING_IP',
        'HTTP_TRUE_CLIENT_IP',
        'HTTP_X_REAL_IP',
        'HTTP_CLIENT_IP',
        'HTTP_X_CLUSTER_CLIENT_IP',
    ];

    foreach ($directHeaders as $header) {
        $ip = request_first_valid_ip((string) ($_SERVER[$header] ?? ''));
        if ($ip !== '') {
            return $ip;
        }
    }

    foreach (['HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED'] as $header) {
        $value = (string) ($_SERVER[$header] ?? '');
        if ($value === '') {
            continue;
        }

        $ips = array_map('trim', explode(',', $value));
        foreach ($ips as $ip) {
            if (request_is_public_ip($ip)) {
                return $ip;
            }
        }

        foreach ($ips as $ip) {
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
    }

    return request_first_valid_ip((string) ($_SERVER['REMOTE_ADDR'] ?? ''));
}

/**
 * Whether forwarded IP headers may be trusted. Default false (safe on plain hosting).
 */
function request_trust_proxy(): bool
{
    static $trust = null;
    if ($trust !== null) {
        return $trust;
    }

    $path = dirname(__DIR__) . '/config.php';
    if (!is_file($path)) {
        $trust = false;
        return false;
    }

    $cfg = require $path;
    $trust = is_array($cfg) && !empty($cfg['trust_proxy']);
    return $trust;
}

function request_first_valid_ip(string $value): string
{
    $value = trim(explode(',', $value)[0]);
    if ($value !== '' && filter_var($value, FILTER_VALIDATE_IP)) {
        return $value;
    }

    return '';
}

function request_is_public_ip(string $ip): bool
{
    return $ip !== ''
        && filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false;
}

function request_is_local_dev_hostname(): bool
{
    $host = strtolower((string) ($_SERVER['HTTP_HOST'] ?? ''));

    return $host === 'localhost'
        || str_starts_with($host, 'localhost:')
        || str_starts_with($host, '127.0.0.1');
}

function request_is_private_ip(string $ip): bool
{
    return $ip !== '' && !filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE);
}
