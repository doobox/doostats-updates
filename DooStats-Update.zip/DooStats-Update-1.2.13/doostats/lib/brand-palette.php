<?php

declare(strict_types=1);

require_once __DIR__ . '/i18n.php';

/**
 * Brand colour palette. The product stores a plain hex string in config.
 * The UI offers Tailwind CSS "500" accents plus a Custom picker for any hex:
 * https://tailwindcss.com/docs/colors
 */

/** @return array<string, string> lowercase hex => display name */
function doostats_brand_palette(): array
{
    return [
        '#ef4444' => 'Red',
        '#f97316' => 'Orange',
        '#f59e0b' => 'Amber',
        '#eab308' => 'Yellow',
        '#84cc16' => 'Lime',
        '#22c55e' => 'Green',
        '#10b981' => 'Emerald',
        '#14b8a6' => 'Teal',
        '#06b6d4' => 'Cyan',
        '#0ea5e9' => 'Sky',
        '#3b82f6' => 'Blue',
        '#6366f1' => 'Indigo',
        '#8b5cf6' => 'Violet',
        '#a855f7' => 'Purple',
        '#d946ef' => 'Fuchsia',
        '#ec4899' => 'Pink',
        '#f43f5e' => 'Rose',
    ];
}

/** The default accent used for new installs and as a fallback (Tailwind blue-500). */
function doostats_brand_default(): string
{
    return '#3b82f6';
}

/**
 * Soft tint of a hex for --brand-weak.
 */
function doostats_brand_weak_rgba(string $hex, float $alpha = 0.12): string
{
    $rgb = sscanf(strtolower(trim($hex)), '#%02x%02x%02x');
    if (!is_array($rgb) || count($rgb) !== 3) {
        $rgb = [59, 130, 246];
    }
    return sprintf('rgba(%d, %d, %d, %.2f)', $rgb[0], $rgb[1], $rgb[2], $alpha);
}

/**
 * Inline <style> that sets --brand / --brand-weak from the stored hex.
 */
function doostats_brand_css_vars(string $hex): string
{
    $brand = strtolower(trim($hex));
    if ($brand === '' || !preg_match('/^#[0-9a-f]{6}$/', $brand)) {
        $brand = doostats_brand_default();
    }
    $esc = static fn (string $s): string => htmlspecialchars($s, ENT_QUOTES, 'UTF-8');

    return '<style>'
        . ':root{'
        . '--brand:' . $esc($brand) . ';'
        . '--brand-weak:' . $esc(doostats_brand_weak_rgba($brand)) . ';'
        . '}'
        . '</style>';
}

/** Localised display name for a palette English label (e.g. Red → t(settings.brand.red)). */
function doostats_brand_label(string $englishName): string
{
    return t('settings.brand.' . strtolower($englishName));
}

/** Human-readable name for a hex value, or "Custom" if outside the palette. */
function doostats_brand_name(string $hex): string
{
    $english = doostats_brand_palette()[strtolower(trim($hex))] ?? 'Custom';
    return doostats_brand_label($english);
}

/**
 * Normalise a hex for the colour picker / hidden input. Falls back to default.
 */
function doostats_brand_normalize_hex(string $hex): string
{
    $hex = strtolower(trim($hex));
    if ($hex !== '' && preg_match('/^#[0-9a-f]{6}$/', $hex)) {
        return $hex;
    }
    return doostats_brand_default();
}

/**
 * Render the colour <select> replacement: palette swatches plus an always-on
 * Custom option with a native colour picker. A hidden input still submits the
 * raw hex so Settings / Setup save paths stay unchanged.
 */
function doostats_brand_select_html(string $currentHex, string $fieldId = 'brand_hex'): string
{
    $palette = doostats_brand_palette();
    $current = doostats_brand_normalize_hex($currentHex);
    $isCustom = !isset($palette[$current]);
    $currentName = doostats_brand_label($isCustom ? 'Custom' : $palette[$current]);
    $customHex = $isCustom ? $current : doostats_brand_default();
    $esc = static fn (string $s): string => htmlspecialchars($s, ENT_QUOTES, 'UTF-8');

    $btnId = $fieldId . '_btn';
    $listId = $fieldId . '_list';
    $pickerId = $fieldId . '_picker';

    ob_start();
    ?>
    <div class="colorselect" data-colorselect>
      <input type="hidden" name="<?= $esc($fieldId) ?>" id="<?= $esc($fieldId) ?>" value="<?= $esc($current) ?>" />
      <div class="colorselect-field">
        <button type="button" class="colorselect-trigger" id="<?= $esc($btnId) ?>" aria-haspopup="listbox" aria-expanded="false" aria-controls="<?= $esc($listId) ?>">
          <span class="swatch" data-swatch style="background: <?= $esc($current) ?>"></span>
          <span class="colorselect-name" data-name><?= $esc($currentName) ?></span>
          <svg class="colorselect-caret" width="12" height="12" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M4 6l4 4 4-4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </button>
        <ul class="colorselect-list" id="<?= $esc($listId) ?>" role="listbox" tabindex="-1" hidden>
          <li class="colorselect-option" role="option" data-custom="1" data-value="<?= $esc($customHex) ?>" aria-selected="<?= $isCustom ? 'true' : 'false' ?>" tabindex="-1">
            <span class="swatch" data-custom-swatch style="background: <?= $esc($customHex) ?>"></span>
            <span><?= $esc(doostats_brand_label('Custom')) ?></span>
          </li>
          <?php foreach ($palette as $hex => $name): ?>
            <li class="colorselect-option" role="option" data-value="<?= $esc($hex) ?>" aria-selected="<?= (!$isCustom && $hex === $current) ? 'true' : 'false' ?>" tabindex="-1">
              <span class="swatch" style="background: <?= $esc($hex) ?>"></span>
              <span><?= $esc(doostats_brand_label($name)) ?></span>
            </li>
          <?php endforeach; ?>
        </ul>
      </div>
      <div class="colorselect-custom" data-custom-row<?= $isCustom ? '' : ' hidden' ?>>
        <label class="colorselect-custom-label" for="<?= $esc($pickerId) ?>">
          <input type="color" id="<?= $esc($pickerId) ?>" class="colorselect-picker" data-custom-picker value="<?= $esc($customHex) ?>" />
          <span class="colorselect-custom-hex" data-custom-hex><?= $esc($customHex) ?></span>
        </label>
      </div>
    </div>
    <?php
    return (string) ob_get_clean();
}

/** One-time client script that powers every [data-colorselect] on the page. */
function doostats_brand_select_script(): string
{
    return <<<'HTML'
<script>
(function () {
  function brandWeak(hex) {
    var m = /^#([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return 'rgba(59, 130, 246, 0.12)';
    var n = parseInt(m[1], 16);
    return 'rgba(' + ((n >> 16) & 255) + ', ' + ((n >> 8) & 255) + ', ' + (n & 255) + ', 0.12)';
  }

  function applyBrand(hex) {
    if (!/^#[0-9a-f]{6}$/i.test(hex)) return;
    document.documentElement.style.setProperty('--brand', hex);
    document.documentElement.style.setProperty('--brand-weak', brandWeak(hex));
  }

  document.querySelectorAll('[data-colorselect]').forEach(function (root) {
    var btn = root.querySelector('.colorselect-trigger');
    var list = root.querySelector('.colorselect-list');
    var input = root.querySelector('input[type=hidden]');
    var nameEl = root.querySelector('[data-name]');
    var swatchEl = root.querySelector('[data-swatch]');
    var customRow = root.querySelector('[data-custom-row]');
    var picker = root.querySelector('[data-custom-picker]');
    var customHexEl = root.querySelector('[data-custom-hex]');
    var customSwatch = root.querySelector('[data-custom-swatch]');
    var customOpt = root.querySelector('.colorselect-option[data-custom="1"]');
    var options = Array.prototype.slice.call(root.querySelectorAll('.colorselect-option'));
    if (!btn || !list || !input) return;

    function open() {
      list.hidden = false;
      btn.setAttribute('aria-expanded', 'true');
      var sel = list.querySelector('[aria-selected="true"]') || options[0];
      if (sel) sel.focus();
    }
    function close() {
      list.hidden = true;
      btn.setAttribute('aria-expanded', 'false');
    }
    function setCustomVisible(on) {
      if (!customRow) return;
      customRow.hidden = !on;
    }
    function applyCustomHex(hex) {
      hex = String(hex || '').toLowerCase();
      if (!/^#[0-9a-f]{6}$/.test(hex)) return;
      input.value = hex;
      if (swatchEl) swatchEl.style.background = hex;
      if (picker) picker.value = hex;
      if (customHexEl) customHexEl.textContent = hex;
      if (customSwatch) customSwatch.style.background = hex;
      if (customOpt) customOpt.setAttribute('data-value', hex);
      if (nameEl && customOpt) {
        var label = customOpt.querySelector('span:last-child');
        if (label) nameEl.textContent = label.textContent;
      }
      applyBrand(hex);
    }
    function choose(opt) {
      options.forEach(function (o) { o.setAttribute('aria-selected', o === opt ? 'true' : 'false'); });
      var isCustom = opt.getAttribute('data-custom') === '1';
      setCustomVisible(isCustom);
      if (isCustom) {
        applyCustomHex(picker ? picker.value : opt.getAttribute('data-value'));
      } else {
        var value = opt.getAttribute('data-value');
        input.value = value;
        if (swatchEl) swatchEl.style.background = value;
        if (nameEl) {
          var label = opt.querySelector('span:last-child');
          if (label) nameEl.textContent = label.textContent;
        }
        applyBrand(value);
      }
      close();
      btn.focus();
    }

    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      if (list.hidden) { open(); } else { close(); }
    });
    options.forEach(function (opt) {
      opt.addEventListener('click', function (e) { e.stopPropagation(); choose(opt); });
    });
    if (picker) {
      picker.addEventListener('input', function () {
        if (customOpt) {
          options.forEach(function (o) {
            o.setAttribute('aria-selected', o === customOpt ? 'true' : 'false');
          });
        }
        setCustomVisible(true);
        applyCustomHex(picker.value);
      });
      picker.addEventListener('click', function (e) { e.stopPropagation(); });
    }
    list.addEventListener('keydown', function (e) {
      var i = options.indexOf(document.activeElement);
      if (e.key === 'ArrowDown') { e.preventDefault(); (options[i + 1] || options[0]).focus(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); (options[i - 1] || options[options.length - 1]).focus(); }
      else if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); if (options[i]) choose(options[i]); }
      else if (e.key === 'Escape') { e.preventDefault(); close(); btn.focus(); }
    });
    document.addEventListener('click', function (e) {
      if (!list.hidden && !root.contains(e.target)) close();
    });
  });
})();
</script>
HTML;
}
