<?php

declare(strict_types=1);

require_once __DIR__ . '/analytics.php';

/**
 * Minimal session-based auth for the dashboard. Single admin, password hashed
 * in config.php (bcrypt). No users table, no cookies beyond the session.
 */

function auth_boot(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_name('doostats');
        session_set_cookie_params([
            'httponly' => true,
            'samesite' => 'Lax',
            'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
        ]);
        session_start();
    }
}

/**
 * Release the session lock early. PHP's default (file) session handler holds an
 * exclusive lock on the session file for the whole request. On read-only pages
 * (the dashboard and its 15s live-visitor poll) everything needed from
 * $_SESSION has already been read once auth is checked, so closing the session
 * here lets concurrent requests in the same session run in parallel instead of
 * queueing behind each other — which is what makes a reload occasionally hang
 * while a live poll is still in flight.
 */
function auth_release_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }
}

function auth_is_configured(): bool
{
    $hash = (string) (analytics_config()['admin_password_hash'] ?? '');
    return $hash !== '';
}

function auth_is_logged_in(): bool
{
    auth_boot();
    return !empty($_SESSION['doostats_authed']);
}

function auth_attempt(string $password): bool
{
    $hash = (string) (analytics_config()['admin_password_hash'] ?? '');
    if ($hash === '' || !password_verify($password, $hash)) {
        return false;
    }
    auth_boot();
    session_regenerate_id(true);
    $_SESSION['doostats_authed'] = true;
    return true;
}

/**
 * Per-IP budget for dashboard sign-in attempts (5 per 15 minutes).
 * Uses the shared SQLite rate_limits table; the IP is hashed so raw addresses
 * are not stored. Call before auth_attempt() so locked-out IPs never hit bcrypt.
 */
function auth_login_rate_ok(): bool
{
    $ip = analytics_client_ip();
    if ($ip === '') {
        $ip = 'unknown';
    }
    $bucket = 'login:' . hash('sha256', $ip . '|' . analytics_salt());
    return analytics_rate_limit_ok($bucket, 5, 15 * 60);
}

/**
 * Verify a password against the stored hash without logging in. Used by the
 * settings page to confirm the current password before allowing a change.
 */
function auth_verify_password(string $password): bool
{
    $hash = (string) (analytics_config()['admin_password_hash'] ?? '');
    return $hash !== '' && password_verify($password, $hash);
}

function auth_logout(): void
{
    auth_boot();
    $_SESSION = [];
    session_destroy();
}

function auth_require_login(): void
{
    if (!auth_is_logged_in()) {
        header('Location: login.php');
        exit;
    }
}

/** CSRF token for the login form. */
function auth_csrf_token(): string
{
    auth_boot();
    if (empty($_SESSION['doostats_csrf'])) {
        $_SESSION['doostats_csrf'] = bin2hex(random_bytes(16));
    }
    return (string) $_SESSION['doostats_csrf'];
}

function auth_check_csrf(?string $token): bool
{
    auth_boot();
    $expected = (string) ($_SESSION['doostats_csrf'] ?? '');
    return $expected !== '' && is_string($token) && hash_equals($expected, $token);
}
