DooStats language packs
=======================

English (lib/lang/en.php) is the source of truth for keys. Missing keys in any
other pack fall back to English.

Dates, hours (24h on charts), country names, numbers, and percents follow the
active language code (ui_language) via PHP intl when available — packs do not
need to translate digit shapes, the % symbol, or clock hour style.

Shipped packs (product)
-----------------------
Packs that ship with DooStats live in lib/lang/ (next to en.php). Product
updates replace that folder, so do not put your own translations there.

  en English
  de Deutsch
  fr Français
  ja 日本語
  es Español
  zh-hans 简体中文
  it Italiano
  pt-br Português (Brasil)
  ko 한국어
  nl Nederlands
  zh-hant 繁體中文
  pl Polski
  sv Svenska

Codes are lowercase (pt-br, zh-hans, zh-hant). Filenames must match.

Your own packs (survive updates)
--------------------------------
Put custom language files in data/lang/ instead, e.g. data/lang/fr.php.

  1. Copy lib/lang/en.php to data/lang/fr.php (where fr = should be your chosen language code).
  2. Set _meta.name (e.g. "Français").
  3. Translate the string values. Keep every key identical.
  4. Apostrophes in values must be escaped: host\'s
  5. Placeholders look like {count} or {version} — keep them in the translation.
  6. Choose the language in Settings → General (or during setup).

Create data/lang/ if it does not exist (same permissions as data/). A pack in
data/lang/ with the same code as a shipped pack overrides the shipped one.

The Language selector only appears when more than one pack is installed.
Do not edit lib/lang/en.php for a custom language — updates overwrite it.
