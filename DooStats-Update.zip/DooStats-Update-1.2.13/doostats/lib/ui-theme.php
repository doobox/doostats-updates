<?php

declare(strict_types=1);

/**
 * UI colour theme: light, dark, or system (follow OS preference).
 * Applied via Bootstrap 5.3 data-bs-theme on <html>.
 */

/** @return list<string> */
function doostats_ui_theme_values(): array
{
    return ['light', 'dark', 'system'];
}

function doostats_ui_theme_default(): string
{
    return 'system';
}

/**
 * Configured theme preference (light|dark|system).
 */
function doostats_ui_theme(?array $cfg = null): string
{
    if ($cfg === null) {
        $cfg = function_exists('analytics_config') ? analytics_config() : [];
    }
    // Existing installs without ui_theme stay light; new setup defaults to system.
    if (!array_key_exists('ui_theme', $cfg)) {
        return 'light';
    }
    $theme = strtolower(trim((string) $cfg['ui_theme']));
    return in_array($theme, doostats_ui_theme_values(), true) ? $theme : doostats_ui_theme_default();
}

/**
 * Attributes for the <html> tag: data-bs-theme and/or data-ui-theme=system.
 */
function doostats_ui_theme_html_attrs(?array $cfg = null): string
{
    $theme = doostats_ui_theme($cfg);
    if ($theme === 'system') {
        return ' data-ui-theme="system"';
    }
    return ' data-bs-theme="' . htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') . '"';
}

/**
 * Early <head> script so "system" resolves before first paint (avoids a flash).
 * Also listens for OS preference changes.
 */
function doostats_ui_theme_boot_script(?array $cfg = null): string
{
    if (doostats_ui_theme($cfg) !== 'system') {
        return '';
    }

    return <<<'HTML'
<script>
(function () {
  var root = document.documentElement;
  function apply() {
    root.setAttribute(
      'data-bs-theme',
      window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
    );
  }
  apply();
  try {
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', apply);
  } catch (e) {}
})();
</script>
HTML;
}
