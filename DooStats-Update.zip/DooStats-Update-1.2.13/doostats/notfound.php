<?php

declare(strict_types=1);

/**
 * Optional 404 recording. Include this at the top of your custom 404 page:
 *
 *   require __DIR__ . '/stats/notfound.php';
 *
 * It records the missing path so it shows in the dashboard's "Not found" panel.
 * Rate limited per visitor so a crawler cannot flood the table.
 */

require_once __DIR__ . '/lib/analytics.php';

(static function (): void {
    try {
        $path = parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH) ?: '/';
        analytics_record_not_found($path);
    } catch (Throwable $e) {
        // Never break the error page.
    }
})();
