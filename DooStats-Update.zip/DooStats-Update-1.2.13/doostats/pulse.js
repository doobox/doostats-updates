/*
 * DooStats pulse. Load once, then mark elements on the page:
 *   <script src="/doostats/pulse.js" defer></script>
 *   <span data-pulse-online data-pulse-label="visitors online"></span>
 *   <span data-pulse-today data-pulse-label="visits today"></span>
 *   <span data-pulse-week data-pulse-label="visits this week"></span>
 *
 * Fills each marker with "{count} {label}". Fails quietly if unreachable.
 */
(function () {
  'use strict';

  var script = document.currentScript;
  if (!script || !script.src) {
    return;
  }

  var base = script.src.replace(/pulse\.js(?:\?.*)?$/i, '');
  var modes = [
    { attr: 'data-pulse-online', mode: 'online', refresh: 30000 },
    { attr: 'data-pulse-today', mode: 'today', refresh: 300000 },
    { attr: 'data-pulse-week', mode: 'week', refresh: 300000 },
  ];

  function formatCount(n) {
    try {
      return Number(n).toLocaleString();
    } catch (e) {
      return String(n);
    }
  }

  function paint(els, data) {
    if (!data || !data.ok) {
      return;
    }
    var count = formatCount(data.count);
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      var label = (el.getAttribute('data-pulse-label') || '').trim();
      el.textContent = label ? (count + ' ' + label) : count;
    }
  }

  function fetchMode(mode, els) {
    fetch(base + 'pulse.php?mode=' + encodeURIComponent(mode), {
      method: 'GET',
      credentials: 'omit',
      cache: 'no-store',
      headers: { Accept: 'application/json' },
    })
      .then(function (r) {
        if (!r.ok) {
          throw new Error('bad');
        }
        return r.json();
      })
      .then(function (data) {
        paint(els, data);
      })
      .catch(function () {
        /* leave markers unchanged */
      });
  }

  function boot() {
    for (var i = 0; i < modes.length; i++) {
      (function (entry) {
        var els = document.querySelectorAll('[' + entry.attr + ']');
        if (!els.length) {
          return;
        }
        fetchMode(entry.mode, els);
        setInterval(function () {
          fetchMode(entry.mode, els);
        }, entry.refresh);
      })(modes[i]);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
