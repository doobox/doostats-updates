/*
 * First-party world dot-map. No external calls, no map library.
 *
 * Country outlines come from window.__DOOBOX_WORLD_PATHS (see world-50m.js),
 * pre-projected to an equirectangular grid: x = lng + 180 (0..360),
 * y = 90 - lat (0..180). Zoom/pan is just the SVG viewBox, so it stays sharp
 * at any size and needs no tiles.
 *
 * Usage:
 *   const map = createDooboxWorldMap(el, { accent, accentLight, land, border });
 *   map.setPoints([{ lat, lng, visitors, country_label }]);
 */
(function () {
  'use strict';

  var SVG_NS = 'http://www.w3.org/2000/svg';
  var WORLD_W = 360;
  var WORLD_H = 180;
  // Outer bounds = the whole world plus a margin, so the map starts pulled
  // back a touch and can never pan the world fully off-screen.
  var MARGIN_X = 25;
  var MARGIN_Y = 15;
  var OUTER = { x: -MARGIN_X, y: -MARGIN_Y, w: WORLD_W + MARGIN_X * 2, h: WORLD_H + MARGIN_Y * 2 };
  // Initial view (and the zoom-out floor) is one step tighter than the outer
  // bounds, so the map loads a little zoomed in and cannot zoom out to the full
  // world + margin. 0.7 matches one click of the zoom-in button.
  var LOAD_STEP = 0.7;
  var INIT_W = OUTER.w * LOAD_STEP;
  var INIT_H = OUTER.h * LOAD_STEP;
  var MAX_ZOOM = 4; // matches the previous Leaflet limit

  // Min/max of the y coordinates in a path (y = odd-indexed numbers).
  function yBounds(d) {
    var nums = d.match(/-?\d+(?:\.\d+)?/g);
    var min = Infinity;
    var max = -Infinity;
    if (nums) {
      for (var i = 1; i < nums.length; i += 2) {
        var y = parseFloat(nums[i]);
        if (y < min) min = y;
        if (y > max) max = y;
      }
    }
    return { min: min, max: max };
  }

  // Antarctica isn't drawn (we don't expect traffic from there); a visitor who
  // does appear that far south still gets a dot, sitting in open sea. A land
  // path counts as Antarctic when it lies entirely south of ~60S. y = 90 - lat,
  // so lat -60 is y 150.
  function isAntarctic(d) {
    return yBounds(d).min >= 150;
  }

  function clamp(value, min, max) {
    return value < min ? min : value > max ? max : value;
  }

  function project(lng, lat) {
    return { x: lng + 180, y: 90 - lat };
  }

  /** Blend two #rrggbb colours. t=0 → a, t=1 → b. */
  function mixHex(a, b, t) {
    function parse(h) {
      h = String(h || '').replace('#', '');
      if (h.length === 3) {
        h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
      }
      if (h.length !== 6) {
        return [170, 194, 236];
      }
      return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
    }
    var A = parse(a);
    var B = parse(b);
    t = clamp(t, 0, 1);
    function ch(i) {
      var n = Math.round(A[i] + (B[i] - A[i]) * t);
      var hex = n.toString(16);
      return hex.length === 1 ? '0' + hex : hex;
    }
    return '#' + ch(0) + ch(1) + ch(2);
  }

  window.createDooboxWorldMap = function (container, options) {
    options = options || {};
    var accent = options.accent || '#1877f2';
    var accentLight = options.accentLight || '#8fbcf7';
    var water = options.water || '#eef3fb';
    var land = options.land || '#b7c9e8';
    var border = options.border || '#e4ecf8';
    // Borders stay near sea-colour; on zoom they lighten a touch further so
    // outlines stay soft while land reads a bit stronger.
    var borderZoomed = options.borderZoomed || mixHex(border, water, 0.45);
    var paths = window.__DOOBOX_WORLD_PATHS || [];

    // interactive:false disables zoom/pan (fixed view). fit:'world' frames the
    // whole world exactly, with no starting zoom.
    var interactive = options.interactive !== false;
    var fitWorld = options.fit === 'world';
    var outer = fitWorld ? { x: 0, y: 0, w: WORLD_W, h: WORLD_H } : OUTER;
    var initW = fitWorld ? WORLD_W : INIT_W;
    var initH = fitWorld ? WORLD_H : INIT_H;

    container.textContent = '';
    container.style.position = 'relative';
    container.style.touchAction = interactive ? 'none' : 'auto';
    container.style.cursor = interactive ? 'grab' : 'default';
    container.style.background = water;

    var svg = document.createElementNS(SVG_NS, 'svg');
    svg.setAttribute('width', '100%');
    svg.setAttribute('height', '100%');
    svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');
    svg.style.display = 'block';

    var view = { x: outer.x + (outer.w - initW) / 2, y: outer.y + (outer.h - initH) / 2, w: initW, h: initH };
    var landPaths = [];
    var STROKE_OUT = 0.9;
    var STROKE_IN = 1.15;
    // With vector-effect:non-scaling-stroke, dasharray is effectively in
    // screen px — values under ~2 look solid. Keep gaps clearly visible.
    var DASH_OUT = '3.5 5';
    var DASH_IN = '4 5.5';

    function updateBorders() {
      // Mini map: no country outlines. Expanded map: soft dashed borders.
      if (!interactive) {
        for (var i = 0; i < landPaths.length; i++) {
          landPaths[i].setAttribute('stroke', 'none');
          landPaths[i].removeAttribute('stroke-dasharray');
        }
        return;
      }
      // 0 at the initial (zoomed-out) view, 1 at max zoom-in.
      var zoomT = 0;
      if (initW > 0) {
        var minW = initW / MAX_ZOOM;
        zoomT = clamp((initW - view.w) / (initW - minW), 0, 1);
      }
      var stroke = STROKE_OUT + (STROKE_IN - STROKE_OUT) * zoomT;
      var colour = mixHex(border, borderZoomed, zoomT);
      var dash = zoomT > 0.5 ? DASH_IN : DASH_OUT;
      for (var j = 0; j < landPaths.length; j++) {
        landPaths[j].setAttribute('stroke', colour);
        landPaths[j].setAttribute('stroke-width', String(stroke));
        landPaths[j].setAttribute('stroke-dasharray', dash);
      }
    }

    function applyView() {
      svg.setAttribute('viewBox', view.x + ' ' + view.y + ' ' + view.w + ' ' + view.h);
      updateBorders();
      updateDotSizes();
    }

    // Land layer. Track the vertical extent of everything we actually draw so
    // the fit-world view can be centred on the land (with Antarctica omitted
    // the drawn world is shorter, so centring evens out the sea above/below).
    var landGroup = document.createElementNS(SVG_NS, 'g');
    var drawnMinY = Infinity;
    var drawnMaxY = -Infinity;
    for (var i = 0; i < paths.length; i++) {
      if (isAntarctic(paths[i])) continue;
      var yb = yBounds(paths[i]);
      if (yb.min < drawnMinY) drawnMinY = yb.min;
      if (yb.max > drawnMaxY) drawnMaxY = yb.max;
      var p = document.createElementNS(SVG_NS, 'path');
      p.setAttribute('d', paths[i]);
      p.setAttribute('fill', land);
      if (interactive) {
        p.setAttribute('stroke', border);
        p.setAttribute('stroke-width', String(STROKE_OUT));
        p.setAttribute('stroke-dasharray', DASH_OUT);
        p.setAttribute('stroke-linejoin', 'round');
        p.setAttribute('stroke-linecap', 'round');
        p.setAttribute('vector-effect', 'non-scaling-stroke');
      } else {
        p.setAttribute('stroke', 'none');
      }
      landGroup.appendChild(p);
      landPaths.push(p);
    }
    svg.appendChild(landGroup);

    // Shift the fit-world framing vertically so the drawn land is centred.
    // (The view is applied once at the end, after the dot layer is ready.)
    if (fitWorld && isFinite(drawnMinY) && isFinite(drawnMaxY)) {
      var vShift = (drawnMinY + drawnMaxY) / 2 - WORLD_H / 2;
      outer.y += vShift;
      view.y += vShift;
    }

    var dotGroup = document.createElementNS(SVG_NS, 'g');
    svg.appendChild(dotGroup);
    container.appendChild(svg);

    // Tooltip.
    var tip = document.createElement('div');
    tip.style.cssText =
      'position:absolute;pointer-events:none;z-index:10;display:none;white-space:nowrap;' +
      'padding:2px 8px;border-radius:6px;font-size:12px;line-height:1.4;' +
      'background:rgba(17,24,39,0.9);color:#fff;transform:translate(-50%,-130%);';
    container.appendChild(tip);

    var dots = []; // { el, basePx }
    function updateDotSizes() {
      var pxWidth = svg.clientWidth || container.clientWidth || 1;
      var unitsPerPx = view.w / pxWidth;
      for (var i = 0; i < dots.length; i++) {
        dots[i].el.setAttribute('r', String(dots[i].basePx * unitsPerPx));
      }
    }

    function showTip(html, cx, cy) {
      var pxWidth = svg.clientWidth || container.clientWidth || 1;
      var pxHeight = svg.clientHeight || container.clientHeight || 1;
      // Map viewBox coords back to container pixels (meet may letterbox).
      var scale = Math.min(pxWidth / view.w, pxHeight / view.h);
      var offsetX = (pxWidth - view.w * scale) / 2;
      var offsetY = (pxHeight - view.h * scale) / 2;
      tip.style.left = offsetX + (cx - view.x) * scale + 'px';
      tip.style.top = offsetY + (cy - view.y) * scale + 'px';
      tip.textContent = html;
      tip.style.display = 'block';
    }

    function setPoints(points) {
      dotGroup.textContent = '';
      dots = [];
      if (!Array.isArray(points)) points = [];
      points.forEach(function (point) {
        var lat = Number(point.lat);
        var lng = Number(point.lng);
        if (!isFinite(lat) || !isFinite(lng)) return;
        var visitors = Number(point.visitors || 0);
        var pos = project(lng, lat);
        var circle = document.createElementNS(SVG_NS, 'circle');
        circle.setAttribute('cx', String(pos.x));
        circle.setAttribute('cy', String(pos.y));
        circle.setAttribute('fill', options.dotFill || '#ffffff');
        circle.setAttribute('fill-opacity', String(options.dotFillOpacity != null ? options.dotFillOpacity : 1));
        circle.setAttribute('stroke', options.dotStroke || accent);
        circle.setAttribute('stroke-width', '1.5');
        circle.setAttribute('stroke-opacity', String(options.dotStrokeOpacity != null ? options.dotStrokeOpacity : 1));
        circle.setAttribute('vector-effect', 'non-scaling-stroke');
        circle.style.cursor = 'pointer';
        var countText = typeof options.formatNumber === 'function'
          ? options.formatNumber(visitors)
          : String(visitors);
        var label;
        if (typeof options.formatTooltip === 'function') {
          label = options.formatTooltip(point.country_label || 'Unknown', countText);
        } else {
          label = (point.country_label || 'Unknown') + ': ' + countText + ' active';
        }
        circle.addEventListener('mouseenter', function () {
          showTip(label, pos.x, pos.y);
        });
        circle.addEventListener('mouseleave', function () {
          tip.style.display = 'none';
        });
        dotGroup.appendChild(circle);
        dots.push({ el: circle, basePx: 4 + Math.min(14, Math.sqrt(visitors) * 3) });
      });
      updateDotSizes();
    }

    // Zoom towards a viewBox point, keeping min = initial view, max = 4x in.
    function zoomTo(factor, focusX, focusY) {
      var minW = initW / MAX_ZOOM;
      var newW = clamp(view.w * factor, minW, initW);
      var ratio = newW / view.w;
      if (ratio === 1) return;
      var newH = view.h * ratio;
      view.x = focusX - (focusX - view.x) * ratio;
      view.y = focusY - (focusY - view.y) * ratio;
      view.w = newW;
      view.h = newH;
      view.x = clamp(view.x, outer.x, outer.x + outer.w - view.w);
      view.y = clamp(view.y, outer.y, outer.y + outer.h - view.h);
      applyView();
    }

    function pointerToView(evt) {
      var rect = svg.getBoundingClientRect();
      var pxWidth = rect.width || 1;
      var pxHeight = rect.height || 1;
      var scale = Math.min(pxWidth / view.w, pxHeight / view.h);
      var offsetX = (pxWidth - view.w * scale) / 2;
      var offsetY = (pxHeight - view.h * scale) / 2;
      return {
        x: view.x + (evt.clientX - rect.left - offsetX) / scale,
        y: view.y + (evt.clientY - rect.top - offsetY) / scale,
      };
    }

    if (interactive) {
      svg.addEventListener('wheel', function (evt) {
        evt.preventDefault();
        var focus = pointerToView(evt);
        zoomTo(evt.deltaY < 0 ? 0.8 : 1.25, focus.x, focus.y);
      }, { passive: false });

      var dragging = false;
      var last = null;
      svg.addEventListener('pointerdown', function (evt) {
        dragging = true;
        last = { x: evt.clientX, y: evt.clientY };
        container.style.cursor = 'grabbing';
        svg.setPointerCapture(evt.pointerId);
      });
      svg.addEventListener('pointermove', function (evt) {
        if (!dragging || !last) return;
        var rect = svg.getBoundingClientRect();
        var scale = Math.min((rect.width || 1) / view.w, (rect.height || 1) / view.h);
        view.x = clamp(view.x - (evt.clientX - last.x) / scale, outer.x, outer.x + outer.w - view.w);
        view.y = clamp(view.y - (evt.clientY - last.y) / scale, outer.y, outer.y + outer.h - view.h);
        last = { x: evt.clientX, y: evt.clientY };
        applyView();
      });
      var endDrag = function (evt) {
        dragging = false;
        last = null;
        container.style.cursor = 'grab';
        if (evt && evt.pointerId != null && svg.hasPointerCapture(evt.pointerId)) {
          svg.releasePointerCapture(evt.pointerId);
        }
      };
      svg.addEventListener('pointerup', endDrag);
      svg.addEventListener('pointercancel', endDrag);

      // Zoom buttons.
      var controls = document.createElement('div');
      controls.style.cssText = 'position:absolute;top:8px;left:8px;z-index:10;display:flex;flex-direction:column;gap:4px;';
      var makeButton = function (text, factor) {
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.textContent = text;
        btn.style.cssText =
          'width:28px;height:28px;border:1px solid #c2cad6;background:#fff;border-radius:6px;' +
          'font-size:16px;line-height:1;color:#374151;cursor:pointer;box-shadow:0 1px 2px rgba(0,0,0,0.08);';
        btn.addEventListener('click', function () {
          zoomTo(factor, view.x + view.w / 2, view.y + view.h / 2);
        });
        return btn;
      };
      controls.appendChild(makeButton('+', 0.7));
      controls.appendChild(makeButton('\u2212', 1 / 0.7));
      container.appendChild(controls);
    }

    window.addEventListener('resize', updateDotSizes);
    applyView();

    return {
      setPoints: setPoints,
      reset: function () {
        view = { x: outer.x + (outer.w - initW) / 2, y: outer.y + (outer.h - initH) / 2, w: initW, h: initH };
        applyView();
      },
    };
  };
})();
