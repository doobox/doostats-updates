<?php

declare(strict_types=1);

/**
 * Public pulse JSON API for pulse.js page markers.
 * Returns aggregate counts only (online / today / week).
 */

require_once __DIR__ . '/lib/pulse.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: public, max-age=15');
header('X-Content-Type-Options: nosniff');

$method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));

doostats_pulse_apply_cors();

if ($method === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($method !== 'GET') {
    http_response_code(405);
    echo '{"ok":false}';
    exit;
}

$fail = static function (): void {
    http_response_code(404);
    echo '{"ok":false}';
    exit;
};

if (!doostats_pulse_rate_allow()) {
    http_response_code(429);
    header('Retry-After: 60');
    echo '{"ok":false}';
    exit;
}

$mode = doostats_pulse_normalize_mode((string) ($_GET['mode'] ?? 'online'));
$payload = doostats_pulse_cache_read($mode);
if ($payload === null) {
    try {
        $payload = doostats_pulse_payload($mode);
        doostats_pulse_cache_write($payload);
    } catch (Throwable $e) {
        $fail();
    }
}

echo json_encode([
    'ok' => true,
    'count' => (int) $payload['count'],
    'mode' => (string) $payload['mode'],
    'color' => (string) $payload['color'],
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
