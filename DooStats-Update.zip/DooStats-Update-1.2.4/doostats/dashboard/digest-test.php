<?php

declare(strict_types=1);

require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/config-write.php';
require_once __DIR__ . '/../lib/digest.php';

/**
 * AJAX: save digest settings from the form, then send a test email.
 * Keeps the Settings page from scrolling; status is returned as JSON.
 */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$json = static function (array $payload, int $code = 200): void {
    http_response_code($code);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
};

if (!auth_is_logged_in()) {
    $json(['ok' => false, 'message' => t('updates.error.not_signed_in')], 403);
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    $json(['ok' => false, 'message' => t('updates.error.post_required')], 405);
}

if (!auth_check_csrf($_POST['csrf'] ?? null)) {
    $json(['ok' => false, 'message' => t('updates.error.csrf')], 403);
}

$digestEnabled = !empty($_POST['digest_enabled']);
$digestEmail = trim((string) ($_POST['digest_email'] ?? ''));

if (!$digestEnabled) {
    $json(['ok' => false, 'message' => t('settings.reports.error.disabled')]);
}
if ($digestEmail === '' || !filter_var($digestEmail, FILTER_VALIDATE_EMAIL)) {
    $json(['ok' => false, 'message' => t('settings.reports.error.email')]);
}

$cfg = analytics_config();
$new = $cfg;
$new['digest_enabled'] = true;
$new['digest_email'] = $digestEmail;

if (!doostats_write_config($new)) {
    $json(['ok' => false, 'message' => t('settings.error.config_write')]);
}

// Drop the session lock before mail() so other dashboard tabs stay responsive.
auth_release_session();

$send = doostats_digest_send_now(true);
$json([
    'ok' => $send['ok'],
    'message' => $send['message'],
    'status' => doostats_digest_status_label(),
]);
