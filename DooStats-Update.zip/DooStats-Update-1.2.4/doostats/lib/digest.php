<?php

declare(strict_types=1);

/**
 * Opt-in weekly email digest. Triggered lazily after collect.php returns 204 —
 * no cron. Settings: digest_enabled + digest_email in config.php.
 * Runtime status: data/digest-state.json.
 */

require_once __DIR__ . '/analytics.php';
require_once __DIR__ . '/i18n.php';
require_once __DIR__ . '/install-path.php';

const DOOSTATS_DIGEST_INTERVAL_SECONDS = 604800; // 7 days

function doostats_digest_data_dir(): string
{
    $cfg = analytics_config();
    return rtrim((string) ($cfg['data_dir'] ?? dirname(__DIR__) . '/data'), '/\\');
}

function doostats_digest_state_path(): string
{
    return doostats_digest_data_dir() . '/digest-state.json';
}

/**
 * @return array{last_sent_at: string, last_attempt_at: string, last_ok: bool, last_error: string, last_to: string}
 */
function doostats_digest_state(): array
{
    $empty = [
        'last_sent_at' => '',
        'last_attempt_at' => '',
        'last_ok' => false,
        'last_error' => '',
        'last_to' => '',
    ];
    $path = doostats_digest_state_path();
    if (!is_file($path)) {
        return $empty;
    }
    $raw = @file_get_contents($path);
    $data = is_string($raw) ? json_decode($raw, true) : null;
    if (!is_array($data)) {
        return $empty;
    }
    $attempt = trim((string) ($data['last_attempt_at'] ?? ''));
    if ($attempt === '') {
        $attempt = trim((string) ($data['last_sent_at'] ?? ''));
    }
    return [
        'last_sent_at' => trim((string) ($data['last_sent_at'] ?? '')),
        'last_attempt_at' => $attempt,
        'last_ok' => !empty($data['last_ok']),
        'last_error' => trim((string) ($data['last_error'] ?? '')),
        'last_to' => trim((string) ($data['last_to'] ?? '')),
    ];
}

/**
 * @param array{last_sent_at?: string, last_attempt_at?: string, last_ok?: bool, last_error?: string, last_to?: string} $state
 */
function doostats_digest_write_state(array $state): bool
{
    $dir = doostats_digest_data_dir();
    if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
        return false;
    }
    $current = doostats_digest_state();
    $merged = array_merge($current, $state);
    $json = json_encode([
        'last_sent_at' => (string) ($merged['last_sent_at'] ?? ''),
        'last_attempt_at' => (string) ($merged['last_attempt_at'] ?? ''),
        'last_ok' => !empty($merged['last_ok']),
        'last_error' => (string) ($merged['last_error'] ?? ''),
        'last_to' => (string) ($merged['last_to'] ?? ''),
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n";

    $path = doostats_digest_state_path();
    $tmp = $path . '.' . bin2hex(random_bytes(4)) . '.tmp';
    if (@file_put_contents($tmp, $json, LOCK_EX) === false) {
        @unlink($tmp);
        return false;
    }
    if (!@rename($tmp, $path)) {
        @unlink($tmp);
        return false;
    }
    @chmod($path, 0644);
    return true;
}

function doostats_digest_enabled(): bool
{
    return !empty(analytics_config()['digest_enabled']);
}

function doostats_digest_email(): string
{
    return trim((string) (analytics_config()['digest_email'] ?? ''));
}

function doostats_digest_email_valid(?string $email = null): bool
{
    $email = $email ?? doostats_digest_email();
    return $email !== '' && (bool) filter_var($email, FILTER_VALIDATE_EMAIL);
}

function doostats_digest_dashboard_url(): string
{
    $cfg = analytics_config();
    $site = rtrim((string) ($cfg['site_url'] ?? ''), '/');
    if ($site === '') {
        $site = rtrim(doostats_detect_site_url(), '/');
    }
    return $site . doostats_install_path() . '/dashboard/';
}

function doostats_digest_from_address(): string
{
    $cfg = analytics_config();
    $host = '';
    $siteUrl = trim((string) ($cfg['site_url'] ?? ''));
    if ($siteUrl !== '') {
        $host = (string) (parse_url($siteUrl, PHP_URL_HOST) ?: '');
    }
    if ($host === '') {
        $host = trim((string) ($_SERVER['HTTP_HOST'] ?? ''));
    }
    if ($host === '') {
        $host = trim((string) ($_SERVER['SERVER_NAME'] ?? ''));
    }
    $host = preg_replace('/:\d+$/', '', $host) ?: 'localhost';
    // Strip brackets from IPv6 literals for a safer From header.
    $host = trim($host, '[]');
    return 'doostats@' . $host;
}

function doostats_digest_is_due(array $state): bool
{
    $sent = trim((string) ($state['last_sent_at'] ?? ''));
    if ($sent === '') {
        return true;
    }
    try {
        $dt = new DateTimeImmutable($sent);
    } catch (Exception $e) {
        return true;
    }
    return (time() - $dt->getTimestamp()) >= DOOSTATS_DIGEST_INTERVAL_SECONDS;
}

/**
 * Non-blocking exclusive lock. Returns a file handle to keep until unlock, or null.
 *
 * @return resource|null
 */
function doostats_digest_acquire_lock()
{
    $dir = doostats_digest_data_dir();
    if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
        return null;
    }
    $path = $dir . '/digest.lock';
    $fh = @fopen($path, 'c+');
    if ($fh === false) {
        return null;
    }
    if (!flock($fh, LOCK_EX | LOCK_NB)) {
        fclose($fh);
        return null;
    }
    return $fh;
}

/**
 * @param resource $fh
 */
function doostats_digest_release_lock($fh): void
{
    flock($fh, LOCK_UN);
    fclose($fh);
}

/**
 * Lazy weekly send after a beacon. Safe to call on every collect.php request.
 * Never throws.
 */
function doostats_digest_maybe_send(): void
{
    try {
        if (!doostats_digest_enabled() || !doostats_digest_email_valid()) {
            return;
        }
        $state = doostats_digest_state();
        if (!doostats_digest_is_due($state)) {
            return;
        }
        $lock = doostats_digest_acquire_lock();
        if ($lock === null) {
            return;
        }
        try {
            // Re-check under lock (another beacon may have just sent).
            $state = doostats_digest_state();
            if (!doostats_digest_is_due($state)) {
                return;
            }
            doostats_digest_send(doostats_digest_email(), false);
        } finally {
            doostats_digest_release_lock($lock);
        }
    } catch (Throwable $e) {
        // Never break tracking.
    }
}

/**
 * Manual / test send from Settings. Updates status.
 *
 * @return array{ok: bool, message: string}
 */
function doostats_digest_send_now(bool $isTest = true): array
{
    if (!doostats_digest_email_valid()) {
        return ['ok' => false, 'message' => t('settings.reports.error.email')];
    }
    if (!doostats_digest_enabled() && !$isTest) {
        return ['ok' => false, 'message' => t('settings.reports.error.disabled')];
    }

    $lock = doostats_digest_acquire_lock();
    if ($lock === null) {
        return ['ok' => false, 'message' => t('settings.reports.error.busy')];
    }

    try {
        if ($isTest) {
            $state = doostats_digest_state();
            $result = doostats_digest_send(doostats_digest_email(), true);
            // A first test establishes the weekly schedule. Without this, the
            // next pageview sees "never sent" and immediately sends a second,
            // non-test copy.
            if ($result['ok'] && trim((string) ($state['last_sent_at'] ?? '')) === '') {
                doostats_digest_write_state(['last_sent_at' => gmdate('Y-m-d\TH:i:s\Z')]);
            }
            return $result;
        }

        return doostats_digest_send(doostats_digest_email(), false);
    } finally {
        doostats_digest_release_lock($lock);
    }
}

/**
 * Build and send one digest email. Writes last_sent status (weekly and test).
 *
 * @return array{ok: bool, message: string}
 */
function doostats_digest_send(string $to, bool $isTest): array
{
    try {
        $payload = doostats_digest_build_message($isTest);
    } catch (Throwable $e) {
        $now = gmdate('Y-m-d\TH:i:s\Z');
        $stateUpdate = [
            'last_attempt_at' => $now,
            'last_ok' => false,
            'last_error' => t('settings.reports.error.build'),
            'last_to' => $to,
        ];
        if (!$isTest) {
            $stateUpdate['last_sent_at'] = $now;
        }
        doostats_digest_write_state($stateUpdate);
        return ['ok' => false, 'message' => t('settings.reports.error.build')];
    }

    $boundary = 'doostats-' . bin2hex(random_bytes(12));
    $from = doostats_digest_from_address();
    $host = substr(strrchr($from, '@') ?: '@localhost', 1);
    $subject = str_replace(["\r", "\n"], '', $payload['subject']);
    if (function_exists('mb_encode_mimeheader')) {
        $subject = mb_encode_mimeheader($subject, 'UTF-8', 'B', "\r\n");
    }
    $headers = [
        'Date: ' . date(DATE_RFC2822),
        'Message-ID: <' . bin2hex(random_bytes(12)) . '@' . $host . '>',
        'MIME-Version: 1.0',
        'Content-Type: multipart/alternative; boundary="' . $boundary . '"',
        'From: DooStats <' . $from . '>',
        'Auto-Submitted: auto-generated',
        'X-Mailer: DooStats',
    ];
    $body = '--' . $boundary . "\r\n"
        . "Content-Type: text/plain; charset=UTF-8\r\n"
        . "Content-Transfer-Encoding: base64\r\n\r\n"
        . chunk_split(base64_encode($payload['text']))
        . '--' . $boundary . "\r\n"
        . "Content-Type: text/html; charset=UTF-8\r\n"
        . "Content-Transfer-Encoding: base64\r\n\r\n"
        . chunk_split(base64_encode($payload['html']))
        . '--' . $boundary . "--\r\n";

    $ok = @mail(
        $to,
        $subject,
        $body,
        implode("\r\n", $headers)
    );

    $now = gmdate('Y-m-d\TH:i:s\Z');
    $error = $ok ? '' : t('settings.reports.error.mail');
    $stateUpdate = [
        'last_attempt_at' => $now,
        'last_ok' => $ok,
        'last_error' => $error,
        'last_to' => $to,
    ];
    // Weekly sends advance the due clock. A first successful test establishes
    // the initial schedule in doostats_digest_send_now().
    if (!$isTest) {
        $stateUpdate['last_sent_at'] = $now;
    }
    doostats_digest_write_state($stateUpdate);

    if ($ok) {
        return [
            'ok' => true,
            'message' => $isTest
                ? t('settings.reports.notice.test_sent')
                : t('settings.reports.notice.sent'),
        ];
    }
    return ['ok' => false, 'message' => $error];
}

/**
 * @return array{subject: string, html: string, text: string}
 */
function doostats_digest_build_message(bool $isTest): array
{
    $cfg = analytics_config();
    $siteName = trim((string) ($cfg['site_name'] ?? ''));
    if ($siteName === '') {
        $siteName = t('nav.brand_fallback');
    }
    $brand = (string) ($cfg['brand_hex'] ?? '#3b82f6');
    if (!preg_match('/^#[0-9a-fA-F]{6}$/', $brand)) {
        $brand = '#3b82f6';
    }

    $summary = analytics_dashboard_summary(7);
    $pages = analytics_top_pages(7, 5);
    $referrers = analytics_top_referrers(7, 5);
    $notFound = analytics_not_found_rows(7, 5);
    $dashboardUrl = doostats_digest_dashboard_url();
    $trackVisitors = analytics_process_visitor_ip();

    $visitors = (int) ($summary['unique_visitors'] ?? 0);
    $views = (int) ($summary['total_views'] ?? 0);
    $returning = (int) ($summary['returning_visitors'] ?? 0);
    $ppv = (float) ($summary['pages_per_visitor'] ?? 0);
    $change = $summary['views_change_percent'] ?? null;
    if (!$trackVisitors) {
        $visitors = 0;
        $returning = 0;
        $ppv = 0.0;
    }

    if ($trackVisitors) {
        $subject = t('digest.email.subject', [
            'site' => $siteName,
            'visitors' => i18n_format_number($visitors),
        ]);
    } else {
        $subject = t('digest.email.subject_views', [
            'site' => $siteName,
            'views' => i18n_format_number($views),
        ]);
    }
    if (is_int($change)) {
        $subject .= ' (' . ($change >= 0 ? '+' : '') . i18n_format_percent($change) . ')';
    }
    if ($isTest) {
        $subject = t('digest.email.subject_test_prefix') . ' ' . $subject;
    }

    $esc = static fn (string $s): string => htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
    $changeHtml = '';
    if (is_int($change)) {
        $label = ($change >= 0 ? '+' : '') . i18n_format_percent($change);
        $changeHtml = ' <span style="color:' . ($change >= 0 ? '#15803d' : '#b91c1c') . '">('
            . $esc($label) . ' ' . $esc(t('digest.email.vs_previous')) . ')</span>';
    }

    $rows = static function (array $items, string $keyLabel, string $keyCount) use ($esc): string {
        if ($items === []) {
            return '<tr><td colspan="2" style="padding:0.4rem 0;color:#5c6575;">'
                . $esc(t('digest.email.empty')) . '</td></tr>';
        }
        $html = '';
        foreach ($items as $row) {
            $label = (string) ($row[$keyLabel] ?? '');
            if ($label === 'direct') {
                $label = t('digest.email.direct');
            }
            $count = (int) ($row[$keyCount] ?? $row['views'] ?? $row['count'] ?? 0);
            $html .= '<tr>'
                . '<td style="padding:0.35rem 0.5rem 0.35rem 0;border-bottom:1px solid #e4e7ee;">'
                . $esc($label) . '</td>'
                . '<td style="padding:0.35rem 0;border-bottom:1px solid #e4e7ee;text-align:right;font-variant-numeric:tabular-nums;">'
                . $esc(i18n_format_number($count)) . '</td>'
                . '</tr>';
        }
        return $html;
    };

    if ($trackVisitors) {
        $heroLabel = t('digest.email.visitors');
        $heroValue = i18n_format_number($visitors);
        $subMetricsHtml = '<tr>'
            . '<td style="padding:0.35rem 0.5rem 0.35rem 0;vertical-align:top;">'
            . '<div style="font-size:0.8rem;color:#5c6575;">' . $esc(t('digest.email.pageviews')) . '</div>'
            . '<div style="font-weight:600;">' . $esc(i18n_format_number($views)) . '</div></td>'
            . '<td style="padding:0.35rem 0.5rem;vertical-align:top;">'
            . '<div style="font-size:0.8rem;color:#5c6575;">' . $esc(t('digest.email.returning')) . '</div>'
            . '<div style="font-weight:600;">' . $esc(i18n_format_number($returning)) . '</div></td>'
            . '<td style="padding:0.35rem 0;vertical-align:top;">'
            . '<div style="font-size:0.8rem;color:#5c6575;">' . $esc(t('digest.email.pages_per_visitor')) . '</div>'
            . '<div style="font-weight:600;">' . $esc(i18n_format_number($ppv, 1)) . '</div></td>'
            . '</tr>';
        $textMetrics = t('digest.email.visitors') . ': ' . i18n_format_number($visitors) . "\n"
            . t('digest.email.pageviews') . ': ' . i18n_format_number($views) . "\n"
            . t('digest.email.returning') . ': ' . i18n_format_number($returning) . "\n"
            . t('digest.email.pages_per_visitor') . ': ' . i18n_format_number($ppv, 1) . "\n\n";
    } else {
        $heroLabel = t('digest.email.pageviews');
        $heroValue = i18n_format_number($views);
        $subMetricsHtml = '';
        $textMetrics = t('digest.email.pageviews') . ': ' . i18n_format_number($views) . "\n\n";
    }

    $html = '<!DOCTYPE html><html><head><meta charset="utf-8" /></head>'
        . '<body style="margin:0;padding:0;background:#f4f6fa;color:#1a1f2c;'
        . 'font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;font-size:16px;line-height:1.5;">'
        . '<div style="max-width:32rem;margin:0 auto;padding:1.5rem 1rem 2rem;">'
        . '<p style="margin:0 0 0.75rem;font-weight:700;letter-spacing:-0.02em;">'
        . 'Doo<span style="color:' . $esc($brand) . ';">Stats</span></p>'
        . '<h1 style="margin:0 0 0.35rem;font-size:1.35rem;letter-spacing:-0.02em;">'
        . $esc(t('digest.email.heading', ['site' => $siteName])) . '</h1>'
        . '<p style="margin:0 0 1.25rem;color:#5c6575;font-size:0.95rem;">'
        . $esc(t('digest.email.lede')) . '</p>'
        . '<table role="presentation" style="width:100%;border-collapse:collapse;background:#fff;'
        . 'border:1px solid #e4e7ee;border-radius:12px;padding:0;margin:0 0 1rem;">'
        . '<tr><td style="padding:1rem 1.15rem;">'
        . '<p style="margin:0 0 0.35rem;font-size:0.85rem;color:#5c6575;">'
        . $esc($heroLabel) . '</p>'
        . '<p style="margin:0' . ($subMetricsHtml !== '' ? ' 0 0.85rem' : '') . ';font-size:1.6rem;font-weight:700;letter-spacing:-0.02em;">'
        . $esc($heroValue) . $changeHtml . '</p>'
        . ($subMetricsHtml !== ''
            ? '<table role="presentation" style="width:100%;border-collapse:collapse;">' . $subMetricsHtml . '</table>'
            : '')
        . '</td></tr></table>'

        . '<h2 style="margin:1.25rem 0 0.5rem;font-size:1rem;">' . $esc(t('digest.email.top_pages')) . '</h2>'
        . '<table role="presentation" style="width:100%;border-collapse:collapse;">'
        . $rows($pages, 'path', 'views') . '</table>'

        . '<h2 style="margin:1.25rem 0 0.5rem;font-size:1rem;">' . $esc(t('digest.email.top_referrers')) . '</h2>'
        . '<table role="presentation" style="width:100%;border-collapse:collapse;">'
        . $rows($referrers, 'referrer', 'views') . '</table>'

        . '<h2 style="margin:1.25rem 0 0.5rem;font-size:1rem;">' . $esc(t('digest.email.not_found')) . '</h2>'
        . '<table role="presentation" style="width:100%;border-collapse:collapse;">'
        . $rows($notFound, 'path', 'count') . '</table>'

        . '<p style="margin:1.5rem 0 0;">'
        . '<a href="' . $esc($dashboardUrl) . '" style="display:inline-block;padding:0.65rem 1rem;'
        . 'background:' . $esc($brand) . ';color:#fff;font-weight:600;text-decoration:none;border-radius:8px;">'
        . $esc(t('digest.email.view_dashboard')) . '</a></p>'
        . '<p style="margin:1.25rem 0 0;font-size:0.85rem;color:#5c6575;">'
        . $esc(t('digest.email.footer')) . '</p>'
        . '</div></body></html>';

    $textRows = static function (array $items, string $keyLabel, string $keyCount): string {
        if ($items === []) {
            return t('digest.email.empty') . "\n";
        }
        $text = '';
        foreach ($items as $row) {
            $label = (string) ($row[$keyLabel] ?? '');
            if ($label === 'direct') {
                $label = t('digest.email.direct');
            }
            $count = (int) ($row[$keyCount] ?? $row['views'] ?? $row['count'] ?? 0);
            $text .= '- ' . $label . ': ' . i18n_format_number($count) . "\n";
        }
        return $text;
    };
    $text = t('digest.email.heading', ['site' => $siteName]) . "\n"
        . t('digest.email.lede') . "\n\n"
        . $textMetrics
        . t('digest.email.top_pages') . "\n" . $textRows($pages, 'path', 'views') . "\n"
        . t('digest.email.top_referrers') . "\n" . $textRows($referrers, 'referrer', 'views') . "\n"
        . t('digest.email.not_found') . "\n" . $textRows($notFound, 'path', 'count') . "\n"
        . t('digest.email.view_dashboard') . ': ' . $dashboardUrl . "\n\n"
        . t('digest.email.footer') . "\n";

    return ['subject' => $subject, 'html' => $html, 'text' => $text];
}

/** Human-readable status line for Settings. */
function doostats_digest_status_label(): string
{
    $state = doostats_digest_state();
    $sent = trim((string) ($state['last_attempt_at'] ?? ''));
    if ($sent === '') {
        return t('settings.reports.status.never');
    }
    try {
        $dt = new DateTimeImmutable($sent);
        $tz = analytics_timezone();
        $when = i18n_format_date($dt->setTimezone($tz), 'datetime', $tz);
    } catch (Exception $e) {
        $when = $sent;
    }
    if (!empty($state['last_ok'])) {
        return t('settings.reports.status.ok', ['when' => $when]);
    }
    $err = trim((string) ($state['last_error'] ?? ''));
    if ($err === '') {
        $err = t('settings.reports.error.mail');
    }
    return t('settings.reports.status.fail', ['when' => $when, 'error' => $err]);
}
