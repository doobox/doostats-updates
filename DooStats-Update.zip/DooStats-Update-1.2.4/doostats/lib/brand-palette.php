<?php

declare(strict_types=1);

require_once __DIR__ . '/i18n.php';

/**
 * Brand colour palette. The product stores a plain hex string in config, but
 * the UI offers a strict set of accents so every install looks consistent.
 * Swatches are Tailwind CSS "500" colours (same shade in light and dark mode):
 * https://tailwindcss.com/docs/colors
 */

/** @return array<string, string> lowercase hex => display name */
function doostats_brand_palette(): array
{
    return [
        '#ef4444' => 'Red',
        '#f97316' => 'Orange',
        '#f59e0b' => 'Amber',
        '#eab308' => 'Yellow',
        '#84cc16' => 'Lime',
        '#22c55e' => 'Green',
        '#10b981' => 'Emerald',
        '#14b8a6' => 'Teal',
        '#06b6d4' => 'Cyan',
        '#0ea5e9' => 'Sky',
        '#3b82f6' => 'Blue',
        '#6366f1' => 'Indigo',
        '#8b5cf6' => 'Violet',
        '#a855f7' => 'Purple',
        '#d946ef' => 'Fuchsia',
        '#ec4899' => 'Pink',
        '#f43f5e' => 'Rose',
    ];
}

/** The default accent used for new installs and as a fallback (Tailwind blue-500). */
function doostats_brand_default(): string
{
    return '#3b82f6';
}

/**
 * Soft tint of a hex for --brand-weak.
 */
function doostats_brand_weak_rgba(string $hex, float $alpha = 0.12): string
{
    $rgb = sscanf(strtolower(trim($hex)), '#%02x%02x%02x');
    if (!is_array($rgb) || count($rgb) !== 3) {
        $rgb = [59, 130, 246];
    }
    return sprintf('rgba(%d, %d, %d, %.2f)', $rgb[0], $rgb[1], $rgb[2], $alpha);
}

/**
 * Inline <style> that sets --brand / --brand-weak from the stored hex.
 */
function doostats_brand_css_vars(string $hex): string
{
    $brand = strtolower(trim($hex));
    if ($brand === '' || !preg_match('/^#[0-9a-f]{6}$/', $brand)) {
        $brand = doostats_brand_default();
    }
    $esc = static fn (string $s): string => htmlspecialchars($s, ENT_QUOTES, 'UTF-8');

    return '<style>'
        . ':root{'
        . '--brand:' . $esc($brand) . ';'
        . '--brand-weak:' . $esc(doostats_brand_weak_rgba($brand)) . ';'
        . '}'
        . '</style>';
}

/** Localised display name for a palette English label (e.g. Red → t(settings.brand.red)). */
function doostats_brand_label(string $englishName): string
{
    return t('settings.brand.' . strtolower($englishName));
}

/** Human-readable name for a hex value, or "Custom" if outside the palette. */
function doostats_brand_name(string $hex): string
{
    $english = doostats_brand_palette()[strtolower(trim($hex))] ?? 'Custom';
    return doostats_brand_label($english);
}

/**
 * Render the custom colour <select> replacement: a listbox of swatch + name
 * rows backed by a hidden input that still submits the raw hex. If the current
 * value isn't a palette colour (e.g. a legacy config) it's shown as "Custom"
 * and kept selectable so saving other fields never rewrites it unexpectedly.
 */
function doostats_brand_select_html(string $currentHex, string $fieldId = 'brand_hex'): string
{
    $palette = doostats_brand_palette();
    $current = strtolower(trim($currentHex));
    $currentEnglish = $palette[$current] ?? 'Custom';
    $currentName = doostats_brand_label($currentEnglish);
    $esc = static fn (string $s): string => htmlspecialchars($s, ENT_QUOTES, 'UTF-8');

    $btnId = $fieldId . '_btn';
    $listId = $fieldId . '_list';

    ob_start();
    ?>
    <div class="colorselect" data-colorselect>
      <input type="hidden" name="<?= $esc($fieldId) ?>" id="<?= $esc($fieldId) ?>" value="<?= $esc($current) ?>" />
      <button type="button" class="colorselect-trigger" id="<?= $esc($btnId) ?>" aria-haspopup="listbox" aria-expanded="false" aria-controls="<?= $esc($listId) ?>">
        <span class="swatch" data-swatch style="background: <?= $esc($current) ?>"></span>
        <span class="colorselect-name" data-name><?= $esc($currentName) ?></span>
        <svg class="colorselect-caret" width="12" height="12" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M4 6l4 4 4-4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </button>
      <ul class="colorselect-list" id="<?= $esc($listId) ?>" role="listbox" tabindex="-1" hidden>
        <?php if (!isset($palette[$current])): ?>
          <li class="colorselect-option" role="option" data-value="<?= $esc($current) ?>" aria-selected="true" tabindex="-1">
            <span class="swatch" style="background: <?= $esc($current) ?>"></span>
            <span><?= $esc(doostats_brand_label('Custom')) ?></span>
          </li>
        <?php endif; ?>
        <?php foreach ($palette as $hex => $name): ?>
          <li class="colorselect-option" role="option" data-value="<?= $esc($hex) ?>" aria-selected="<?= $hex === $current ? 'true' : 'false' ?>" tabindex="-1">
            <span class="swatch" style="background: <?= $esc($hex) ?>"></span>
            <span><?= $esc(doostats_brand_label($name)) ?></span>
          </li>
        <?php endforeach; ?>
      </ul>
    </div>
    <?php
    return (string) ob_get_clean();
}

/** One-time client script that powers every [data-colorselect] on the page. */
function doostats_brand_select_script(): string
{
    return <<<'HTML'
<script>
(function () {
  document.querySelectorAll('[data-colorselect]').forEach(function (root) {
    var btn = root.querySelector('.colorselect-trigger');
    var list = root.querySelector('.colorselect-list');
    var input = root.querySelector('input[type=hidden]');
    var nameEl = root.querySelector('[data-name]');
    var swatchEl = root.querySelector('[data-swatch]');
    var options = Array.prototype.slice.call(root.querySelectorAll('.colorselect-option'));
    if (!btn || !list || !input) return;

    function open() {
      list.hidden = false;
      btn.setAttribute('aria-expanded', 'true');
      var sel = list.querySelector('[aria-selected=true]') || options[0];
      if (sel) sel.focus();
    }
    function close() {
      list.hidden = true;
      btn.setAttribute('aria-expanded', 'false');
    }
    function choose(opt) {
      options.forEach(function (o) { o.setAttribute('aria-selected', o === opt ? 'true' : 'false'); });
      var value = opt.getAttribute('data-value');
      input.value = value;
      swatchEl.style.background = value;
      nameEl.textContent = opt.querySelector('span:last-child').textContent;
      close();
      btn.focus();
    }

    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      if (list.hidden) { open(); } else { close(); }
    });
    options.forEach(function (opt) {
      opt.addEventListener('click', function (e) { e.stopPropagation(); choose(opt); });
    });
    list.addEventListener('keydown', function (e) {
      var i = options.indexOf(document.activeElement);
      if (e.key === 'ArrowDown') { e.preventDefault(); (options[i + 1] || options[0]).focus(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); (options[i - 1] || options[options.length - 1]).focus(); }
      else if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); if (options[i]) choose(options[i]); }
      else if (e.key === 'Escape') { e.preventDefault(); close(); btn.focus(); }
    });
    document.addEventListener('click', function (e) {
      if (!list.hidden && !root.contains(e.target)) close();
    });
  });
})();
</script>
HTML;
}
