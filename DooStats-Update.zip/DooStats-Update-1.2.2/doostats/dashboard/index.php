<?php

declare(strict_types=1);

require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/_layout.php';

auth_boot();
if (!auth_is_configured()) {
    header('Location: ../setup.php');
    exit;
}
auth_require_login();
// Read-only page: release the session lock so the live poll and reloads don't
// serialise behind one another.
auth_release_session();

$cfg = analytics_config();
$brandHex = (string) ($cfg['brand_hex'] ?? doostats_brand_default());
$siteName = (string) ($cfg['site_name'] ?? t('nav.brand_fallback'));

$retentionDays = analytics_retention_days();
$allowedRanges = ['1', '7', '30'];
if ($retentionDays > 30) {
    $allowedRanges[] = 'all';
}
$rangeFromQuery = isset($_GET['days']);
$rangeParam = $rangeFromQuery
    ? (string) $_GET['days']
    : (string) ($cfg['dashboard_days'] ?? '7');
if (!in_array($rangeParam, $allowedRanges, true)) {
    $rangeParam = $rangeParam === 'all' ? '30' : '7';
}
// Remember the last range the admin picked (query string only — avoid rewriting
// config.php on every plain dashboard load).
if ($rangeFromQuery && (string) ($cfg['dashboard_days'] ?? '') !== $rangeParam) {
    require_once __DIR__ . '/../lib/config-write.php';
    $newCfg = $cfg;
    $newCfg['dashboard_days'] = $rangeParam;
    if (doostats_write_config($newCfg)) {
        $cfg = analytics_config();
    }
}
$rangeAll = $rangeParam === 'all';
if ($rangeAll) {
    $days = $retentionDays;
} else {
    $days = (int) $rangeParam;
}

$emptyMetric = t('dash.metric.empty');
$summary = [
    'total_views' => 0,
    'unique_visitors' => 0,
    'returning_visitors' => 0,
    'top_country' => $emptyMetric,
    'top_country_visitors' => 0,
    'previous_views' => 0,
    'views_change_percent' => null,
    'views_change_fallback' => false,
    'views_change_comparable' => false,
    'views_change_compare_days' => 0,
    'views_change_infinite' => false,
    'views_change_infinite_up' => true,
    'devices' => ['mobile' => 0, 'desktop' => 0, 'tablet' => 0],
];
$daily = ['labels' => [], 'views' => [], 'visitors' => [], 'granularity' => 'day'];
$dailyCompare = ['labels' => [], 'views' => [], 'visitors' => [], 'granularity' => 'day', 'from' => '', 'to' => ''];
$hourly = ['labels' => [], 'values' => []];
$visitorsByCountry = ['labels' => [], 'values' => []];
$topPages = ['labels' => [], 'values' => []];
$topReferrers = ['labels' => [], 'values' => []];
$browsers = ['labels' => [], 'values' => []];
$eventRows = [];
$notFoundRows = [];
$dbError = false;
$processVisitorIp = analytics_process_visitor_ip();

try {
    $summary = array_merge($summary, analytics_dashboard_summary($days));
    $daily = analytics_daily_series($days);
    $dailyCompare = analytics_previous_daily_series($days);
    $hourly = analytics_hourly_series($days);
    $browsers = analytics_browsers_chart($days, 10);
    if ($processVisitorIp) {
        $visitorsByCountry = analytics_visitors_by_country($days, 10);
    } else {
        // Without IP processing there is no visitor identity or geo.
        $daily['visitors'] = [];
        $dailyCompare['visitors'] = [];
        $summary['unique_visitors'] = 0;
        $summary['returning_visitors'] = 0;
        $summary['top_country'] = $emptyMetric;
        $summary['top_country_visitors'] = 0;
    }
    $topPages = analytics_top_pages_chart($days, 100);
    $topReferrers = analytics_top_referrers_chart($days, 100);
    $eventRows = analytics_event_rows($days);
    $notFoundRows = analytics_not_found_rows($days, 100);
} catch (Throwable $e) {
    $dbError = true;
}

// Colour palette derived from the brand hex.
$rgb = sscanf($brandHex, '#%02x%02x%02x');
[$br, $bg, $bb] = is_array($rgb) && count($rgb) === 3 ? $rgb : [24, 119, 242];
$lighten = static fn (int $c): int => (int) round($c + (255 - $c) * 0.45);
$darken = static fn (int $c): int => (int) round($c * 0.62);
$tint = static fn (float $t): string => sprintf(
    '#%02x%02x%02x',
    (int) round($br + (255 - $br) * $t),
    (int) round($bg + (255 - $bg) * $t),
    (int) round($bb + (255 - $bb) * $t)
);
// Mix brand toward a dark base (for map chrome in dark mode — not toward white).
$mixDark = static function (int $tr, int $tg, int $tb, float $t) use ($br, $bg, $bb): string {
    return sprintf(
        '#%02x%02x%02x',
        (int) round($br + ($tr - $br) * $t),
        (int) round($bg + ($tg - $bg) * $t),
        (int) round($bb + ($tb - $bb) * $t)
    );
};
$palette = [
    'accent' => $brandHex,
    'accentLight' => sprintf('#%02x%02x%02x', $lighten((int) $br), $lighten((int) $bg), $lighten((int) $bb)),
    // Darker brand tint for secondary chart colours on dark backgrounds.
    'accentLightDark' => sprintf('#%02x%02x%02x', $darken((int) $br), $darken((int) $bg), $darken((int) $bb)),
    'accentMuted' => sprintf('rgba(%d, %d, %d, 0.15)', $br, $bg, $bb),
    'theme' => doostats_ui_theme($cfg),
    'text' => '#6b7280',
    'grid' => '#e5e7eb',
    'textDark' => '#9ca3af',
    'gridDark' => '#374151',
    'mapWater' => $tint(0.88),
    'mapLand' => $tint(0.50),
    'mapBorder' => $tint(0.82),
    'mapBorderZoomed' => $tint(0.86),
    // Dark mode: ocean ≈ page charcoal; land a step lighter; borders near water.
    'mapWaterDark' => $mixDark(18, 21, 26, 0.90),
    'mapLandDark' => $mixDark(48, 60, 78, 0.42),
    'mapBorderDark' => $mixDark(24, 28, 34, 0.86),
    'mapBorderZoomedDark' => $mixDark(32, 38, 48, 0.78),
];

if ($rangeAll) {
    $periodBounds = analytics_period_bounds($days);
    $periodLabel = i18n_format_date($periodBounds['from'], 'period')
        . ' – '
        . i18n_format_date($periodBounds['to'], 'period');
} else {
    $periodLabel = analytics_period_label($days);
}

$compareFrom = (string) ($dailyCompare['from'] ?? '');
$compareTo = (string) ($dailyCompare['to'] ?? '');
if ($compareFrom !== '' && $compareTo !== '') {
    if ($compareFrom === $compareTo) {
        $comparePeriodLabel = i18n_format_date($compareTo, 'period');
    } else {
        $comparePeriodLabel = i18n_format_date($compareFrom, 'period')
            . ' – '
            . i18n_format_date($compareTo, 'period');
    }
} else {
    $comparePeriodLabel = t('dash.metric.empty');
}

$chartData = [
    'labels' => $daily['labels'],
    'views' => $daily['views'],
    'visitors' => $daily['visitors'],
    'granularity' => $daily['granularity'] ?? 'day',
    'periodLabel' => $periodLabel,
    'compareLabels' => $dailyCompare['labels'] ?? [],
    'compareViews' => $dailyCompare['views'] ?? [],
    'compareVisitors' => $dailyCompare['visitors'] ?? [],
    'compareGranularity' => $dailyCompare['granularity'] ?? 'day',
    'comparePeriodLabel' => $comparePeriodLabel,
    'hourLabels' => $hourly['labels'],
    'hourValues' => $hourly['values'],
    'browserLabels' => $browsers['labels'],
    'browserValues' => $browsers['values'],
    'countryLabels' => $visitorsByCountry['labels'],
    'countryValues' => $visitorsByCountry['values'],
    'pageLabels' => $topPages['labels'],
    'pageValues' => $topPages['values'],
    'referrerLabels' => $topReferrers['labels'],
    'referrerValues' => $topReferrers['values'],
    'devices' => array_values($summary['devices']),
    'deviceLabels' => [
        t('dash.device.mobile'),
        t('dash.device.desktop'),
        t('dash.device.tablet'),
    ],
];

$esc = static fn (string $v): string => htmlspecialchars($v, ENT_QUOTES, 'UTF-8');
$num = static fn ($v): string => i18n_format_number((int) $v);
$dayOptions = [
    '1' => t('dash.range.today'),
    '7' => t('dash.range.7_days'),
    '30' => t('dash.range.30_days'),
];
if ($retentionDays > 30) {
    $dayOptions['all'] = t('dash.range.all');
}

$refreshSeconds = (int) ($cfg['dashboard_refresh_seconds'] ?? 0);
if (!in_array($refreshSeconds, [30, 60, 300, 600, 1200], true)) {
    $refreshSeconds = 0;
}

$hasTraffic = !$dbError && analytics_has_any_pageviews();
$setupStillPresent = is_file(dirname(__DIR__) . '/setup.php');
// Selected range has nothing at all (pageviews, events, or 404s) — show one
// period empty panel instead of a grid of dashed card placeholders.
$periodEmpty = $hasTraffic
    && (int) ($summary['total_views'] ?? 0) === 0
    && $eventRows === []
    && $notFoundRows === [];

$sumSeries = static function (array $values): int {
  $total = 0;
  foreach ($values as $v) {
    $total += (int) $v;
  }
  return $total;
};
$trafficEmpty = $sumSeries($daily['views'] ?? []) === 0;
$trafficCompareAvailable = !$rangeAll && !$trafficEmpty;
$devicesEmpty = $sumSeries(array_values($summary['devices'] ?? [])) === 0;
$browsersEmpty = ($browsers['labels'] ?? []) === [] || $sumSeries($browsers['values'] ?? []) === 0;
$hoursEmpty = $sumSeries($hourly['values'] ?? []) === 0;
$countryEmpty = ($visitorsByCountry['labels'] ?? []) === [] || $sumSeries($visitorsByCountry['values'] ?? []) === 0;

$trackerSrc = doostats_tracker_src();
$jsSnippet = '<script src="' . $trackerSrc . '" defer></script>';

$jsI18n = i18n_js_dict([
    'js.chart.page_views',
    'js.chart.unique_visitors',
    'js.chart.visitors',
    'js.map.active_one',
    'js.map.active_many',
    'js.map.tooltip',
    'js.pager.prev',
    'js.pager.next',
    'js.pager.page_of',
]);

dashboard_layout_start([
    'title' => $siteName,
    'active' => 'dashboard',
    'brand' => $brandHex,
    'site_name' => $siteName,
    'subtitle' => t('dash.subtitle'),
]);
?>

  <?php if ($dbError): ?>
    <div class="alert alert-warning" role="alert"><?= $esc(t('dash.db_error')) ?></div>
  <?php elseif (!$hasTraffic): ?>
  <div class="card mb-4 onboarding">
    <div class="card-body p-4 p-md-5">
      <h2 class="h4 mb-1"><?= $esc(t('dash.onboarding.title')) ?></h2>
      <p class="text-secondary mb-4"><?= $esc(t('dash.onboarding.intro')) ?></p>

      <?php if ($setupStillPresent): ?>
        <div class="alert alert-warning py-2 mb-4">
          <?= $esc(t('dash.onboarding.delete_setup')) ?>
        </div>
      <?php endif; ?>

      <ol class="onboarding-steps mb-4">
        <li>
          <strong><?= $esc(t('dash.onboarding.step1')) ?></strong>
          <div class="codebox mt-2">
            <pre><code><?= $esc($jsSnippet) ?></code></pre>
            <button type="button" class="codebox-copy" data-copy aria-label="<?= $esc(t('dash.copy_clipboard')) ?>">
              <svg class="ic-copy" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16" aria-hidden="true"><path fill-rule="evenodd" d="M4 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1zM2 5a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1v-1h1v1a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h1v1z"/></svg>
              <svg class="ic-check" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16" aria-hidden="true"><path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0"/></svg>
            </button>
          </div>
          <p class="form-text mb-0 mt-2"><?= $esc(t('dash.onboarding.step1_help')) ?></p>
        </li>
        <li class="mt-4">
          <strong><?= $esc(t('dash.onboarding.step2')) ?></strong>
          <p class="text-secondary mb-0 mt-1"><?= $esc(t('dash.onboarding.step2_help')) ?></p>
        </li>
        <li class="mt-4">
          <strong><?= $esc(t('dash.onboarding.step3')) ?></strong>
          <p class="text-secondary mb-0 mt-1"><?= $esc(t('dash.onboarding.step3_help')) ?></p>
        </li>
      </ol>

      <div class="d-flex flex-wrap gap-2">
        <a class="btn btn-primary" href="snippets.php"><?= $esc(t('dash.onboarding.more_snippets')) ?></a>
        <a class="btn btn-outline-secondary" href="settings.php"><?= $esc(t('dash.onboarding.settings')) ?></a>
        <a class="btn btn-outline-secondary" href="index.php"><?= $esc(t('dash.onboarding.refresh')) ?></a>
      </div>
    </div>
  </div>
  <?php else: ?>

  <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
    <span class="text-secondary"><?= $esc($periodLabel) ?></span>
    <div class="btn-group" role="group" aria-label="<?= $esc(t('dash.range.aria')) ?>">
      <?php foreach ($dayOptions as $value => $label): ?>
        <?php
          $rangeActive = $value === 'all' ? $rangeAll : (!$rangeAll && (string) $days === (string) $value);
          $rangeHref = $value === 'all' ? 'all' : (string) (int) $value;
        ?>
        <a class="btn btn-sm <?= $rangeActive ? 'btn-primary' : 'btn-outline-secondary' ?>" href="?days=<?= $esc($rangeHref) ?>"<?= $rangeActive ? ' aria-current="true"' : '' ?>><?= $esc($label) ?></a>
      <?php endforeach; ?>
    </div>
  </div>

  <?php if ($periodEmpty): ?>
  <div class="card period-empty">
    <div class="card-body period-empty-body">
      <div class="period-empty-icon" aria-hidden="true">
        <svg xmlns="http://www.w3.org/2000/svg" width="56" height="56" fill="none" viewBox="0 0 56 56">
          <rect x="6" y="10" width="44" height="36" rx="6" stroke="currentColor" stroke-width="2" opacity="0.35"/>
          <path d="M16 34v-6M24 34V22M32 34v-10M40 34V18" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" opacity="0.55"/>
          <circle cx="40" cy="18" r="3" fill="currentColor" opacity="0.85"/>
        </svg>
      </div>
      <h2 class="h4 mb-2"><?= $esc(t('dash.period_empty.title')) ?></h2>
      <p class="text-secondary mb-2"><?= $esc(t('dash.period_empty.intro', ['period' => $periodLabel])) ?></p>
      <p class="text-secondary small mb-0"><?= $esc(t('dash.period_empty.hint')) ?></p>
    </div>
  </div>
  <?php else: ?>

  <div class="row g-3 mb-3">
    <div class="<?= $processVisitorIp ? 'col-12 col-md-4' : 'col-12' ?>">
      <div class="card h-100"><div class="card-body">
        <div class="text-secondary"><?= $esc(t('dash.metric.page_views')) ?></div>
        <div class="metric-value"><?= $num($summary['total_views']) ?></div>
      </div></div>
    </div>
    <?php if ($processVisitorIp): ?>
    <div class="col-12 col-md-4">
      <div class="card h-100"><div class="card-body">
        <div class="text-secondary"><?= $esc(t('dash.metric.unique_visitors')) ?></div>
        <div class="metric-value"><?= $num($summary['unique_visitors']) ?></div>
      </div></div>
    </div>
    <div class="col-12 col-md-4">
      <div class="card h-100"><div class="card-body">
        <div class="text-secondary"><?= $esc(t('dash.metric.returning_visitors')) ?></div>
        <div class="metric-value"><?= $num($summary['returning_visitors']) ?></div>
      </div></div>
    </div>
    <?php endif; ?>
  </div>

  <div class="row g-3 mb-3">
    <div class="col-lg-9">
      <div class="card h-100"><div class="card-body">
        <div class="card-title-row">
          <h2 class="card-title h5 mb-0"><?= $esc(t('dash.chart.daily_traffic')) ?></h2>
          <?php if ($trafficCompareAvailable): ?>
          <div class="form-check form-switch mb-0 traffic-compare-switch" id="traffic-compare-switch">
            <input class="form-check-input" type="checkbox" role="switch" id="traffic-compare-toggle" />
            <label class="form-check-label" for="traffic-compare-toggle"><?= $esc(t('dash.chart.compare')) ?></label>
          </div>
          <?php endif; ?>
        </div>
        <?php if ($trafficEmpty): ?>
          <div class="empty"><?= $esc(t('dash.empty.traffic')) ?></div>
        <?php else: ?>
          <div id="traffic-single">
            <div class="chart-box"><canvas id="chart-traffic"></canvas></div>
          </div>
          <?php if ($trafficCompareAvailable): ?>
          <div id="traffic-compare" class="d-none">
            <div class="traffic-compare-pane">
              <div class="small text-secondary mb-1"><?= $esc(t('dash.chart.compare_current')) ?> · <?= $esc($periodLabel) ?></div>
              <div class="chart-box chart-box-half"><canvas id="chart-traffic-current"></canvas></div>
            </div>
            <div class="traffic-compare-pane mt-2">
              <div class="small text-secondary mb-1"><?= $esc(t('dash.chart.compare_previous')) ?> · <?= $esc($comparePeriodLabel) ?></div>
              <div class="chart-box chart-box-half"><canvas id="chart-traffic-previous"></canvas></div>
            </div>
          </div>
          <?php endif; ?>
        <?php endif; ?>
      </div></div>
    </div>
    <div class="col-lg-3">
      <div class="card h-100"><div class="card-body">
        <h2 class="card-title h5"><?= $esc(t('dash.chart.devices')) ?></h2>
        <?php if ($devicesEmpty): ?>
          <div class="empty"><?= $esc(t('dash.empty.devices')) ?></div>
        <?php else: ?>
          <div class="chart-box"><canvas id="chart-devices"></canvas></div>
        <?php endif; ?>
      </div></div>
    </div>
  </div>

  <?php
    $viewsChange = $summary['views_change_percent'] ?? null;
    $viewsFallback = !empty($summary['views_change_fallback']);
    $viewsCompareDays = (int) ($summary['views_change_compare_days'] ?? 0);
    $viewsInfinite = false;
    $viewsChangeHtml = $esc(t('dash.metric.empty'));
    $caretUp = '<svg class="metric-caret" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><path d="M7.247 4.86l-4.796 5.481c-.566.647-.106 1.659.753 1.659h9.592a1 1 0 0 0 .753-1.659l-4.796-5.481a1 1 0 0 0-1.506 0z"/></svg>';
    $caretDown = '<svg class="metric-caret" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><path d="M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z"/></svg>';
    if (is_numeric($viewsChange)) {
      $pct = (int) round((float) $viewsChange);
      $pctText = $esc(i18n_format_percent(abs($pct)));
      if ($pct > 0) {
        $viewsChangeHtml = '<span class="metric-perf">' . $caretUp . '<span>' . $pctText . '</span></span>';
      } elseif ($pct < 0) {
        $viewsChangeHtml = '<span class="metric-perf">' . $caretDown . '<span>' . $pctText . '</span></span>';
      } else {
        $viewsChangeHtml = $pctText;
      }
    } elseif ((int) ($summary['total_views'] ?? 0) > 0 && (int) ($summary['previous_views'] ?? 0) === 0) {
      // No previous pageviews to divide by (empty prior window, or All).
      $viewsInfinite = true;
      $viewsChangeHtml = '<span class="metric-perf">' . $caretUp . '<span>' . $esc(t('dash.perf.infinite')) . '</span></span>';
    } elseif ((int) ($summary['total_views'] ?? 0) === 0 && (int) ($summary['previous_views'] ?? 0) > 0) {
      $viewsInfinite = true;
      $viewsChangeHtml = '<span class="metric-perf">' . $caretDown . '<span>' . $esc(t('dash.perf.infinite')) . '</span></span>';
    }
  ?>
  <div class="row g-3 mb-3">
    <div class="<?= $processVisitorIp ? 'col-12 col-md-6' : 'col-12' ?>">
      <div class="card h-100"><div class="card-body">
        <div class="text-secondary"><?= $esc(t('dash.metric.performance')) ?></div>
        <div class="metric-value"><?= $viewsChangeHtml ?></div>
        <?php if ($viewsInfinite): ?>
          <div class="small text-secondary"><?= $esc(t('dash.perf.no_previous_note')) ?></div>
        <?php elseif ($viewsFallback && $viewsCompareDays > 0): ?>
          <div class="small text-secondary"><?= $esc(tn('dash.perf.fallback_note_one', 'dash.perf.fallback_note_many', $viewsCompareDays)) ?></div>
        <?php endif; ?>
      </div></div>
    </div>
    <?php if ($processVisitorIp): ?>
    <div class="col-12 col-md-6">
      <div class="card h-100"><div class="card-body">
        <div class="text-secondary"><?= $esc(t('dash.metric.pages_per_visitor')) ?></div>
        <div class="metric-value"><?= $esc(i18n_format_number((float) ($summary['pages_per_visitor'] ?? 0), 1)) ?></div>
      </div></div>
    </div>
    <?php endif; ?>
  </div>

  <div class="row g-3 mb-3">
    <div class="col-lg-4">
      <div class="card h-100"><div class="card-body">
        <h2 class="card-title h5"><?= $esc(t('dash.chart.top_browsers')) ?></h2>
        <?php if ($browsersEmpty): ?>
          <div class="empty"><?= $esc(t('dash.empty.browsers')) ?></div>
        <?php else: ?>
          <div class="chart-box"><canvas id="chart-browsers"></canvas></div>
        <?php endif; ?>
      </div></div>
    </div>
    <div class="col-lg-8">
      <div class="card h-100"><div class="card-body">
        <h2 class="card-title h5"><?= $esc(t('dash.chart.peak_times')) ?></h2>
        <?php if ($hoursEmpty): ?>
          <div class="empty"><?= $esc(t('dash.empty.peak_times')) ?></div>
        <?php else: ?>
          <div class="chart-box"><canvas id="chart-hours"></canvas></div>
        <?php endif; ?>
      </div></div>
    </div>
  </div>

  <?php if ($processVisitorIp): ?>
  <div class="row g-3 mb-3">
    <div class="col-lg-6">
      <div class="card h-100"><div class="card-body">
        <h2 class="card-title h5 mb-0"><?= $esc(t('dash.chart.live_visitors')) ?></h2>
        <div id="map" class="mt-3" role="button" tabindex="0" aria-label="<?= $esc(t('dash.map.expand')) ?>" data-bs-toggle="modal" data-bs-target="#mapModal"></div>
        <p class="text-secondary small mt-2 mb-0" id="map-status"><?= $esc(t('dash.map.loading')) ?></p>
      </div></div>
    </div>
    <div class="col-lg-6">
      <div class="card h-100"><div class="card-body d-flex flex-column">
        <h2 class="card-title h5"><?= $esc(t('dash.chart.visitors_by_country')) ?></h2>
        <?php if ($countryEmpty): ?>
          <div class="empty chart-box-fill mt-2 d-flex align-items-center justify-content-center"><?= $esc(t('dash.empty.countries')) ?></div>
        <?php else: ?>
          <div class="chart-box chart-box-fill mt-2"><canvas id="chart-country"></canvas></div>
        <?php endif; ?>
      </div></div>
    </div>
  </div>
  <?php endif; ?>

  <div class="dash-table-grid mb-3">
    <div class="card h-100"><div class="card-body">
      <h2 class="card-title h5"><?= $esc(t('dash.chart.top_pages')) ?></h2>
      <?php if ($topPages['labels'] === []): ?>
        <div class="empty"><?= $esc(t('dash.empty.pageviews')) ?></div>
      <?php else: ?>
        <table class="table table-sm table-stats align-middle mb-0" data-paginate data-page-size="10">
          <thead><tr><th class="col-label"><?= $esc(t('dash.table.path')) ?></th><th class="col-count text-end"><?= $esc(t('dash.table.views')) ?></th></tr></thead>
          <tbody>
          <?php foreach ($topPages['labels'] as $i => $label): ?>
            <?php $labelStr = (string) $label; ?>
            <tr>
              <td class="col-label"><span class="truncate-start" title="<?= $esc($labelStr) ?>"><span><?= $esc($labelStr) ?></span></span></td>
              <td class="col-count text-end"><span class="badge rounded-pill text-bg-primary"><?= $num($topPages['values'][$i] ?? 0) ?></span></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div></div>

    <div class="card h-100"><div class="card-body">
      <h2 class="card-title h5"><?= $esc(t('dash.chart.top_referrers')) ?></h2>
      <?php if ($topReferrers['labels'] === []): ?>
        <div class="empty"><?= $esc(t('dash.empty.referrers')) ?></div>
      <?php else: ?>
        <table class="table table-sm table-stats align-middle mb-0" data-paginate data-page-size="10">
          <thead><tr><th class="col-label"><?= $esc(t('dash.table.source')) ?></th><th class="col-count text-end"><?= $esc(t('dash.table.views')) ?></th></tr></thead>
          <tbody>
          <?php foreach ($topReferrers['labels'] as $i => $label): ?>
            <?php $labelStr = (string) $label; ?>
            <tr>
              <td class="col-label"><span class="truncate-start" title="<?= $esc($labelStr) ?>"><span><?= $esc($labelStr) ?></span></span></td>
              <td class="col-count text-end"><span class="badge rounded-pill text-bg-primary"><?= $num($topReferrers['values'][$i] ?? 0) ?></span></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div></div>

    <div class="card h-100"><div class="card-body">
      <h2 class="card-title h5"><?= $esc(t('dash.chart.events')) ?></h2>
      <?php if ($eventRows === []): ?>
        <div class="empty"><?= $esc(t('dash.empty.events')) ?></div>
      <?php else: ?>
        <table class="table table-sm table-stats align-middle mb-0" data-paginate data-page-size="10">
          <thead><tr><th class="col-label"><?= $esc(t('dash.table.event')) ?></th><th class="col-count text-end"><?= $esc(t('dash.table.count')) ?></th></tr></thead>
          <tbody>
          <?php foreach ($eventRows as $row): ?>
            <?php $labelStr = (string) $row['label']; ?>
            <tr>
              <td class="col-label"><span class="truncate-end" title="<?= $esc($labelStr) ?>"><?= $esc($labelStr) ?></span></td>
              <td class="col-count text-end"><span class="badge rounded-pill text-bg-primary"><?= $num($row['count']) ?></span></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div></div>

    <div class="card h-100"><div class="card-body">
      <h2 class="card-title h5"><?= $esc(t('dash.chart.not_found')) ?></h2>
      <?php if ($notFoundRows === []): ?>
        <div class="empty"><?= $esc(t('dash.empty.not_found')) ?></div>
      <?php else: ?>
        <table class="table table-sm table-stats align-middle mb-0" data-paginate data-page-size="10">
          <thead><tr><th class="col-label"><?= $esc(t('dash.table.path')) ?></th><th class="col-count text-end"><?= $esc(t('dash.table.hits')) ?></th></tr></thead>
          <tbody>
          <?php foreach ($notFoundRows as $row): ?>
            <?php $labelStr = (string) ($row['path'] ?? ''); ?>
            <tr>
              <td class="col-label"><span class="truncate-start" title="<?= $esc($labelStr) ?>"><span><?= $esc($labelStr) ?></span></span></td>
              <td class="col-count text-end"><span class="badge rounded-pill text-bg-primary"><?= $num($row['hits'] ?? ($row['count'] ?? 0)) ?></span></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div></div>
  </div>

  <?php if ($processVisitorIp): ?>
  <div class="modal fade" id="mapModal" tabindex="-1" aria-hidden="true" aria-labelledby="mapModalLabel">
    <div class="modal-dialog modal-xl modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h2 class="modal-title h5" id="mapModalLabel"><?= $esc(t('dash.map.modal_title')) ?></h2>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?= $esc(t('dash.map.close')) ?>"></button>
        </div>
        <div class="modal-body">
          <div id="mapModalCanvas" class="modal-map"></div>
          <p class="text-secondary small mt-3 mb-0"><?= $esc(t('dash.map.hint')) ?></p>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>

<script src="../assets/chart.umd.min.js"></script>
<?php if ($processVisitorIp): ?>
<script src="../assets/geo/world-50m.js?v=<?= (int) @filemtime(__DIR__ . '/../assets/geo/world-50m.js') ?>"></script>
<script src="../assets/geo/worldmap.js?v=<?= (int) @filemtime(__DIR__ . '/../assets/geo/worldmap.js') ?>"></script>
<?php endif; ?>
<script>
  const CHART = <?= json_encode($chartData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
  const PALETTE = <?= json_encode($palette, JSON_UNESCAPED_SLASHES) ?>;
  const PROCESS_VISITOR_IP = <?= $processVisitorIp ? 'true' : 'false' ?>;
  const I18N = <?= json_encode($jsI18n, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
  const UI_LOCALE = <?= json_encode(str_replace('_', '-', i18n_language()), JSON_UNESCAPED_UNICODE) ?>;
  function formatNumber(n) {
    try {
      return new Intl.NumberFormat(UI_LOCALE, { maximumFractionDigits: 0 }).format(Number(n));
    } catch (e) {
      return String(n);
    }
  }
  function numTick(value) {
    return formatNumber(value);
  }

  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('table[data-paginate]').forEach(function (t) {
      try {
        paginateTable(t, parseInt(t.getAttribute('data-page-size') || '10', 10));
      } catch (e) {}
    });
    try { initCharts(); } catch (e) {}
    if (PROCESS_VISITOR_IP) {
      try { initMap(); } catch (e) {}
    }
  });

  function initCharts() {
    if (!window.Chart) return;
    const isDarkTheme = function () {
      if (PALETTE.theme === 'dark') return true;
      if (PALETTE.theme === 'light') return false;
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    };
    const dark = isDarkTheme();
    const accentSecondary = dark ? (PALETTE.accentLightDark || PALETTE.accentLight) : PALETTE.accentLight;
    const softFill = function (hex) {
      const m = /^#?([0-9a-f]{6})$/i.exec(hex || '');
      if (!m) return PALETTE.accentMuted;
      const n = parseInt(m[1], 16);
      const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
      return 'rgba(' + r + ', ' + g + ', ' + b + ', 0.15)';
    };
    const chrome = dark
      ? { text: PALETTE.textDark || '#9ca3af', grid: PALETTE.gridDark || '#374151' }
      : { text: PALETTE.text, grid: PALETTE.grid };
    const baseScales = {
      x: { ticks: { color: chrome.text, maxRotation: 0, autoSkip: true, maxTicksLimit: 8 }, grid: { display: false } },
      y: { ticks: { color: chrome.text, precision: 0, callback: numTick }, grid: { color: chrome.grid }, beginAtZero: true },
    };

    const traffic = document.getElementById('chart-traffic');
    const trafficCurrent = document.getElementById('chart-traffic-current');
    const trafficPrevious = document.getElementById('chart-traffic-previous');
    const trafficSingle = document.getElementById('traffic-single');
    const trafficCompare = document.getElementById('traffic-compare');
    const trafficToggle = document.getElementById('traffic-compare-toggle');

    function trafficDatasets(views, visitors) {
      const datasets = [
        { label: I18N['js.chart.page_views'], data: views, borderColor: PALETTE.accent, backgroundColor: softFill(PALETTE.accent), fill: true, tension: 0.35, pointRadius: 2 },
      ];
      if (visitors && visitors.length) {
        datasets.push(
          { label: I18N['js.chart.unique_visitors'], data: visitors, borderColor: accentSecondary, backgroundColor: 'transparent', tension: 0.35, pointRadius: 2, borderDash: [6, 4] }
        );
      }
      return datasets;
    }

    function seriesMax(values) {
      let m = 0;
      (values || []).forEach(function (v) {
        const n = Number(v) || 0;
        if (n > m) m = n;
      });
      return m;
    }

    const sharedYMax = Math.max(
      seriesMax(CHART.views),
      seriesMax(CHART.visitors),
      seriesMax(CHART.compareViews),
      seriesMax(CHART.compareVisitors),
      1
    );

    function trafficScales(granularity, sharedY) {
      const scales = Object.assign({}, baseScales, {
        x: Object.assign({}, baseScales.x, {
          ticks: Object.assign({}, baseScales.x.ticks, {
            maxTicksLimit: granularity === 'hour' ? 12 : 8,
          }),
        }),
        // Headroom so peak points/strokes aren't clipped at the chart top.
        y: Object.assign({}, baseScales.y, { grace: '12%' }),
      });
      if (sharedY) {
        // Explicit max disables grace — pad the shared ceiling instead.
        const padded = Math.max(1, Math.ceil(sharedYMax * 1.12));
        scales.y = Object.assign({}, scales.y, { max: padded });
      }
      return scales;
    }

    let chartTraffic = null;
    let chartTrafficCurrent = null;
    let chartTrafficPrevious = null;

    if (traffic) {
      chartTraffic = new Chart(traffic, {
        type: 'line',
        data: { labels: CHART.labels, datasets: trafficDatasets(CHART.views, CHART.visitors) },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { labels: { color: chrome.text } } },
          scales: trafficScales(CHART.granularity, false),
        },
      });
    }

    if (trafficCurrent) {
      chartTrafficCurrent = new Chart(trafficCurrent, {
        type: 'line',
        data: { labels: CHART.labels, datasets: trafficDatasets(CHART.views, CHART.visitors) },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: trafficScales(CHART.granularity, true),
        },
      });
    }

    if (trafficPrevious) {
      chartTrafficPrevious = new Chart(trafficPrevious, {
        type: 'line',
        data: {
          labels: CHART.compareLabels,
          datasets: trafficDatasets(CHART.compareViews, CHART.compareVisitors),
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: trafficScales(CHART.compareGranularity, true),
        },
      });
    }

    if (trafficToggle && trafficSingle && trafficCompare) {
      const storageKey = 'doostats.trafficCompare';
      const switchWrap = document.getElementById('traffic-compare-switch');
      function setCompareMode(on, animate) {
        if (!animate && switchWrap) {
          switchWrap.classList.add('traffic-compare-no-anim');
        }
        trafficToggle.checked = !!on;
        trafficSingle.classList.toggle('d-none', on);
        trafficCompare.classList.toggle('d-none', !on);
        try { localStorage.setItem(storageKey, on ? '1' : '0'); } catch (e) {}
        window.requestAnimationFrame(function () {
          if (on) {
            if (chartTrafficCurrent) chartTrafficCurrent.resize();
            if (chartTrafficPrevious) chartTrafficPrevious.resize();
          } else if (chartTraffic) {
            chartTraffic.resize();
          }
          if (!animate && switchWrap) {
            // Drop the no-anim class after the checked state has painted.
            window.requestAnimationFrame(function () {
              switchWrap.classList.remove('traffic-compare-no-anim');
            });
          }
        });
      }
      let initialOn = false;
      try { initialOn = localStorage.getItem(storageKey) === '1'; } catch (e) {}
      setCompareMode(initialOn, false);
      trafficToggle.addEventListener('change', function () {
        setCompareMode(trafficToggle.checked, true);
      });
    }

    const devices = document.getElementById('chart-devices');
    if (devices) {
      new Chart(devices, {
        type: 'doughnut',
        data: { labels: CHART.deviceLabels, datasets: [{ data: CHART.devices, backgroundColor: [PALETTE.accent, accentSecondary, chrome.grid], borderWidth: 0 }] },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { color: chrome.text } } } },
      });
    }

    const browsers = document.getElementById('chart-browsers');
    if (browsers) {
      new Chart(browsers, {
        type: 'bar',
        data: {
          labels: CHART.browserLabels,
          datasets: [{
            label: I18N['js.chart.page_views'],
            data: CHART.browserValues,
            backgroundColor: PALETTE.accent,
            borderRadius: 6,
            maxBarThickness: 18,
          }],
        },
        options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { ticks: { color: chrome.text, precision: 0, callback: numTick }, grid: { color: chrome.grid }, beginAtZero: true }, y: { ticks: { color: chrome.text }, grid: { display: false } } } },
      });
    }

    const hours = document.getElementById('chart-hours');
    if (hours) {
      new Chart(hours, {
        type: 'bar',
        data: {
          labels: CHART.hourLabels,
          datasets: [{
            label: I18N['js.chart.page_views'],
            data: CHART.hourValues,
            backgroundColor: PALETTE.accent,
            borderRadius: 4,
            maxBarThickness: 18,
          }],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: {
            x: { ticks: { color: chrome.text, maxRotation: 0, autoSkip: false }, grid: { display: false } },
            y: { ticks: { color: chrome.text, precision: 0, callback: numTick }, grid: { color: chrome.grid }, beginAtZero: true },
          },
        },
      });
    }

    const country = document.getElementById('chart-country');
    if (country) {
      new Chart(country, {
        type: 'bar',
        data: {
          labels: CHART.countryLabels,
          datasets: [{
            label: I18N['js.chart.visitors'],
            data: CHART.countryValues,
            backgroundColor: PALETTE.accent,
            borderRadius: 6,
            maxBarThickness: 18,
          }],
        },
        options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { ticks: { color: chrome.text, precision: 0, callback: numTick }, grid: { color: chrome.grid }, beginAtZero: true }, y: { ticks: { color: chrome.text }, grid: { display: false } } } },
      });
    }
  }

  function initMap() {
    const el = document.getElementById('map');
    const status = document.getElementById('map-status');
    if (!el || typeof window.createDooboxWorldMap !== 'function') return;
    const dark = PALETTE.theme === 'dark' || (PALETTE.theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
    const baseOpts = {
      accent: PALETTE.accent,
      accentLight: PALETTE.accentLight,
      water: dark ? (PALETTE.mapWaterDark || PALETTE.mapWater) : PALETTE.mapWater,
      land: dark ? (PALETTE.mapLandDark || PALETTE.mapLand) : PALETTE.mapLand,
      border: dark ? (PALETTE.mapBorderDark || PALETTE.mapBorder) : PALETTE.mapBorder,
      borderZoomed: dark ? (PALETTE.mapBorderZoomedDark || PALETTE.mapBorderZoomed) : PALETTE.mapBorderZoomed,
      dotFill: dark ? '#e5e7eb' : '#ffffff',
      dotFillOpacity: dark ? 0.95 : 1,
      dotStrokeOpacity: dark ? 0.92 : 1,
      formatNumber: formatNumber,
      formatTooltip: function (country, countText) {
        return (I18N['js.map.tooltip'] || '{country}: {count} active')
          .replace('{country}', country)
          .replace('{count}', countText);
      },
    };
    const inlineMap = window.createDooboxWorldMap(el, Object.assign({ interactive: false, fit: 'world' }, baseOpts));
    el.style.cursor = 'pointer';
    el.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        el.click();
      }
    });
    let modalMap = null;
    let points = [];

    const modalEl = document.getElementById('mapModal');
    if (modalEl) {
      modalEl.addEventListener('shown.bs.modal', function () {
        if (!modalMap) {
          modalMap = window.createDooboxWorldMap(document.getElementById('mapModalCanvas'), Object.assign({ interactive: true, fit: 'world' }, baseOpts));
        }
        modalMap.setPoints(points);
      });
    }

    let polling = false;
    function refresh() {
      if (polling || document.hidden) return;
      polling = true;
      fetch('live.php', { credentials: 'same-origin', cache: 'no-store' })
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (data) {
          if (!data || !data.ok) return;
          points = data.active_visitors_map || [];
          inlineMap.setPoints(points);
          if (modalMap) modalMap.setPoints(points);
          const total = data.active_visitors_total || 0;
          status.textContent = total === 1
            ? I18N['js.map.active_one']
            : I18N['js.map.active_many'].replace('{count}', formatNumber(total));
        })
        .catch(function () {})
        .finally(function () { polling = false; });
    }
    refresh();
    setInterval(refresh, 15000);
    document.addEventListener('visibilitychange', function () {
      if (!document.hidden) refresh();
    });
  }

  function paginateTable(table, pageSize) {
    const rows = Array.prototype.slice.call(table.tBodies[0].rows);
    if (rows.length <= pageSize) return;
    let page = 0;
    const pages = Math.ceil(rows.length / pageSize);
    const windowSize = 5;

    const nav = document.createElement('nav');
    nav.className = 'table-pager';
    nav.setAttribute('aria-label', 'Pagination');
    const ul = document.createElement('ul');
    ul.className = 'pagination pagination-sm mb-0 justify-content-center';
    nav.appendChild(ul);
    table.parentNode.insertBefore(nav, table.nextSibling);

    function makeItem(opts) {
      const li = document.createElement('li');
      li.className = 'page-item' + (opts.disabled ? ' disabled' : '') + (opts.active ? ' active' : '');
      if (opts.active) {
        li.setAttribute('aria-current', 'page');
        const span = document.createElement('span');
        span.className = 'page-link';
        span.textContent = opts.text;
        li.appendChild(span);
        return li;
      }
      const a = document.createElement('a');
      a.className = 'page-link';
      a.href = '#';
      if (opts.label) a.setAttribute('aria-label', opts.label);
      a.textContent = opts.text;
      if (opts.disabled) {
        a.setAttribute('tabindex', '-1');
        a.setAttribute('aria-disabled', 'true');
        a.addEventListener('click', function (e) { e.preventDefault(); });
      } else if (opts.onClick) {
        a.addEventListener('click', function (e) {
          e.preventDefault();
          opts.onClick();
        });
      }
      li.appendChild(a);
      return li;
    }

    function pageWindow(current, total, size) {
      if (total <= size) {
        return { start: 0, end: total - 1 };
      }
      let start = current - Math.floor(size / 2);
      let end = start + size - 1;
      if (start < 0) {
        start = 0;
        end = size - 1;
      }
      if (end > total - 1) {
        end = total - 1;
        start = end - size + 1;
      }
      return { start: start, end: end };
    }

    function render() {
      rows.forEach(function (row, i) {
        row.style.display = i >= page * pageSize && i < (page + 1) * pageSize ? '' : 'none';
      });

      const prevLabel = I18N['js.pager.prev'] || 'Previous';
      const nextLabel = I18N['js.pager.next'] || 'Next';
      const win = pageWindow(page, pages, windowSize);
      ul.textContent = '';
      ul.appendChild(makeItem({
        disabled: page === 0,
        label: prevLabel,
        text: prevLabel,
        onClick: function () { page--; render(); },
      }));
      for (let p = win.start; p <= win.end; p++) {
        ul.appendChild(makeItem({
          active: p === page,
          text: formatNumber(p + 1),
          onClick: (function (target) {
            return function () { page = target; render(); };
          })(p),
        }));
      }
      ul.appendChild(makeItem({
        disabled: page >= pages - 1,
        label: nextLabel,
        text: nextLabel,
        onClick: function () { page++; render(); },
      }));
    }

    render();
  }
</script>
  <?php endif; /* periodEmpty */ ?>
  <?php endif; /* hasTraffic */ ?>

<?php
$onboardingScript = '';
if (!$dbError && !$hasTraffic) {
    $onboardingScript = <<<'HTML'
<script>
(function () {
  document.querySelectorAll('[data-copy]').forEach(function (btn) {
    var timer;
    function done() {
      btn.classList.add('is-copied');
      clearTimeout(timer);
      timer = setTimeout(function () { btn.classList.remove('is-copied'); }, 1500);
    }
    btn.addEventListener('click', function () {
      var pre = btn.closest('.codebox').querySelector('pre');
      var text = pre ? pre.innerText : '';
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(done).catch(function () {});
      } else {
        var ta = document.createElement('textarea');
        ta.value = text; document.body.appendChild(ta); ta.select();
        try { document.execCommand('copy'); done(); } catch (e) {}
        document.body.removeChild(ta);
      }
    });
  });
})();
</script>
HTML;
}

$refreshScript = '';
if ($refreshSeconds >= 30) {
    $refreshScript = '<script>(function(){var sec=' . (int) $refreshSeconds . ';'
        . 'if(sec<30)return;'
        . 'setInterval(function(){if(document.hidden)return;window.location.reload();},sec*1000);'
        . '})();</script>';
}

dashboard_layout_end($onboardingScript . $refreshScript);
?>
