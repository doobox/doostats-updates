<?php

declare(strict_types=1);

require_once __DIR__ . '/_layout.php';
require_once __DIR__ . '/../lib/brand-palette.php';
require_once __DIR__ . '/../lib/update-check.php';
require_once __DIR__ . '/../lib/digest.php';
require_once __DIR__ . '/../lib/settings-save.php';

$ctx = dashboard_guard();
$cfg = $ctx['cfg'];

$errors = [];
$notice = '';
$reportsErrors = [];
$reportsNotice = '';
$sectionNotices = [
    'general' => '',
    'profile' => '',
    'password' => '',
    'advanced' => '',
    'danger' => '',
];
$sectionErrors = [
    'general' => [],
    'profile' => [],
    'password' => [],
    'advanced' => [],
    'danger' => [],
];
$updateResult = null;
$availableLanguages = i18n_available_languages();

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $form = (string) ($_POST['form'] ?? '');

    if (!auth_check_csrf($_POST['csrf'] ?? null)) {
        $errors[] = t('settings.error.csrf');
    } elseif ($form === 'update_check') {
        // Fallback when JS is unavailable; AJAX uses update-check.php.
        $updateResult = doostats_public_update_result(doostats_check_for_updates());
    } elseif (in_array($form, ['general', 'advanced', 'password', 'profile', 'avatar_remove', 'reports', 'reset_stats'], true)) {
        $saved = doostats_settings_save($form, $cfg, $_POST, $_FILES);
        $cfg = $saved['cfg'];
        if ($form === 'general') {
            $ctx['brand'] = (string) ($cfg['brand_hex'] ?? $ctx['brand']);
            $ctx['site_name'] = (string) ($cfg['site_name'] ?? $ctx['site_name']);
        }
        if ($form === 'profile' || $form === 'avatar_remove') {
            $ctx['user_name'] = (string) (($cfg['user_name'] ?? '') !== '' ? $cfg['user_name'] : t('nav.user_fallback'));
        }
        if ($form === 'reports') {
            if ($saved['ok']) {
                $reportsNotice = $saved['message'];
            } else {
                $reportsErrors = $saved['errors'] !== [] ? $saved['errors'] : [$saved['message']];
            }
        } else {
            $card = match ($form) {
                'general' => 'general',
                'advanced' => 'advanced',
                'password' => 'password',
                'profile', 'avatar_remove' => 'profile',
                'reset_stats' => 'danger',
                default => 'general',
            };
            if ($saved['ok']) {
                $sectionNotices[$card] = $saved['message'];
                $notice = $saved['message'];
            } else {
                $sectionErrors[$card] = $saved['errors'] !== [] ? $saved['errors'] : [$saved['message']];
                $errors = $sectionErrors[$card];
            }
        }
    }
}

$esc = static fn ($v): string => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$selectedTz = (string) ($cfg['timezone'] ?? 'UTC');
$selectedLang = (string) ($cfg['ui_language'] ?? 'en');
if (!isset($availableLanguages[$selectedLang])) {
    $selectedLang = 'en';
}
$ignoreIpsText = implode("\n", (array) ($cfg['ignore_ips'] ?? []));
$excludedPathsText = implode("\n", (array) ($cfg['excluded_paths'] ?? []));
$referrerBlockText = implode("\n", (array) ($cfg['referrer_blocklist'] ?? []));
$filterBots = !array_key_exists('filter_bots', $cfg) || !empty($cfg['filter_bots']);
$processVisitorIp = analytics_process_visitor_ip();
$csrf = auth_csrf_token();

// Resolve the avatar from the (possibly just-updated) local config, so both the
// preview and the top-bar reflect a fresh upload/removal within this request.
$avatarFile = null;
$avatarName = basename((string) ($cfg['avatar'] ?? ''));
if ($avatarName !== '') {
    $avatarDir = rtrim((string) ($cfg['data_dir'] ?? dirname(__DIR__) . '/data'), '/\\');
    if (is_file($avatarDir . '/' . $avatarName)) {
        $avatarFile = $avatarDir . '/' . $avatarName;
    }
}

$installed = doostats_installed_version();
$builtAt = doostats_format_built_at($installed['built']);
$updatesIntro = $builtAt !== ''
    ? t('settings.updates.installed_built', ['version' => $installed['version'], 'built' => $builtAt])
    : t('settings.updates.installed', ['version' => $installed['version']]);

$jsI18n = i18n_js_dict([
    'js.avatar.preview_alt',
    'js.settings.saving',
    'js.settings.failed',
    'js.settings.unreachable',
    'js.updates.checking',
    'js.updates.download',
    'js.updates.install',
    'js.updates.installing',
    'js.updates.install_failed',
    'js.updates.reload_now',
    'js.updates.failed',
    'js.updates.unreachable',
    'js.updates.fallback_help',
    'js.updates.fallback_link',
    'js.reports.sending',
    'js.reports.failed',
    'js.reports.unreachable',
]);

$renderSectionFlash = static function (string $card) use ($sectionNotices, $sectionErrors, $esc): void {
    $notice = (string) ($sectionNotices[$card] ?? '');
    $errs = $sectionErrors[$card] ?? [];
    if ($notice === '' && $errs === []) {
        return;
    }
    if ($notice !== '') {
        echo '<div class="alert alert-success py-2 ui-fade-in" role="status">' . $esc($notice) . '</div>';
    }
    if ($errs !== []) {
        echo '<div class="alert alert-danger py-2 ui-fade-in" role="alert">';
        foreach ($errs as $e) {
            echo '<div>' . $esc($e) . '</div>';
        }
        echo '</div>';
    }
};

dashboard_layout_start([
    'title' => t('settings.title'),
    'active' => 'settings',
    'brand' => $ctx['brand'],
    'site_name' => $ctx['site_name'],
    'user_name' => $ctx['user_name'],
    'subtitle' => t('settings.subtitle'),
    'avatar_file' => $avatarFile,
]);
?>

  <?php
    // Top flash only for CSRF / unexpected errors that are not tied to a card.
    $topOnly = $errors !== [] && $sectionErrors['general'] === [] && $sectionErrors['profile'] === []
        && $sectionErrors['password'] === [] && $sectionErrors['advanced'] === [] && $sectionErrors['danger'] === []
        && $reportsErrors === [];
  ?>
  <?php if ($topOnly): ?>
    <div class="alert alert-danger ui-fade-in" role="alert">
      <?php foreach ($errors as $e): ?><div><?= $esc($e) ?></div><?php endforeach; ?>
    </div>
  <?php endif; ?>

  <div class="settings-forms">
  <div class="row g-4 settings-top align-items-stretch">
    <div class="col-lg-6 d-lg-flex">
      <section class="card flex-grow-1 w-100" data-settings-card="general">
        <div class="card-body p-4">
          <h2 class="card-title h5 mb-1"><?= $esc(t('settings.general.title')) ?></h2>
          <p class="text-secondary mb-4"><?= $esc(t('settings.general.intro')) ?></p>
          <div class="js-settings-result" data-result-for="general"><?php $renderSectionFlash('general'); ?></div>
          <form id="settings-form-general" method="post" data-settings-form="general">
            <input type="hidden" name="csrf" value="<?= $esc($csrf) ?>" />
            <input type="hidden" name="form" value="general" />
            <div class="mb-3">
              <label class="form-label" for="site_name"><?= $esc(t('settings.general.site_name')) ?></label>
              <input id="site_name" class="form-control" type="text" name="site_name" value="<?= $esc($cfg['site_name'] ?? '') ?>" required />
            </div>
            <div class="mb-3">
              <label class="form-label" for="site_url"><?= $esc(t('settings.general.site_url')) ?></label>
              <input id="site_url" class="form-control" type="url" name="site_url" placeholder="<?= $esc(t('settings.general.site_url_placeholder')) ?>" value="<?= $esc($cfg['site_url'] ?? '') ?>" required />
            </div>
            <div class="mb-3">
              <label class="form-label" for="install_path"><?= $esc(t('settings.general.install_path')) ?></label>
              <?php
                $savedInstall = array_key_exists('install_path', $cfg)
                  ? doostats_normalize_install_path((string) $cfg['install_path'])
                  : '';
              ?>
              <input id="install_path" class="form-control font-monospace" type="text" name="install_path" placeholder="<?= $esc(t('settings.general.install_path_placeholder')) ?>" value="<?= $esc($savedInstall) ?>" />
            </div>
            <div class="mb-3">
              <label class="form-label" for="brand_hex_btn"><?= $esc(t('settings.general.brand_colour')) ?></label>
              <?= doostats_brand_select_html((string) ($cfg['brand_hex'] ?? doostats_brand_default())) ?>
            </div>
            <div class="mb-3">
              <label class="form-label" for="timezone"><?= $esc(t('settings.general.timezone')) ?></label>
              <select id="timezone" class="form-select" name="timezone">
                <?php foreach (timezone_identifiers_list() as $tz): ?>
                  <option value="<?= $esc($tz) ?>"<?= $tz === $selectedTz ? ' selected' : '' ?>><?= $esc($tz) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <?php if (count($availableLanguages) > 1): ?>
            <div class="mb-3">
              <label class="form-label" for="ui_language"><?= $esc(t('settings.general.language')) ?></label>
              <select id="ui_language" class="form-select" name="ui_language">
                <?php foreach ($availableLanguages as $code => $name): ?>
                  <option value="<?= $esc($code) ?>"<?= $code === $selectedLang ? ' selected' : '' ?>><?= $esc($name) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <?php endif; ?>
            <div class="mb-3">
              <label class="form-label" for="ui_theme"><?= $esc(t('settings.general.theme')) ?></label>
              <?php $selectedTheme = doostats_ui_theme($cfg); ?>
              <select id="ui_theme" class="form-select" name="ui_theme">
                <option value="light"<?= $selectedTheme === 'light' ? ' selected' : '' ?>><?= $esc(t('settings.general.theme_light')) ?></option>
                <option value="dark"<?= $selectedTheme === 'dark' ? ' selected' : '' ?>><?= $esc(t('settings.general.theme_dark')) ?></option>
                <option value="system"<?= $selectedTheme === 'system' ? ' selected' : '' ?>><?= $esc(t('settings.general.theme_system')) ?></option>
              </select>
            </div>
            <div class="mb-3">
              <label class="form-label" for="retention_days"><?= $esc(t('settings.general.retention')) ?></label>
              <input id="retention_days" class="form-control" type="number" name="retention_days" min="1" max="90" value="<?= $esc((int) ($cfg['retention_days'] ?? 45)) ?>" />
            </div>
            <div class="mb-3">
              <label class="form-label" for="dashboard_refresh_seconds"><?= $esc(t('settings.general.auto_refresh')) ?></label>
              <?php $dashRefresh = (int) ($cfg['dashboard_refresh_seconds'] ?? 0); ?>
              <select id="dashboard_refresh_seconds" class="form-select" name="dashboard_refresh_seconds">
                <option value="0"<?= $dashRefresh === 0 ? ' selected' : '' ?>><?= $esc(t('settings.general.refresh_off')) ?></option>
                <option value="30"<?= $dashRefresh === 30 ? ' selected' : '' ?>><?= $esc(t('settings.general.refresh_30')) ?></option>
                <option value="60"<?= $dashRefresh === 60 ? ' selected' : '' ?>><?= $esc(t('settings.general.refresh_60')) ?></option>
                <option value="300"<?= $dashRefresh === 300 ? ' selected' : '' ?>><?= $esc(t('settings.general.refresh_300')) ?></option>
                <option value="600"<?= $dashRefresh === 600 ? ' selected' : '' ?>><?= $esc(t('settings.general.refresh_600')) ?></option>
                <option value="1200"<?= $dashRefresh === 1200 ? ' selected' : '' ?>><?= $esc(t('settings.general.refresh_1200')) ?></option>
              </select>
            </div>
            <div class="pt-2">
              <button class="btn btn-primary js-settings-submit" type="submit"><?= $esc(t('settings.general.save')) ?></button>
            </div>
          </form>
        </div>
      </section>
    </div>

    <div class="col-lg-6 d-lg-flex">
      <div class="settings-stack">
      <section class="card" data-settings-card="profile">
        <div class="card-body p-4">
          <h2 class="card-title h5 mb-1"><?= $esc(t('settings.profile.title')) ?></h2>
          <p class="text-secondary mb-4"><?= $esc(t('settings.profile.intro')) ?></p>
          <div class="js-settings-result" data-result-for="profile"><?php $renderSectionFlash('profile'); ?></div>
          <form id="settings-form-profile" method="post" enctype="multipart/form-data" autocomplete="off" data-settings-form="profile">
            <input type="hidden" name="csrf" value="<?= $esc($csrf) ?>" />
            <input type="hidden" name="form" value="profile" />
            <div class="mb-3">
              <label class="form-label" for="profile_label"><?= $esc(t('settings.profile.user_name')) ?></label>
              <input id="profile_label" class="form-control" type="text" name="profile_label" value="<?= $esc((string) (($cfg['user_name'] ?? '') !== '' ? $cfg['user_name'] : t('nav.user_fallback'))) ?>" maxlength="20" required autocomplete="off" spellcheck="false" data-1p-ignore data-lpignore="true" />
            </div>
            <div class="mb-3">
              <label class="form-label" for="avatar"><?= $esc(t('settings.profile.avatar')) ?></label>
              <div class="d-flex align-items-start gap-3 flex-wrap">
                <div class="avatar-preview" id="avatarPreview">
                  <?php if ($avatarFile !== null): ?>
                    <img src="avatar.php?v=<?= (int) @filemtime($avatarFile) ?>" alt="<?= $esc(t('settings.profile.avatar_current_alt')) ?>" />
                  <?php else: ?>
                    <?= DASHBOARD_AVATAR_SVG ?>
                  <?php endif; ?>
                </div>
                <div class="flex-grow-1" style="min-width:200px">
                  <input id="avatar" class="form-control" type="file" name="avatar" accept="image/png,image/jpeg,image/gif,image/webp" />
                  <div class="form-text"><?= $esc(t('settings.profile.avatar_help')) ?></div>
                </div>
              </div>
            </div>
            <div class="pt-2 d-flex gap-2">
              <button class="btn btn-primary js-settings-submit" type="submit"><?= $esc(t('settings.profile.save')) ?></button>
              <button id="avatar-remove-btn" class="btn btn-outline-secondary" type="submit" form="avatar-remove-form"<?= $avatarFile === null ? ' hidden' : '' ?>><?= $esc(t('settings.profile.remove_avatar')) ?></button>
            </div>
          </form>
          <form id="avatar-remove-form" method="post" hidden data-settings-form="avatar_remove">
            <input type="hidden" name="csrf" value="<?= $esc($csrf) ?>" />
            <input type="hidden" name="form" value="avatar_remove" />
          </form>
        </div>
      </section>

      <section class="card" data-settings-card="password">
        <div class="card-body p-4">
          <h2 class="card-title h5 mb-1"><?= $esc(t('settings.password.title')) ?></h2>
          <p class="text-secondary mb-4"><?= $esc(t('settings.password.intro')) ?></p>
          <div class="js-settings-result" data-result-for="password"><?php $renderSectionFlash('password'); ?></div>
          <form id="settings-form-password" method="post" autocomplete="off" data-settings-form="password">
            <input type="hidden" name="csrf" value="<?= $esc($csrf) ?>" />
            <input type="hidden" name="form" value="password" />
            <div class="mb-3">
              <label class="form-label" for="current_password"><?= $esc(t('settings.password.current')) ?></label>
              <input id="current_password" class="form-control" type="password" name="current_password" required autocomplete="current-password" />
            </div>
            <div class="mb-3">
              <label class="form-label" for="new_password"><?= $esc(t('settings.password.new')) ?></label>
              <input id="new_password" class="form-control" type="password" name="new_password" required autocomplete="new-password" />
            </div>
            <div class="mb-3">
              <label class="form-label" for="new_password2"><?= $esc(t('settings.password.confirm')) ?></label>
              <input id="new_password2" class="form-control" type="password" name="new_password2" required autocomplete="new-password" />
            </div>
            <div class="pt-2">
              <button class="btn btn-primary js-settings-submit" type="submit"><?= $esc(t('settings.password.update')) ?></button>
            </div>
          </form>
        </div>
      </section>
      </div>
    </div>
  </div>

  <div class="row g-4 settings-top align-items-stretch mt-4">
    <div class="col-lg-6 d-lg-flex">
      <section class="card flex-grow-1 w-100" data-settings-card="advanced">
        <div class="card-body p-4">
          <h2 class="card-title h5 mb-1"><?= $esc(t('settings.advanced.title')) ?></h2>
          <p class="text-secondary mb-4"><?= $esc(t('settings.advanced.intro')) ?></p>
          <div class="js-settings-result" data-result-for="advanced"><?php $renderSectionFlash('advanced'); ?></div>
          <form id="settings-form-advanced" method="post" data-settings-form="advanced">
            <input type="hidden" name="csrf" value="<?= $esc($csrf) ?>" />
            <input type="hidden" name="form" value="advanced" />
            <div class="form-check form-switch mb-3">
              <input id="filter_bots" class="form-check-input" type="checkbox" role="switch" name="filter_bots" value="1"<?= $filterBots ? ' checked' : '' ?> />
              <label class="form-check-label" for="filter_bots"><?= $esc(t('settings.advanced.filter_bots')) ?></label>
            </div>
            <div class="form-check form-switch mb-3">
              <input id="ignore_localhost" class="form-check-input" type="checkbox" role="switch" name="ignore_localhost" value="1"<?= !empty($cfg['ignore_localhost']) ? ' checked' : '' ?> />
              <label class="form-check-label" for="ignore_localhost"><?= $esc(t('settings.advanced.ignore_localhost')) ?></label>
            </div>
            <div class="form-check form-switch mb-3">
              <input id="trust_proxy" class="form-check-input" type="checkbox" role="switch" name="trust_proxy" value="1"<?= !empty($cfg['trust_proxy']) ? ' checked' : '' ?> />
              <label class="form-check-label" for="trust_proxy"><?= $esc(t('settings.advanced.trust_proxy')) ?></label>
              <div class="form-text"><?= $esc(t('settings.advanced.trust_proxy_help')) ?></div>
            </div>
            <div class="form-check form-switch mb-3">
              <input id="process_visitor_ip" class="form-check-input" type="checkbox" role="switch" name="process_visitor_ip" value="1"<?= $processVisitorIp ? ' checked' : '' ?> />
              <label class="form-check-label" for="process_visitor_ip"><?= $esc(t('settings.advanced.process_ip')) ?></label>
              <div class="form-text"><?= $esc(t('settings.advanced.process_ip_help')) ?></div>
            </div>
            <div class="mb-3">
              <label class="form-label" for="excluded_paths"><?= $esc(t('settings.advanced.excluded_paths')) ?></label>
              <textarea id="excluded_paths" class="form-control font-monospace" name="excluded_paths" rows="3" placeholder="<?= $esc(t('settings.advanced.excluded_paths_placeholder')) ?>"><?= $esc($excludedPathsText) ?></textarea>
              <div class="form-text"><?= $esc(t('settings.advanced.excluded_paths_help')) ?></div>
            </div>
            <div class="mb-3">
              <label class="form-label" for="ignore_ips"><?= $esc(t('settings.advanced.ignore_ips')) ?></label>
              <textarea id="ignore_ips" class="form-control font-monospace" name="ignore_ips" rows="3" placeholder="<?= $esc(t('settings.advanced.ignore_ips_placeholder')) ?>"><?= $esc($ignoreIpsText) ?></textarea>
              <div class="form-text"><?= $esc(t('settings.advanced.ignore_ips_help')) ?></div>
            </div>
            <div class="mb-3">
              <label class="form-label" for="referrer_blocklist"><?= $esc(t('settings.advanced.blocked_referrers')) ?></label>
              <textarea id="referrer_blocklist" class="form-control font-monospace" name="referrer_blocklist" rows="3" placeholder="<?= $esc(t('settings.advanced.blocked_referrers_placeholder')) ?>"><?= $esc($referrerBlockText) ?></textarea>
              <div class="form-text"><?= $esc(t('settings.advanced.blocked_referrers_help')) ?></div>
            </div>
            <div class="pt-2">
              <button class="btn btn-primary js-settings-submit" type="submit"><?= $esc(t('settings.advanced.save')) ?></button>
            </div>
          </form>
        </div>
      </section>
    </div>

    <div class="col-lg-6 d-lg-flex">
      <div class="settings-stack">
      <section class="card" id="reports" data-settings-card="reports">
        <div class="card-body p-4">
          <h2 class="card-title h5 mb-1"><?= $esc(t('settings.reports.title')) ?></h2>
          <p class="text-secondary mb-4"><?= $esc(t('settings.reports.intro')) ?></p>
          <div id="reports-result" class="js-settings-result" data-result-for="reports">
            <?php if ($reportsNotice !== ''): ?>
              <div class="alert alert-success py-2 ui-fade-in" role="status"><?= $esc($reportsNotice) ?></div>
            <?php endif; ?>
            <?php if ($reportsErrors !== []): ?>
              <div class="alert alert-danger py-2 ui-fade-in" role="alert">
                <?php foreach ($reportsErrors as $e): ?><div><?= $esc($e) ?></div><?php endforeach; ?>
              </div>
            <?php endif; ?>
          </div>
          <form id="reports-form" method="post" action="#reports" data-settings-form="reports">
            <input type="hidden" name="csrf" value="<?= $esc($csrf) ?>" />
            <input type="hidden" name="form" value="reports" />
            <div class="form-check form-switch mb-3">
              <input id="digest_enabled" class="form-check-input" type="checkbox" role="switch" name="digest_enabled" value="1"<?= !empty($cfg['digest_enabled']) ? ' checked' : '' ?> />
              <label class="form-check-label" for="digest_enabled"><?= $esc(t('settings.reports.enabled')) ?></label>
            </div>
            <div id="reports-details" class="ui-collapse<?= empty($cfg['digest_enabled']) ? '' : ' is-open' ?>"<?= empty($cfg['digest_enabled']) ? ' hidden' : '' ?>>
              <div class="ui-collapse-inner">
                <div class="mb-3">
                  <label class="form-label" for="digest_email"><?= $esc(t('settings.reports.email')) ?></label>
                  <input id="digest_email" class="form-control" type="email" name="digest_email" value="<?= $esc((string) ($cfg['digest_email'] ?? '')) ?>" autocomplete="email" placeholder="<?= $esc(t('settings.reports.email_placeholder')) ?>" />
                  <div class="form-text"><?= $esc(t('settings.reports.email_help')) ?></div>
                </div>
                <p id="reports-status" class="small text-secondary mb-3"><?= $esc(doostats_digest_status_label()) ?></p>
              </div>
            </div>
            <div class="d-flex flex-wrap gap-2 pt-2">
              <button class="btn btn-primary js-settings-submit" type="submit"><?= $esc(t('settings.reports.save')) ?></button>
              <button id="reports-test-btn" class="btn btn-outline-secondary" type="button" hidden><?= $esc(t('settings.reports.send_test')) ?></button>
            </div>
          </form>
        </div>
      </section>

      <section class="card" id="updates">
        <div class="card-body p-4">
          <h2 class="card-title h5 mb-1"><?= $esc(t('settings.updates.title')) ?></h2>
          <p id="updates-installed" class="text-secondary mb-3"><?= $esc($updatesIntro) ?></p>

          <div id="update-check-result" class="js-settings-result">
          <?php if (is_array($updateResult)): ?>
            <?php
              $updateAlert = match ((string) ($updateResult['status'] ?? '')) {
                  'update_available' => 'alert-info',
                  'up_to_date' => 'alert-success',
                  default => 'alert-danger',
              };
            ?>
            <div class="alert <?= $esc($updateAlert) ?> py-2 ui-fade-in">
              <div><?= $esc($updateResult['message']) ?></div>
              <?php if ($updateResult['status'] === 'update_available' && $updateResult['notes'] !== ''): ?>
                <div class="small mt-1"><?= $esc($updateResult['notes']) ?></div>
              <?php endif; ?>
              <?php if ($updateResult['status'] === 'update_available'): ?>
                <div class="mt-2 d-flex flex-wrap gap-2">
                  <?php if (!empty($updateResult['can_apply'])): ?>
                    <button type="button" class="btn btn-sm btn-primary js-update-install" data-csrf="<?= $esc($csrf) ?>"><?= $esc(t('settings.updates.install')) ?></button>
                  <?php else: ?>
                    <a class="btn btn-sm btn-primary" href="<?= $esc(doostats_update_fallback_page_url()) ?>" target="_blank" rel="noopener"><?= $esc(t('settings.updates.download')) ?></a>
                  <?php endif; ?>
                </div>
              <?php elseif (($updateResult['status'] ?? '') === 'error'): ?>
                <div class="small mt-2">
                  <?= $esc(t('settings.updates.fallback_help')) ?>
                  <a href="<?= $esc(doostats_update_fallback_page_url()) ?>" target="_blank" rel="noopener"><?= $esc(t('settings.updates.fallback_link')) ?></a>
                </div>
              <?php endif; ?>
            </div>
          <?php endif; ?>
          </div>

          <div class="d-flex flex-wrap align-items-center gap-2">
            <form id="update-check-form" method="post" action="#updates">
              <input type="hidden" name="csrf" value="<?= $esc($csrf) ?>" />
              <input type="hidden" name="form" value="update_check" />
              <button id="update-check-btn" class="btn btn-outline-secondary" type="submit"><?= $esc(t('settings.updates.check')) ?></button>
            </form>
            <a class="btn btn-outline-secondary" href="<?= $esc(doostats_update_changelog_url()) ?>" target="_blank" rel="noopener"><?= $esc(t('settings.updates.release_notes')) ?></a>
          </div>
        </div>
      </section>

      <section class="card border-danger-subtle bg-danger-subtle" id="danger-zone" data-settings-card="danger">
        <div class="card-body p-4">
          <h2 class="card-title h5 text-danger-emphasis mb-1"><?= $esc(t('settings.danger.title')) ?></h2>
          <p class="text-body-secondary mb-3"><?= $esc(t('settings.danger.intro')) ?></p>
          <div class="js-settings-result" data-result-for="danger"><?php $renderSectionFlash('danger'); ?></div>
          <form id="settings-form-reset" method="post" action="#danger-zone" autocomplete="off" data-settings-form="reset_stats">
            <input type="hidden" name="csrf" value="<?= $esc($csrf) ?>" />
            <input type="hidden" name="form" value="reset_stats" />
            <div class="mb-3" style="max-width: 22rem">
              <label class="form-label" for="confirm_password"><?= $esc(t('settings.danger.password')) ?></label>
              <input id="confirm_password" class="form-control" type="password" name="confirm_password" required autocomplete="current-password" />
            </div>
            <button class="btn btn-danger js-settings-submit" type="submit"><?= $esc(t('settings.danger.reset')) ?></button>
          </form>
        </div>
      </section>
      </div>
    </div>
  </div>
  </div>

<?php
$avatarPreviewScript = '<script>const I18N = ' . json_encode($jsI18n, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . ';'
    . 'var UPDATE_FALLBACK_PAGE = ' . json_encode(doostats_update_fallback_page_url(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . ';'
    . 'var AVATAR_FALLBACK_SVG = ' . json_encode(DASHBOARD_AVATAR_SVG, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . ';</script>' . <<<'HTML'
<script>
(function () {
  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function setCollapse(el, open) {
    if (!el) return;
    if (open) {
      el.hidden = false;
      if (reduceMotion) {
        el.classList.add('is-open');
        return;
      }
      // Allow the browser to apply display before starting the open transition.
      void el.offsetHeight;
      el.classList.add('is-open');
      return;
    }
    el.classList.remove('is-open');
    if (reduceMotion) {
      el.hidden = true;
      return;
    }
    window.setTimeout(function () {
      if (!el.classList.contains('is-open')) el.hidden = true;
    }, 220);
  }

  function showResult(box, ok, message, errors) {
    if (!box) return;
    var html = '';
    if (ok) {
      html = '<div class="alert alert-success py-2 ui-fade-in" role="status"></div>';
    } else {
      html = '<div class="alert alert-danger py-2 ui-fade-in" role="alert"></div>';
    }
    box.innerHTML = html;
    var alert = box.firstElementChild;
    if (!alert) return;
    if (!ok && errors && errors.length) {
      errors.forEach(function (err) {
        var row = document.createElement('div');
        row.textContent = err;
        alert.appendChild(row);
      });
    } else {
      alert.textContent = message || (ok ? '' : (I18N['js.settings.failed'] || 'Failed.'));
    }
  }

  function brandWeak(hex) {
    var m = /^#([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return 'rgba(59, 130, 246, 0.12)';
    var n = parseInt(m[1], 16);
    var r = (n >> 16) & 255;
    var g = (n >> 8) & 255;
    var b = n & 255;
    return 'rgba(' + r + ', ' + g + ', ' + b + ', 0.12)';
  }

  function applyTheme(theme) {
    var root = document.documentElement;
    if (theme === 'system') {
      root.setAttribute('data-ui-theme', 'system');
      root.setAttribute(
        'data-bs-theme',
        window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
      );
    } else {
      root.removeAttribute('data-ui-theme');
      root.setAttribute('data-bs-theme', theme);
    }
  }

  function applyUi(ui) {
    if (!ui) return;
    if (ui.brand_hex) {
      document.documentElement.style.setProperty('--brand', ui.brand_hex);
      document.documentElement.style.setProperty('--brand-weak', brandWeak(ui.brand_hex));
    }
    if (ui.ui_theme) applyTheme(ui.ui_theme);
    if (typeof ui.user_name === 'string') {
      var nameEl = document.querySelector('.usermenu-name');
      if (nameEl) nameEl.textContent = ui.user_name;
    }
    if (typeof ui.install_path === 'string') {
      var pathInput = document.getElementById('install_path');
      if (pathInput) pathInput.value = ui.install_path;
    }
    if (typeof ui.ignore_ips === 'string') {
      var ignore = document.getElementById('ignore_ips');
      if (ignore) ignore.value = ui.ignore_ips;
    }
    if (typeof ui.excluded_paths === 'string') {
      var paths = document.getElementById('excluded_paths');
      if (paths) paths.value = ui.excluded_paths;
    }
    if (typeof ui.referrer_blocklist === 'string') {
      var refs = document.getElementById('referrer_blocklist');
      if (refs) refs.value = ui.referrer_blocklist;
    }
    if (ui.clear_password_fields) {
      ['current_password', 'new_password', 'new_password2'].forEach(function (id) {
        var el = document.getElementById(id);
        if (el) el.value = '';
      });
    }
    if (ui.clear_confirm_password) {
      var confirm = document.getElementById('confirm_password');
      if (confirm) confirm.value = '';
    }
    if (Object.prototype.hasOwnProperty.call(ui, 'has_avatar')) {
      var preview = document.getElementById('avatarPreview');
      var navBadge = document.querySelector('.avatar-badge');
      var removeBtn = document.getElementById('avatar-remove-btn');
      var avatarInput = document.getElementById('avatar');
      if (preview) {
        if (ui.has_avatar && ui.avatar_url) {
          preview.innerHTML = '';
          var img = document.createElement('img');
          img.src = ui.avatar_url;
          img.alt = I18N['js.avatar.preview_alt'] || '';
          preview.appendChild(img);
        } else {
          preview.innerHTML = AVATAR_FALLBACK_SVG || '';
        }
      }
      if (navBadge) {
        if (ui.has_avatar && ui.avatar_url) {
          navBadge.innerHTML = '';
          var navImg = document.createElement('img');
          navImg.src = ui.avatar_url;
          navImg.alt = '';
          navBadge.appendChild(navImg);
        } else {
          navBadge.innerHTML = AVATAR_FALLBACK_SVG || '';
        }
      }
      if (removeBtn) removeBtn.hidden = !ui.has_avatar;
      if (avatarInput) avatarInput.value = '';
    }
    if (typeof ui.status === 'string') {
      var status = document.getElementById('reports-status');
      if (status) status.textContent = ui.status;
    }
  }

  function resultBoxFor(formName) {
    if (formName === 'avatar_remove') formName = 'profile';
    if (formName === 'reset_stats') formName = 'danger';
    return document.querySelector('.js-settings-result[data-result-for="' + formName + '"]');
  }

  function bindSettingsForm(form) {
    if (!form || !window.fetch) return;
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var formName = form.getAttribute('data-settings-form') || '';
      var box = resultBoxFor(formName);
      var submitBtn = form.querySelector('.js-settings-submit') || document.querySelector('button[form="' + form.id + '"].js-settings-submit');
      if (formName === 'avatar_remove') {
        submitBtn = document.getElementById('avatar-remove-btn');
      }
      var label = submitBtn ? submitBtn.textContent : '';
      if (submitBtn) {
        submitBtn.disabled = true;
        if (formName !== 'avatar_remove' && formName !== 'reset_stats') {
          submitBtn.textContent = I18N['js.settings.saving'] || 'Saving…';
        }
      }

      fetch('settings-save.php', {
        method: 'POST',
        credentials: 'same-origin',
        cache: 'no-store',
        body: new FormData(form)
      })
        .then(function (r) { return r.json().then(function (payload) { return { httpOk: r.ok, data: payload }; }); })
        .then(function (res) {
          var data = res.data || {};
          showResult(box, !!data.ok, data.message || I18N['js.settings.failed'], data.errors || []);
          if (data.ok) applyUi(data.ui || {});
          if (data.ok && data.reload) {
            window.location.reload();
            return;
          }
          if (formName === 'reports') {
            var enabled = document.getElementById('digest_enabled');
            var details = document.getElementById('reports-details');
            if (enabled && details) setCollapse(details, !!enabled.checked);
            syncReportsUi();
          }
        })
        .catch(function () {
          showResult(box, false, I18N['js.settings.unreachable'] || I18N['js.settings.failed']);
        })
        .finally(function () {
          if (submitBtn) {
            submitBtn.disabled = false;
            if (label) submitBtn.textContent = label;
          }
        });
    });
  }

  document.querySelectorAll('form[data-settings-form]').forEach(bindSettingsForm);

  var avatarInput = document.getElementById('avatar');
  var preview = document.getElementById('avatarPreview');
  if (avatarInput && preview) {
    avatarInput.addEventListener('change', function () {
      var file = avatarInput.files && avatarInput.files[0];
      if (!file || file.type.indexOf('image/') !== 0) return;
      var reader = new FileReader();
      reader.onload = function (e) {
        var img = document.createElement('img');
        img.alt = I18N['js.avatar.preview_alt'];
        img.src = e.target.result;
        preview.innerHTML = '';
        preview.appendChild(img);
      };
      reader.readAsDataURL(file);
    });
  }

  var form = document.getElementById('reports-form');
  var enabled = document.getElementById('digest_enabled');
  var email = document.getElementById('digest_email');
  var details = document.getElementById('reports-details');
  var testBtn = document.getElementById('reports-test-btn');
  var box = document.getElementById('reports-result');
  var status = document.getElementById('reports-status');

  function emailLooksValid(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || '').trim());
  }

  function syncReportsUi() {
    if (details && enabled) setCollapse(details, !!enabled.checked);
    if (!testBtn || !enabled || !email) return;
    var show = enabled.checked && emailLooksValid(email.value);
    testBtn.hidden = !show;
    if (!show) testBtn.disabled = false;
  }

  if (form && enabled && email && testBtn && box) {
    enabled.addEventListener('change', syncReportsUi);
    email.addEventListener('input', syncReportsUi);
    email.addEventListener('change', syncReportsUi);
    syncReportsUi();

    if (window.fetch) {
      testBtn.addEventListener('click', function () {
        if (testBtn.disabled || testBtn.hidden) return;
        if (!enabled.checked || !emailLooksValid(email.value)) {
          syncReportsUi();
          return;
        }
        testBtn.disabled = true;
        var label = testBtn.textContent;
        testBtn.textContent = I18N['js.reports.sending'] || 'Sending…';

        var data = new FormData(form);
        data.set('digest_enabled', '1');

        fetch('digest-test.php', {
          method: 'POST',
          credentials: 'same-origin',
          cache: 'no-store',
          body: data
        })
          .then(function (r) { return r.json().then(function (payload) { return { httpOk: r.ok, data: payload }; }); })
          .then(function (res) {
            var data = res.data || {};
            showResult(box, !!data.ok, data.message || I18N['js.reports.failed']);
            if (data.status && status) status.textContent = data.status;
          })
          .catch(function () {
            showResult(box, false, I18N['js.reports.unreachable'] || I18N['js.reports.failed']);
          })
          .finally(function () {
            testBtn.disabled = false;
            testBtn.textContent = label;
            syncReportsUi();
          });
      });
    }
  }
})();
</script>
<script>
(function () {
  var form = document.getElementById('update-check-form');
  var btn = document.getElementById('update-check-btn');
  var box = document.getElementById('update-check-result');
  var installed = document.getElementById('updates-installed');
  if (!form || !btn || !box || !window.fetch) return;

  function alertClass(status) {
    if (status === 'update_available') return 'alert alert-info py-2 ui-fade-in';
    if (status === 'up_to_date') return 'alert alert-success py-2 ui-fade-in';
    return 'alert alert-danger py-2 ui-fade-in';
  }

  function appendFallback(alert) {
    var help = document.createElement('div');
    help.className = 'small mt-2';
    help.appendChild(document.createTextNode((I18N['js.updates.fallback_help'] || '') + ' '));
    var a = document.createElement('a');
    a.href = window.UPDATE_FALLBACK_PAGE || '#';
    a.target = '_blank';
    a.rel = 'noopener';
    a.textContent = I18N['js.updates.fallback_link'] || 'Download page';
    help.appendChild(a);
    alert.appendChild(help);
  }

  function csrfToken() {
    var input = form.querySelector('input[name="csrf"]');
    return input ? input.value : '';
  }

  function bindInstallButton(root) {
    var installBtn = root.querySelector('.js-update-install');
    if (!installBtn) return;
    installBtn.addEventListener('click', function () {
      if (installBtn.disabled) return;
      installBtn.disabled = true;
      if (btn) btn.disabled = true;
      var label = installBtn.textContent;
      installBtn.textContent = I18N['js.updates.installing'] || 'Installing…';

      var data = new FormData();
      data.set('csrf', installBtn.getAttribute('data-csrf') || csrfToken());

      fetch('update-apply.php', {
        method: 'POST',
        credentials: 'same-origin',
        cache: 'no-store',
        body: data
      })
        .then(function (r) { return r.json().then(function (payload) { return { httpOk: r.ok, data: payload }; }); })
        .then(function (res) {
          var data = res.data || {};
          if (data.ok) {
            if (installed && data.version) {
              installed.textContent = data.message || installed.textContent;
            }
            renderResult({
              status: 'up_to_date',
              message: data.message || I18N['js.updates.install'],
              offer_reload: true
            });
            return;
          }
          renderResult({
            status: 'error',
            message: data.message || I18N['js.updates.install_failed']
          });
        })
        .catch(function () {
          renderResult({
            status: 'error',
            message: I18N['js.updates.unreachable'] || I18N['js.updates.install_failed']
          });
        })
        .finally(function () {
          if (btn) btn.disabled = false;
        });
    });
  }

  function renderResult(data) {
    box.textContent = '';
    var alert = document.createElement('div');
    alert.className = alertClass(data && data.status);
    alert.setAttribute('role', 'status');

    var msg = document.createElement('div');
    msg.textContent = (data && data.message) ? data.message : I18N['js.updates.failed'];
    alert.appendChild(msg);

    if (data && data.status === 'update_available') {
      if (data.notes) {
        var notes = document.createElement('div');
        notes.className = 'small mt-1';
        notes.textContent = data.notes;
        alert.appendChild(notes);
      }
      var actions = document.createElement('div');
      actions.className = 'mt-2 d-flex flex-wrap gap-2';
      if (data.can_apply) {
        var install = document.createElement('button');
        install.type = 'button';
        install.className = 'btn btn-sm btn-primary js-update-install';
        install.setAttribute('data-csrf', csrfToken());
        install.textContent = I18N['js.updates.install'] || 'Install update';
        actions.appendChild(install);
      } else {
        var dlOnly = document.createElement('a');
        dlOnly.className = 'btn btn-sm btn-primary';
        dlOnly.href = window.UPDATE_FALLBACK_PAGE || '#';
        dlOnly.target = '_blank';
        dlOnly.rel = 'noopener';
        dlOnly.textContent = I18N['js.updates.download'];
        actions.appendChild(dlOnly);
      }
      alert.appendChild(actions);
    } else if (data && data.offer_reload) {
      var reloadWrap = document.createElement('div');
      reloadWrap.className = 'mt-2';
      var reloadBtn = document.createElement('button');
      reloadBtn.type = 'button';
      reloadBtn.className = 'btn btn-sm btn-outline-secondary';
      reloadBtn.textContent = I18N['js.updates.reload_now'] || 'Reload now';
      reloadBtn.addEventListener('click', function () { window.location.reload(); });
      reloadWrap.appendChild(reloadBtn);
      alert.appendChild(reloadWrap);
    } else if (!data || data.status === 'error' || data.ok === false) {
      appendFallback(alert);
    }

    box.appendChild(alert);
    bindInstallButton(box);
  }

  bindInstallButton(box);

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (btn.disabled) return;
    btn.disabled = true;
    var label = btn.textContent;
    btn.textContent = I18N['js.updates.checking'];

    fetch('update-check.php', {
      method: 'POST',
      credentials: 'same-origin',
      cache: 'no-store',
      body: new FormData(form)
    })
      .then(function (r) { return r.json().then(function (data) { return { ok: r.ok, data: data }; }); })
      .then(function (res) {
        renderResult(res.data || { status: 'error', message: I18N['js.updates.failed'] });
      })
      .catch(function () {
        renderResult({ status: 'error', message: I18N['js.updates.unreachable'] });
      })
      .finally(function () {
        btn.disabled = false;
        btn.textContent = label;
      });
  });
})();
</script>
HTML;
dashboard_layout_end($avatarPreviewScript . doostats_brand_select_script());
?>
