<?php

declare(strict_types=1);

/**
 * Minimal UI localization.
 *
 * - English: lib/lang/en.php (source of truth; ships with the product).
 * - Shipped packs: lib/lang/{code}.php (replaced on product update).
 * - Site packs: data/lang/{code}.php (survive updates; override shipped packs
 *   with the same code). Missing keys fall back to English, then the key.
 */

function i18n_lang_dir(): string
{
  return __DIR__ . '/lang';
}

/**
 * Writable site language packs (survives product updates).
 */
function i18n_data_lang_dir(): string
{
  $cfg = function_exists('analytics_config') ? analytics_config() : [];
  $base = (string) ($cfg['data_dir'] ?? dirname(__DIR__) . '/data');
  return rtrim($base, '/\\') . '/lang';
}

function i18n_code_valid(string $code): bool
{
  return (bool) preg_match('/^[a-z]{2}(?:-[a-z0-9]+)?$/i', $code);
}

/**
 * Resolve pack file path. English always from lib/. Other codes: data/ first,
 * then lib/.
 */
function i18n_pack_path(string $code): ?string
{
  $code = strtolower(trim($code));
  if ($code === '' || !i18n_code_valid($code)) {
    return null;
  }
  if ($code === 'en') {
    $lib = i18n_lang_dir() . '/en.php';
    return is_file($lib) ? $lib : null;
  }
  $data = i18n_data_lang_dir() . '/' . $code . '.php';
  if (is_file($data)) {
    return $data;
  }
  $lib = i18n_lang_dir() . '/' . $code . '.php';
  return is_file($lib) ? $lib : null;
}

/**
 * Forget cached language/packs (e.g. after Settings saves ui_language).
 */
function i18n_reset(): void
{
  unset(
    $GLOBALS['__doostats_i18n_lang'],
    $GLOBALS['__doostats_i18n_packs'],
    $GLOBALS['__doostats_i18n_date_fmt'],
    $GLOBALS['__doostats_i18n_hour_fmt'],
    $GLOBALS['__doostats_i18n_num_fmt'],
    $GLOBALS['__doostats_i18n_pct_fmt']
  );
}

/**
 * Active UI language code from config (default en).
 */
function i18n_language(): string
{
  if (isset($GLOBALS['__doostats_i18n_lang']) && is_string($GLOBALS['__doostats_i18n_lang'])) {
    return $GLOBALS['__doostats_i18n_lang'];
  }

  $cfg = function_exists('analytics_config') ? analytics_config() : [];
  $code = strtolower(trim((string) ($cfg['ui_language'] ?? 'en')));
  if ($code === '' || !i18n_code_valid($code) || i18n_pack_path($code) === null) {
    $code = 'en';
  }

  $GLOBALS['__doostats_i18n_lang'] = $code;
  return $code;
}

/** BCP 47-ish value for <html lang="…">. */
function i18n_html_lang(): string
{
  return i18n_language();
}

/**
 * English endonym for a language code (for the language selector).
 */
function i18n_english_language_name(string $code): string
{
  static $names = [
    'en' => 'English',
    'de' => 'German',
    'fr' => 'French',
    'ja' => 'Japanese',
    'es' => 'Spanish',
    'zh-hans' => 'Simplified Chinese',
    'it' => 'Italian',
    'pt-br' => 'Brazilian Portuguese',
    'ko' => 'Korean',
    'nl' => 'Dutch',
    'zh-hant' => 'Traditional Chinese',
    'pl' => 'Polish',
    'sv' => 'Swedish',
  ];
  $code = strtolower(trim($code));
  if (isset($names[$code])) {
    return $names[$code];
  }
  if (class_exists(Locale::class)) {
    $display = \Locale::getDisplayLanguage($code, 'en');
    if (is_string($display) && $display !== '' && strcasecmp($display, $code) !== 0) {
      return $display;
    }
  }
  return $code;
}

/**
 * Selector label: "German (Deutsch)". Same name twice collapses to one.
 */
function i18n_language_option_label(string $code, string $nativeName): string
{
  $english = i18n_english_language_name($code);
  $native = trim($nativeName);
  if ($native === '' || strcasecmp($native, $english) === 0) {
    return $english;
  }
  return $english . ' (' . $native . ')';
}

/**
 * Scan a directory for pack codes → native display names (_meta.name).
 *
 * @return array<string, string>
 */
function i18n_scan_lang_dir(string $dir): array
{
  $out = [];
  if (!is_dir($dir)) {
    return $out;
  }
  foreach (glob($dir . '/*.php') ?: [] as $path) {
    $code = strtolower(basename($path, '.php'));
    if (!i18n_code_valid($code)) {
      continue;
    }
    // English belongs in lib/ only — ignore data/lang/en.php.
    if ($code === 'en' && rtrim($dir, '/\\') === rtrim(i18n_data_lang_dir(), '/\\')) {
      continue;
    }
    $pack = include $path;
    if (!is_array($pack)) {
      continue;
    }
    $name = '';
    if (isset($pack['_meta']) && is_array($pack['_meta'])) {
      $name = trim((string) ($pack['_meta']['name'] ?? ''));
    }
    $out[$code] = $name !== '' ? $name : $code;
  }
  return $out;
}

/**
 * @return array<string, string> code => "English (Native)" label
 */
function i18n_available_languages(): array
{
  // lib first, then data overlays (same code → site pack wins the native name).
  $native = i18n_scan_lang_dir(i18n_lang_dir());
  foreach (i18n_scan_lang_dir(i18n_data_lang_dir()) as $code => $name) {
    $native[$code] = $name;
  }
  if ($native === [] || !isset($native['en'])) {
    $native['en'] = 'English';
  }
  $out = [];
  foreach ($native as $code => $name) {
    $out[$code] = i18n_language_option_label($code, $name);
  }
  ksort($out);
  return $out;
}

/**
 * @return array<string, string>
 */
function i18n_pack(string $code): array
{
  $code = strtolower(trim($code));
  if (!isset($GLOBALS['__doostats_i18n_packs']) || !is_array($GLOBALS['__doostats_i18n_packs'])) {
    $GLOBALS['__doostats_i18n_packs'] = [];
  }
  /** @var array<string, array<string, string>> $cache */
  $cache = &$GLOBALS['__doostats_i18n_packs'];
  if (isset($cache[$code])) {
    return $cache[$code];
  }

  $pack = [];
  $path = i18n_pack_path($code);
  if ($path !== null) {
    $loaded = include $path;
    if (is_array($loaded)) {
      foreach ($loaded as $k => $v) {
        if ($k === '_meta' || !is_string($k) || !is_string($v)) {
          continue;
        }
        $pack[$k] = $v;
      }
    }
  }
  $cache[$code] = $pack;
  return $pack;
}

/**
 * Translate a catalog key. Placeholders: {name} replaced from $replace.
 */
function t(string $key, array $replace = []): string
{
  $lang = i18n_language();
  $pack = i18n_pack($lang);
  $en = $lang === 'en' ? $pack : i18n_pack('en');

  $text = $pack[$key] ?? $en[$key] ?? $key;

  if ($replace !== []) {
    $map = [];
    foreach ($replace as $k => $v) {
      $map['{' . $k . '}'] = (string) $v;
    }
    $text = strtr($text, $map);
  }

  return $text;
}

/**
 * Simple singular/plural: $count === 1 uses $oneKey, else $manyKey (with {count}).
 */
function tn(string $oneKey, string $manyKey, int $count, array $replace = []): string
{
  $replace = array_merge(['count' => (string) $count], $replace);
  return t($count === 1 ? $oneKey : $manyKey, $replace);
}

/**
 * Dict of selected keys for inline JS.
 *
 * @param list<string> $keys
 * @return array<string, string>
 */
function i18n_js_dict(array $keys): array
{
  $out = [];
  foreach ($keys as $key) {
    $out[$key] = t($key);
  }
  return $out;
}

/**
 * Locale-aware date for UI display. Driven by ui_language (same as t()).
 * Uses IntlDateFormatter when intl is available; otherwise English DateTime::format.
 *
 * Styles match the previous English patterns:
 * - period:   "Tue 21 Jul"
 * - chart:    "21 Jul"
 * - date:     "21 Jul 2026"
 * - datetime: "21 Jul 2026, 14:30" (caller may append timezone label)
 *
 * @param DateTimeInterface|string $when DateTime or parseable date string (e.g. Y-m-d)
 */
function i18n_format_date(
  DateTimeInterface|string $when,
  string $style = 'chart',
  ?DateTimeZone $tz = null
): string {
  static $styles = [
    'period' => ['icu' => 'EEE d MMM', 'php' => 'D j M'],
    'chart' => ['icu' => 'd MMM', 'php' => 'j M'],
    'date' => ['icu' => 'd MMM y', 'php' => 'j M Y'],
    'datetime' => ['icu' => 'd MMM y, HH:mm', 'php' => 'j M Y, H:i'],
  ];
  if (!isset($styles[$style])) {
    $style = 'chart';
  }

  if ($tz === null) {
    $tz = function_exists('analytics_timezone')
      ? analytics_timezone()
      : new DateTimeZone('UTC');
  }

  if ($when instanceof DateTimeInterface) {
    $dt = DateTimeImmutable::createFromInterface($when)->setTimezone($tz);
  } else {
    try {
      $dt = new DateTimeImmutable(trim($when), $tz);
    } catch (Exception $e) {
      return trim($when);
    }
  }

  $lang = i18n_language();
  $patterns = $styles[$style];

  if (extension_loaded('intl') && class_exists('IntlDateFormatter')) {
    if (!isset($GLOBALS['__doostats_i18n_date_fmt']) || !is_array($GLOBALS['__doostats_i18n_date_fmt'])) {
      $GLOBALS['__doostats_i18n_date_fmt'] = [];
    }
    /** @var array<string, IntlDateFormatter|null> $cache */
    $cache = &$GLOBALS['__doostats_i18n_date_fmt'];
    $cacheKey = $lang . '|' . $style . '|' . $tz->getName();
    if (!array_key_exists($cacheKey, $cache)) {
      $locale = str_replace('-', '_', $lang);
      $fmt = new IntlDateFormatter(
        $locale,
        IntlDateFormatter::NONE,
        IntlDateFormatter::NONE,
        $tz->getName(),
        IntlDateFormatter::GREGORIAN,
        $patterns['icu']
      );
      $cache[$cacheKey] = $fmt instanceof IntlDateFormatter ? $fmt : null;
    }
    $fmt = $cache[$cacheKey];
    if ($fmt instanceof IntlDateFormatter) {
      $out = $fmt->format($dt);
      if (is_string($out) && $out !== '') {
        return $out;
      }
    }
  }

  return $dt->format($patterns['php']);
}

/**
 * Locale-aware hour-of-day label (0–23) for chart axes.
 * Always 24-hour (HH) so axes stay compact; intl still applies locale digits when relevant.
 */
function i18n_format_hour(int $hour): string
{
  $hour = max(0, min(23, $hour));
  $lang = i18n_language();
  $tz = function_exists('analytics_timezone')
    ? analytics_timezone()
    : new DateTimeZone('UTC');

  try {
    $dt = new DateTimeImmutable(
      sprintf('2000-01-01 %02d:00:00', $hour),
      $tz
    );
  } catch (Exception $e) {
    return sprintf('%02d', $hour);
  }

  if (extension_loaded('intl') && class_exists('IntlDateFormatter')) {
    if (!isset($GLOBALS['__doostats_i18n_hour_fmt']) || !is_array($GLOBALS['__doostats_i18n_hour_fmt'])) {
      $GLOBALS['__doostats_i18n_hour_fmt'] = [];
    }
    /** @var array<string, IntlDateFormatter|null> $cache */
    $cache = &$GLOBALS['__doostats_i18n_hour_fmt'];
    $cacheKey = $lang . '|' . $tz->getName();
    if (!array_key_exists($cacheKey, $cache)) {
      $locale = str_replace('-', '_', $lang);
      $fmt = new IntlDateFormatter(
        $locale,
        IntlDateFormatter::NONE,
        IntlDateFormatter::NONE,
        $tz->getName(),
        IntlDateFormatter::GREGORIAN,
        'HH'
      );
      $cache[$cacheKey] = $fmt instanceof IntlDateFormatter ? $fmt : null;
    }
    $fmt = $cache[$cacheKey];
    if ($fmt instanceof IntlDateFormatter) {
      $out = $fmt->format($dt);
      if (is_string($out) && $out !== '') {
        return $out;
      }
    }
  }

  return sprintf('%02d', $hour);
}

/**
 * Locale-aware integer (or fixed-fraction) number for UI display.
 * Driven by ui_language (same as dates / country names).
 */
function i18n_format_number(int|float $value, int $fractionDigits = 0): string
{
  $lang = i18n_language();
  $cacheKey = $lang . '|' . $fractionDigits;

  if (extension_loaded('intl') && class_exists('NumberFormatter')) {
    if (!isset($GLOBALS['__doostats_i18n_num_fmt']) || !is_array($GLOBALS['__doostats_i18n_num_fmt'])) {
      $GLOBALS['__doostats_i18n_num_fmt'] = [];
    }
    /** @var array<string, NumberFormatter|null> $cache */
    $cache = &$GLOBALS['__doostats_i18n_num_fmt'];
    if (!array_key_exists($cacheKey, $cache)) {
      $locale = str_replace('-', '_', $lang);
      $fmt = new NumberFormatter($locale, NumberFormatter::DECIMAL);
      $fmt->setAttribute(NumberFormatter::MIN_FRACTION_DIGITS, $fractionDigits);
      $fmt->setAttribute(NumberFormatter::MAX_FRACTION_DIGITS, $fractionDigits);
      $cache[$cacheKey] = $fmt instanceof NumberFormatter ? $fmt : null;
    }
    $fmt = $cache[$cacheKey];
    if ($fmt instanceof NumberFormatter) {
      $out = $fmt->format((float) $value);
      if (is_string($out) && $out !== '') {
        return $out;
      }
    }
  }

  if ($fractionDigits > 0) {
    return number_format((float) $value, $fractionDigits, '.', ',');
  }
  return number_format((int) round((float) $value), 0, '.', ',');
}

/**
 * Locale-aware percent for UI display. $value is already in percent points
 * (e.g. 12 means 12%). Includes the locale’s percent symbol/placement.
 * Driven by ui_language (same as dates / country names).
 */
function i18n_format_percent(int|float $value): string
{
  $lang = i18n_language();
  $fraction = ((float) $value) / 100.0;

  if (extension_loaded('intl') && class_exists('NumberFormatter')) {
    if (!isset($GLOBALS['__doostats_i18n_pct_fmt']) || !is_array($GLOBALS['__doostats_i18n_pct_fmt'])) {
      $GLOBALS['__doostats_i18n_pct_fmt'] = [];
    }
    /** @var array<string, NumberFormatter|null> $cache */
    $cache = &$GLOBALS['__doostats_i18n_pct_fmt'];
    if (!array_key_exists($lang, $cache)) {
      $locale = str_replace('-', '_', $lang);
      $fmt = new NumberFormatter($locale, NumberFormatter::PERCENT);
      $fmt->setAttribute(NumberFormatter::FRACTION_DIGITS, 0);
      $cache[$lang] = $fmt instanceof NumberFormatter ? $fmt : null;
    }
    $fmt = $cache[$lang];
    if ($fmt instanceof NumberFormatter) {
      $out = $fmt->format($fraction);
      if (is_string($out) && $out !== '') {
        return $out;
      }
    }
  }

  return i18n_format_number((int) round((float) $value)) . '%';
}

