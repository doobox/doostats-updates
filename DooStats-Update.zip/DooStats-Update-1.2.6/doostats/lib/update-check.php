<?php

declare(strict_types=1);

require_once __DIR__ . '/i18n.php';

/**
 * Installed version + manual update check against a public appcast JSON.
 * Nothing is fetched unless the admin clicks “Check for updates” in Settings.
 */

/**
 * Default feed URL. Hosted on GitHub raw so the check never touches the doobox
 * host (whose Imunify360 bot-protection can block shared-hosting IPs). A copy is
 * still published to doobox for installs shipped before the feed moved.
 * Override with update_feed_url in config.php if needed.
 */
const DOOSTATS_UPDATE_FEED_DEFAULT = 'https://raw.githubusercontent.com/doobox/doostats-updates/main/appcast.json';

/**
 * Stable download page when the feed check fails (opens in the admin's browser).
 * Built as Updates/download.html next to the versioned update zip.
 */
const DOOSTATS_UPDATE_FALLBACK_PAGE = 'https://www.doobox.co.uk/sparkle/doostats/Updates/download.html';

/** Public changelog always linked from Settings → Updates. */
const DOOSTATS_UPDATE_CHANGELOG_URL = 'https://www.doobox.co.uk/sparkle/doostats/Updates/CHANGELOG.html';

function doostats_version_file(): string
{
    return dirname(__DIR__) . '/VERSION.txt';
}

function doostats_update_fallback_page_url(): string
{
    return DOOSTATS_UPDATE_FALLBACK_PAGE;
}

function doostats_update_changelog_url(): string
{
    return DOOSTATS_UPDATE_CHANGELOG_URL;
}

/**
 * @return array{version: string, built: string, kind: string}
 */
function doostats_installed_version(): array
{
    $path = doostats_version_file();
    $version = '0.0.0';
    $built = '';
    $kind = 'install';

    if (is_file($path)) {
        $lines = preg_split("/\r\n|\n|\r/", trim((string) file_get_contents($path))) ?: [];
        if (isset($lines[0]) && preg_match('/^\d+\.\d+\.\d+/', trim($lines[0]))) {
            $version = trim($lines[0]);
        }
        if (isset($lines[1])) {
            $built = trim($lines[1]);
        }
        if (isset($lines[2]) && strtolower(trim($lines[2])) === 'update') {
            $kind = 'update';
        }
    }

    return [
        'version' => $version,
        'built' => $built,
        'kind' => $kind,
    ];
}

/**
 * Format a VERSION.txt build stamp for display only.
 * Storage stays ISO-8601 UTC (e.g. 2026-07-20T18:43:00Z); display uses the site timezone.
 */
function doostats_format_built_at(string $built): string
{
    $built = trim($built);
    if ($built === '') {
        return '';
    }

    try {
        $dt = new DateTimeImmutable($built);
    } catch (Exception $e) {
        return $built;
    }

    $tz = function_exists('analytics_timezone')
        ? analytics_timezone()
        : new DateTimeZone('UTC');

    // Midnight UTC stamps are date-only; check before converting to the site zone.
    $utcMidnight = $dt->setTimezone(new DateTimeZone('UTC'))->format('H:i:s') === '00:00:00';
    $dt = $dt->setTimezone($tz);

    if ($utcMidnight) {
        return i18n_format_date($dt, 'date', $tz);
    }

    return i18n_format_date($dt, 'datetime', $tz);
}

function doostats_update_feed_url(): string
{
    $cfg = function_exists('analytics_config') ? analytics_config() : [];
    $url = trim((string) ($cfg['update_feed_url'] ?? ''));
    if ($url !== '' && filter_var($url, FILTER_VALIDATE_URL)) {
        return $url;
    }

    return DOOSTATS_UPDATE_FEED_DEFAULT;
}

/**
 * Fetch the appcast and compare with the installed version.
 *
 * @return array{
 *   ok: bool,
 *   status: 'up_to_date'|'update_available'|'error',
 *   message: string,
 *   installed: string,
 *   latest: string,
 *   notes: string,
 *   download_url: string,
 *   changelog_url: string
 * }
 */
function doostats_check_for_updates(): array
{
    $installed = doostats_installed_version();
    $empty = [
        'ok' => false,
        'status' => 'error',
        'message' => '',
        'installed' => $installed['version'],
        'latest' => '',
        'notes' => '',
        'download_url' => '',
        'changelog_url' => '',
    ];

    $feedUrl = doostats_update_feed_url();
    $raw = doostats_http_get($feedUrl);
    if ($raw === null) {
        $empty['message'] = t('updates.error.unreachable');
        return $empty;
    }

    $data = json_decode($raw, true);
    if (!is_array($data)) {
        $empty['message'] = t('updates.error.invalid_json');
        return $empty;
    }

    $stable = $data['channels']['stable'] ?? null;
    if (!is_array($stable)) {
        // Allow a flat feed: { "version": "1.1.0", "downloads": { "update": "…" } }
        $stable = $data;
    }

    $latest = trim((string) ($stable['version'] ?? $data['latest'] ?? ''));
    if ($latest === '' || !preg_match('/^\d+\.\d+\.\d+/', $latest)) {
        $empty['message'] = t('updates.error.no_version');
        return $empty;
    }

    $downloads = is_array($stable['downloads'] ?? null) ? $stable['downloads'] : [];
    $downloadUrl = trim((string) ($downloads['update'] ?? $downloads['install'] ?? ''));
    $notes = trim((string) ($stable['notes'] ?? ''));
    $changelogUrl = trim((string) ($stable['changelog_url'] ?? ''));

    $cmp = version_compare($installed['version'], $latest);
    if ($cmp >= 0) {
        return [
            'ok' => true,
            'status' => 'up_to_date',
            'message' => t('updates.up_to_date', ['version' => $installed['version']]),
            'installed' => $installed['version'],
            'latest' => $latest,
            'notes' => $notes,
            'download_url' => $downloadUrl,
            'changelog_url' => $changelogUrl,
        ];
    }

    return [
        'ok' => true,
        'status' => 'update_available',
        'message' => t('updates.available', [
            'latest' => $latest,
            'installed' => $installed['version'],
        ]),
        'installed' => $installed['version'],
        'latest' => $latest,
        'notes' => $notes,
        'download_url' => $downloadUrl,
        'changelog_url' => $changelogUrl,
    ];
}

/**
 * Client-facing update result: same as doostats_check_for_updates() but the
 * real zip URL is replaced with has_download so it never appears in HTML/JSON.
 * can_apply is true when this host can run the in-app installer.
 *
 * @param array{
 *   ok: bool,
 *   status: string,
 *   message: string,
 *   installed: string,
 *   latest: string,
 *   notes: string,
 *   download_url: string,
 *   changelog_url: string
 * } $result
 * @return array{
 *   ok: bool,
 *   status: string,
 *   message: string,
 *   installed: string,
 *   latest: string,
 *   notes: string,
 *   changelog_url: string,
 *   has_download: bool,
 *   can_apply: bool
 * }
 */
function doostats_public_update_result(array $result): array
{
    $out = $result;
    $out['has_download'] = trim((string) ($result['download_url'] ?? '')) !== '';
    unset($out['download_url']);

    $canApply = false;
    if (($out['status'] ?? '') === 'update_available' && $out['has_download']) {
        if (!function_exists('doostats_update_can_apply')) {
            require_once __DIR__ . '/update-apply.php';
        }
        $canApply = doostats_update_can_apply()['ok'];
    }
    $out['can_apply'] = $canApply;
    return $out;
}

/** Best-effort GET with a short timeout. Returns body or null. */
function doostats_http_get(string $url): ?string
{
    if (!filter_var($url, FILTER_VALIDATE_URL) || !preg_match('#^https?://#i', $url)) {
        return null;
    }

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        if ($ch === false) {
            return null;
        }
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 3,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_USERAGENT => 'DooStats/' . doostats_installed_version()['version'],
            CURLOPT_HTTPHEADER => ['Accept: application/json'],
        ]);
        $body = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($body === false || $code < 200 || $code >= 300) {
            return null;
        }
        return (string) $body;
    }

    if (!ini_get('allow_url_fopen')) {
        return null;
    }

    $ctx = stream_context_create([
        'http' => [
            'method' => 'GET',
            'timeout' => 10,
            'header' => "Accept: application/json\r\nUser-Agent: DooStats/" . doostats_installed_version()['version'] . "\r\n",
        ],
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
        ],
    ]);
    $body = @file_get_contents($url, false, $ctx);
    return $body === false ? null : (string) $body;
}
