<?php

declare(strict_types=1);

/**
 * Shared Settings save handlers. Used by the classic POST path in
 * dashboard/settings.php and the AJAX endpoint dashboard/settings-save.php.
 */

require_once __DIR__ . '/analytics.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/config-write.php';
require_once __DIR__ . '/digest.php';
require_once __DIR__ . '/i18n.php';
require_once __DIR__ . '/install-path.php';
require_once __DIR__ . '/ui-theme.php';

/**
 * Store an uploaded image as a small square avatar. When GD is available the
 * image is centre-cropped and downscaled to at most $size px; otherwise the
 * original bytes are stored as-is. Returns the saved basename, or null.
 */
function doostats_store_avatar(string $tmpPath, string $ext, string $destDir, int $size = 256): ?string
{
    $name = 'avatar-' . bin2hex(random_bytes(6)) . '.' . $ext;
    $dest = rtrim($destDir, '/\\') . '/' . $name;

    $loaders = [
        'png' => 'imagecreatefrompng',
        'jpg' => 'imagecreatefromjpeg',
        'gif' => 'imagecreatefromgif',
        'webp' => 'imagecreatefromwebp',
    ];

    if (function_exists('imagecreatetruecolor') && isset($loaders[$ext]) && function_exists($loaders[$ext])) {
        $src = @($loaders[$ext])($tmpPath);
        if ($src !== false) {
            $sw = imagesx($src);
            $sh = imagesy($src);
            $side = min($sw, $sh);
            $sx = (int) (($sw - $side) / 2);
            $sy = (int) (($sh - $side) / 2);
            $out = min($size, $side);
            $dst = imagecreatetruecolor($out, $out);
            imagealphablending($dst, false);
            imagesavealpha($dst, true);
            imagecopyresampled($dst, $src, 0, 0, $sx, $sy, $out, $out, $side, $side);

            $ok = match ($ext) {
                'png' => imagepng($dst, $dest, 6),
                'jpg' => imagejpeg($dst, $dest, 82),
                'gif' => imagegif($dst, $dest),
                'webp' => imagewebp($dst, $dest, 82),
                default => false,
            };
            imagedestroy($src);
            imagedestroy($dst);

            if ($ok) {
                @chmod($dest, 0644);
                return $name;
            }
        }
    }

    if (@move_uploaded_file($tmpPath, $dest)) {
        @chmod($dest, 0644);
        return $name;
    }
    return null;
}

/**
 * @param array<string, mixed> $cfg
 * @param array<string, mixed> $post
 * @param array<string, mixed> $files
 * @return array{
 *   ok: bool,
 *   message: string,
 *   errors: list<string>,
 *   cfg: array<string, mixed>,
 *   reload: bool,
 *   ui: array<string, mixed>
 * }
 */
function doostats_settings_save(string $form, array $cfg, array $post, array $files = []): array
{
    $empty = static function (array $cfg, array $errors = [], string $message = ''): array {
        return [
            'ok' => false,
            'message' => $message !== '' ? $message : ($errors[0] ?? t('settings.error.config_write')),
            'errors' => $errors,
            'cfg' => $cfg,
            'reload' => false,
            'ui' => [],
        ];
    };

    return match ($form) {
        'general' => doostats_settings_save_general($cfg, $post),
        'advanced' => doostats_settings_save_advanced($cfg, $post),
        'password' => doostats_settings_save_password($cfg, $post),
        'profile' => doostats_settings_save_profile($cfg, $post, $files),
        'avatar_remove' => doostats_settings_save_avatar_remove($cfg),
        'reports' => doostats_settings_save_reports($cfg, $post),
        'reset_stats' => doostats_settings_save_reset_stats($cfg, $post),
        default => $empty($cfg, [t('settings.error.config_update')]),
    };
}

/**
 * @param array<string, mixed> $cfg
 * @param array<string, mixed> $post
 * @return array{ok:bool,message:string,errors:list<string>,cfg:array<string,mixed>,reload:bool,ui:array<string,mixed>}
 */
function doostats_settings_save_general(array $cfg, array $post): array
{
    $errors = [];
    $availableLanguages = i18n_available_languages();
    $prevLang = (string) ($cfg['ui_language'] ?? 'en');

    $siteName = trim((string) ($post['site_name'] ?? ''));
    $siteUrl = trim((string) ($post['site_url'] ?? ''));
    // Install path is auto-detected; not shown in Settings. Keep any existing
    // config.php override if present (advanced / hand-edited installs).
    $installPath = doostats_normalize_install_path((string) ($cfg['install_path'] ?? ''));
    $dashboardHidden = doostats_dashboard_hidden_from_visible_post($post['dashboard_widgets'] ?? [], $cfg);
    $brand = trim((string) ($post['brand_hex'] ?? ''));
    $timezone = trim((string) ($post['timezone'] ?? 'UTC'));
    if (count($availableLanguages) === 1) {
        $uiLanguage = (string) array_key_first($availableLanguages);
    } else {
        $uiLanguage = strtolower(trim((string) ($post['ui_language'] ?? 'en')));
    }
    $retention = (int) ($post['retention_days'] ?? 45);
    $dashboardRefresh = (int) ($post['dashboard_refresh_seconds'] ?? 0);
    $uiTheme = strtolower(trim((string) ($post['ui_theme'] ?? doostats_ui_theme_default())));

    if ($siteName === '') {
        $errors[] = t('settings.error.site_name_required');
    }
    if ($siteUrl === '' || !filter_var($siteUrl, FILTER_VALIDATE_URL)) {
        $errors[] = t('settings.error.site_url_required');
    }
    if (!preg_match('/^#[0-9a-fA-F]{6}$/', $brand)) {
        $errors[] = t('settings.error.brand_hex');
    }
    if (!in_array($timezone, timezone_identifiers_list(), true)) {
        $errors[] = t('settings.error.timezone');
    }
    if (!isset($availableLanguages[$uiLanguage])) {
        $errors[] = t('settings.error.language');
    }
    if (!in_array($uiTheme, doostats_ui_theme_values(), true)) {
        $errors[] = t('settings.error.theme');
    }
    if ($retention < 1 || $retention > 90) {
        $errors[] = t('settings.error.retention');
    }
    if (!in_array($dashboardRefresh, [0, 30, 60, 300, 600, 1200], true)) {
        $errors[] = t('settings.error.refresh');
    }

    if ($errors !== []) {
        return [
            'ok' => false,
            'message' => $errors[0],
            'errors' => $errors,
            'cfg' => $cfg,
            'reload' => false,
            'ui' => [],
        ];
    }

    $new = $cfg;
    $new['site_name'] = $siteName;
    $new['site_url'] = $siteUrl;
    $new['install_path'] = $installPath;
    $new['dashboard_hidden'] = $dashboardHidden;
    $new['brand_hex'] = strtolower($brand);
    $new['timezone'] = $timezone;
    $new['ui_language'] = $uiLanguage;
    $new['ui_theme'] = $uiTheme;
    $new['retention_days'] = $retention;
    $new['dashboard_refresh_seconds'] = $dashboardRefresh;

    if (!doostats_write_config($new)) {
        return [
            'ok' => false,
            'message' => t('settings.error.config_write'),
            'errors' => [t('settings.error.config_write')],
            'cfg' => $cfg,
            'reload' => false,
            'ui' => [],
        ];
    }

    i18n_reset();
    $GLOBALS['__doostats_i18n_lang'] = $uiLanguage;

    return [
        'ok' => true,
        'message' => t('settings.notice.saved'),
        'errors' => [],
        'cfg' => $new,
        'reload' => $uiLanguage !== $prevLang,
        'ui' => [
            'site_name' => $siteName,
            'brand_hex' => strtolower($brand),
            'ui_theme' => $uiTheme,
        ],
    ];
}

/**
 * @param array<string, mixed> $cfg
 * @param array<string, mixed> $post
 * @return array{ok:bool,message:string,errors:list<string>,cfg:array<string,mixed>,reload:bool,ui:array<string,mixed>}
 */
function doostats_settings_save_advanced(array $cfg, array $post): array
{
    $errors = [];
    $ignoreLocalhost = !empty($post['ignore_localhost']);
    $filterBots = !empty($post['filter_bots']);
    $trustProxy = !empty($post['trust_proxy']);
    $processVisitorIp = !empty($post['process_visitor_ip']);
    $ignoreIps = array_values(array_filter(
        array_map('trim', preg_split('/[\r\n,]+/', (string) ($post['ignore_ips'] ?? '')) ?: []),
        static fn (string $v): bool => $v !== ''
    ));

    $splitLines = static fn (string $raw): array => array_values(array_filter(
        array_map('trim', preg_split('/[\r\n,]+/', $raw) ?: []),
        static fn (string $v): bool => $v !== ''
    ));
    $referrerBlock = array_values(array_filter(
        array_map(static fn (string $h): string => analytics_normalize_host($h), $splitLines((string) ($post['referrer_blocklist'] ?? ''))),
        static fn (string $v): bool => $v !== ''
    ));
    $excludedPaths = array_values(array_filter(
        array_map(static function (string $p): string {
            $p = trim($p);
            return ($p === '' || $p[0] === '/') ? $p : '/' . $p;
        }, $splitLines((string) ($post['excluded_paths'] ?? ''))),
        static fn (string $v): bool => $v !== ''
    ));

    foreach ($ignoreIps as $ip) {
        if (!filter_var($ip, FILTER_VALIDATE_IP)) {
            $errors[] = t('settings.error.invalid_ip', ['ip' => $ip]);
        }
    }

    if ($errors !== []) {
        return [
            'ok' => false,
            'message' => $errors[0],
            'errors' => $errors,
            'cfg' => $cfg,
            'reload' => false,
            'ui' => [],
        ];
    }

    $new = $cfg;
    $new['ignore_localhost'] = $ignoreLocalhost;
    $new['ignore_ips'] = $ignoreIps;
    $new['filter_bots'] = $filterBots;
    $new['trust_proxy'] = $trustProxy;
    $new['process_visitor_ip'] = $processVisitorIp;
    unset($new['country_detection']);
    $new['excluded_paths'] = $excludedPaths;
    $new['referrer_blocklist'] = $referrerBlock;

    if (!doostats_write_config($new)) {
        return [
            'ok' => false,
            'message' => t('settings.error.config_write'),
            'errors' => [t('settings.error.config_write')],
            'cfg' => $cfg,
            'reload' => false,
            'ui' => [],
        ];
    }

    return [
        'ok' => true,
        'message' => t('settings.notice.advanced_saved'),
        'errors' => [],
        'cfg' => $new,
        'reload' => false,
        'ui' => [
            'ignore_ips' => implode("\n", $ignoreIps),
            'excluded_paths' => implode("\n", $excludedPaths),
            'referrer_blocklist' => implode("\n", $referrerBlock),
        ],
    ];
}

/**
 * @param array<string, mixed> $cfg
 * @param array<string, mixed> $post
 * @return array{ok:bool,message:string,errors:list<string>,cfg:array<string,mixed>,reload:bool,ui:array<string,mixed>}
 */
function doostats_settings_save_password(array $cfg, array $post): array
{
    $errors = [];
    $current = (string) ($post['current_password'] ?? '');
    $pass = (string) ($post['new_password'] ?? '');
    $pass2 = (string) ($post['new_password2'] ?? '');

    if (!auth_verify_password($current)) {
        $errors[] = t('settings.error.current_password');
    }
    if (strlen($pass) < 8) {
        $errors[] = t('settings.error.new_password_len');
    }
    if ($pass !== $pass2) {
        $errors[] = t('settings.error.passwords_mismatch');
    }

    if ($errors !== []) {
        return [
            'ok' => false,
            'message' => $errors[0],
            'errors' => $errors,
            'cfg' => $cfg,
            'reload' => false,
            'ui' => [],
        ];
    }

    $new = $cfg;
    $new['admin_password_hash'] = password_hash($pass, PASSWORD_DEFAULT);
    if (!doostats_write_config($new)) {
        return [
            'ok' => false,
            'message' => t('settings.error.config_write'),
            'errors' => [t('settings.error.config_write')],
            'cfg' => $cfg,
            'reload' => false,
            'ui' => [],
        ];
    }

    return [
        'ok' => true,
        'message' => t('settings.notice.password_updated'),
        'errors' => [],
        'cfg' => $new,
        'reload' => false,
        'ui' => ['clear_password_fields' => true],
    ];
}

/**
 * @param array<string, mixed> $cfg
 * @param array<string, mixed> $post
 * @param array<string, mixed> $files
 * @return array{ok:bool,message:string,errors:list<string>,cfg:array<string,mixed>,reload:bool,ui:array<string,mixed>}
 */
function doostats_settings_save_profile(array $cfg, array $post, array $files): array
{
    $errors = [];
    $userName = trim((string) ($post['profile_label'] ?? $post['user_name'] ?? ''));
    $userName = mb_substr($userName, 0, 20);
    if ($userName === '') {
        $userName = 'Admin';
    }
    $dataDir = rtrim((string) ($cfg['data_dir'] ?? dirname(__DIR__) . '/data'), '/\\');

    $new = $cfg;
    $new['user_name'] = $userName;

    $upload = $files['avatar'] ?? null;
    $hasUpload = is_array($upload) && (int) ($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;
    $movedDest = null;

    if ($hasUpload) {
        if ((int) $upload['error'] !== UPLOAD_ERR_OK) {
            $errors[] = t('settings.error.upload_failed');
        } elseif ((int) ($upload['size'] ?? 0) > 1024 * 1024) {
            $errors[] = t('settings.error.image_too_large');
        } elseif (!is_uploaded_file((string) $upload['tmp_name'])) {
            $errors[] = t('settings.error.invalid_upload');
        } else {
            $info = @getimagesize((string) $upload['tmp_name']);
            $mime = is_array($info) ? (string) ($info['mime'] ?? '') : '';
            $extByMime = ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/gif' => 'gif', 'image/webp' => 'webp'];
            if (!isset($extByMime[$mime])) {
                $errors[] = t('settings.error.unsupported_image');
            } elseif ((int) ($info[0] ?? 0) > 6000 || (int) ($info[1] ?? 0) > 6000) {
                $errors[] = t('settings.error.image_dimensions');
            } else {
                $stored = doostats_store_avatar((string) $upload['tmp_name'], $extByMime[$mime], $dataDir);
                if ($stored !== null) {
                    $movedDest = $dataDir . '/' . $stored;
                    $new['avatar'] = $stored;
                } else {
                    $errors[] = t('settings.error.store_image');
                }
            }
        }
    }

    if ($errors !== []) {
        if ($movedDest !== null) {
            @unlink($movedDest);
        }
        return [
            'ok' => false,
            'message' => $errors[0],
            'errors' => $errors,
            'cfg' => $cfg,
            'reload' => false,
            'ui' => [],
        ];
    }

    if (!doostats_write_config($new)) {
        if ($movedDest !== null) {
            @unlink($movedDest);
        }
        return [
            'ok' => false,
            'message' => t('settings.error.config_write'),
            'errors' => [t('settings.error.config_write')],
            'cfg' => $cfg,
            'reload' => false,
            'ui' => [],
        ];
    }

    if ($movedDest !== null) {
        $old = basename((string) ($cfg['avatar'] ?? ''));
        if ($old !== '' && $old !== basename($movedDest) && is_file($dataDir . '/' . $old)) {
            @unlink($dataDir . '/' . $old);
        }
    }

    $avatarName = basename((string) ($new['avatar'] ?? ''));
    $avatarUrl = '';
    if ($avatarName !== '' && is_file($dataDir . '/' . $avatarName)) {
        $avatarUrl = 'avatar.php?v=' . (int) @filemtime($dataDir . '/' . $avatarName);
    }

    return [
        'ok' => true,
        'message' => t('settings.notice.profile_saved'),
        'errors' => [],
        'cfg' => $new,
        'reload' => false,
        'ui' => [
            'user_name' => $userName,
            'avatar_url' => $avatarUrl,
            'has_avatar' => $avatarUrl !== '',
        ],
    ];
}

/**
 * @param array<string, mixed> $cfg
 * @return array{ok:bool,message:string,errors:list<string>,cfg:array<string,mixed>,reload:bool,ui:array<string,mixed>}
 */
function doostats_settings_save_avatar_remove(array $cfg): array
{
    $dataDir = rtrim((string) ($cfg['data_dir'] ?? dirname(__DIR__) . '/data'), '/\\');
    $old = basename((string) ($cfg['avatar'] ?? ''));
    if ($old !== '' && is_file($dataDir . '/' . $old)) {
        @unlink($dataDir . '/' . $old);
    }
    $new = $cfg;
    $new['avatar'] = '';
    if (!doostats_write_config($new)) {
        return [
            'ok' => false,
            'message' => t('settings.error.config_update'),
            'errors' => [t('settings.error.config_update')],
            'cfg' => $cfg,
            'reload' => false,
            'ui' => [],
        ];
    }

    return [
        'ok' => true,
        'message' => t('settings.notice.avatar_removed'),
        'errors' => [],
        'cfg' => $new,
        'reload' => false,
        'ui' => [
            'user_name' => (string) (($new['user_name'] ?? '') !== '' ? $new['user_name'] : t('nav.user_fallback')),
            'avatar_url' => '',
            'has_avatar' => false,
        ],
    ];
}

/**
 * @param array<string, mixed> $cfg
 * @param array<string, mixed> $post
 * @return array{ok:bool,message:string,errors:list<string>,cfg:array<string,mixed>,reload:bool,ui:array<string,mixed>}
 */
function doostats_settings_save_reports(array $cfg, array $post): array
{
    $errors = [];
    $digestEnabled = !empty($post['digest_enabled']);
    $digestEmail = trim((string) ($post['digest_email'] ?? ''));

    if ($digestEnabled && ($digestEmail === '' || !filter_var($digestEmail, FILTER_VALIDATE_EMAIL))) {
        $errors[] = t('settings.reports.error.email');
    } elseif ($digestEmail !== '' && !filter_var($digestEmail, FILTER_VALIDATE_EMAIL)) {
        $errors[] = t('settings.reports.error.email');
    }

    $new = doostats_mail_apply_post($cfg, $post);
    $new['digest_enabled'] = $digestEnabled;
    $new['digest_email'] = $digestEmail;

    if ($digestEnabled) {
        foreach (doostats_mail_smtp_errors($new) as $smtpError) {
            $errors[] = $smtpError;
        }
    }

    if ($errors !== []) {
        return [
            'ok' => false,
            'message' => $errors[0],
            'errors' => $errors,
            'cfg' => $cfg,
            'reload' => false,
            'ui' => [],
        ];
    }

    if (!doostats_write_config($new)) {
        return [
            'ok' => false,
            'message' => t('settings.error.config_write'),
            'errors' => [t('settings.error.config_write')],
            'cfg' => $cfg,
            'reload' => false,
            'ui' => [],
        ];
    }

    return [
        'ok' => true,
        'message' => t('settings.reports.notice.saved'),
        'errors' => [],
        'cfg' => $new,
        'reload' => false,
        'ui' => [
            'digest_enabled' => $digestEnabled,
            'digest_email' => $digestEmail,
            'mail_transport' => doostats_mail_transport($new),
            'status' => doostats_digest_status_label(),
        ],
    ];
}

/**
 * @param array<string, mixed> $cfg
 * @param array<string, mixed> $post
 * @return array{ok:bool,message:string,errors:list<string>,cfg:array<string,mixed>,reload:bool,ui:array<string,mixed>}
 */
function doostats_settings_save_reset_stats(array $cfg, array $post): array
{
    $password = (string) ($post['confirm_password'] ?? '');
    if ($password === '') {
        return [
            'ok' => false,
            'message' => t('settings.error.reset_password_required'),
            'errors' => [t('settings.error.reset_password_required')],
            'cfg' => $cfg,
            'reload' => false,
            'ui' => [],
        ];
    }
    if (!auth_verify_password($password)) {
        return [
            'ok' => false,
            'message' => t('settings.error.reset_password_wrong'),
            'errors' => [t('settings.error.reset_password_wrong')],
            'cfg' => $cfg,
            'reload' => false,
            'ui' => [],
        ];
    }
    if (!analytics_reset_stats()) {
        return [
            'ok' => false,
            'message' => t('settings.error.reset_failed'),
            'errors' => [t('settings.error.reset_failed')],
            'cfg' => $cfg,
            'reload' => false,
            'ui' => [],
        ];
    }

    return [
        'ok' => true,
        'message' => t('settings.notice.stats_reset'),
        'errors' => [],
        'cfg' => $cfg,
        'reload' => false,
        'ui' => ['clear_confirm_password' => true],
    ];
}
