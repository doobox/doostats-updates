<?php
/**
 * DooStats: first-party, cookieless analytics engine.
 * Aggregated counters in SQLite. No cookies, no raw IPs stored, no external
 * calls. This file is self-contained; the only dependency is request-ip.php.
 */
declare(strict_types=1);

require_once __DIR__ . '/request-ip.php';
require_once __DIR__ . '/install-path.php';
require_once __DIR__ . '/i18n.php';
require_once __DIR__ . '/ui-theme.php';

/**
 * Load config.php from the project root. Returns an empty array if it is
 * missing (e.g. before setup), so tracking simply no-ops rather than fatals.
 *
 * @return array<string, mixed>
 */
function analytics_config(): array
{
  if (isset($GLOBALS['__doostats_config']) && is_array($GLOBALS['__doostats_config'])) {
    return $GLOBALS['__doostats_config'];
  }

  $path = dirname(__DIR__) . '/config.php';
  $loaded = is_file($path) ? require $path : [];
  $GLOBALS['__doostats_config'] = is_array($loaded) ? $loaded : [];
  return $GLOBALS['__doostats_config'];
}

/**
 * Replace the in-request config cache. Call after writing config.php so the
 * same request (e.g. Settings save) sees the new values — PHP will not
 * re-evaluate a required file in one request.
 *
 * @param array<string, mixed> $config
 */
function analytics_config_set(array $config): void
{
  $GLOBALS['__doostats_config'] = $config;
}

function analytics_db_path(): string
{
  $config = analytics_config();
  $dir = (string) ($config['data_dir'] ?? dirname(__DIR__) . '/data');
  $filename = (string) ($config['db_name'] ?? 'analytics.sqlite');

  return rtrim($dir, '/\\') . '/' . $filename;
}

/**
 * Wipe all recorded analytics (pageviews, visitors, events, 404s, live map,
 * rate-limit buckets). Leaves config.php and avatar files untouched.
 * Schema is kept; empty tables are ready for new traffic.
 */
function analytics_reset_stats(): bool
{
  try {
    $pdo = analytics_connect();
    $tables = [
      'page_views',
      'events',
      'not_found',
      'daily_visitors',
      'hourly_views',
      'hourly_visitors',
      'browser_views',
      'live_visitors',
      'rate_limits',
    ];
    $pdo->beginTransaction();
    foreach ($tables as $table) {
      $pdo->exec('DELETE FROM ' . $table);
    }
    $pdo->commit();
    try {
      $pdo->exec('VACUUM');
    } catch (Throwable $e) {
      // VACUUM can fail under some lock conditions; data is already cleared.
    }
    return true;
  } catch (Throwable $e) {
    return false;
  }
}

function analytics_salt(): string
{
  return (string) (analytics_config()['salt'] ?? 'change-me-in-config');
}

function analytics_is_local_request(): bool
{
  return request_is_local_dev_hostname();
}

function analytics_client_ip(): string
{
  return request_client_ip();
}

function analytics_should_skip_tracking(): bool
{
  $config = analytics_config();

  if (!empty($config['ignore_localhost']) && analytics_is_local_request()) {
    return true;
  }

  // Drop crawlers/bots (on by default) so stats reflect real people.
  if (($config['filter_bots'] ?? true) && analytics_is_bot(analytics_user_agent())) {
    return true;
  }

  // Only accept beacons whose origin matches the configured domain allowlist.
  if (!analytics_host_allowed()) {
    return true;
  }

  $ip = analytics_client_ip();
  $ignored = $config['ignore_ips'] ?? [];
  if (!is_array($ignored)) {
    $ignored = [];
  }

  return $ip !== '' && in_array($ip, array_map('trim', $ignored), true);
}

function analytics_user_agent(): string
{
  return (string) ($_SERVER['HTTP_USER_AGENT'] ?? '');
}

/**
 * Heuristic bot detection from the User-Agent. First-party pattern list, no
 * external calls. A missing UA is treated as a bot/script, since real browsers
 * always send one.
 */
function analytics_is_bot(string $ua): bool
{
  $ua = trim($ua);
  if ($ua === '') {
    return true;
  }

  return (bool) preg_match(
    '~bot|crawl|spider|slurp|mediapartners|facebookexternalhit|embedly|quora'
    . '|pinterest|bitlybot|redditbot|tumblr|vkshare|w3c_validator|whatsapp'
    . '|telegrambot|discordbot|slackbot|twitterbot|linkedinbot|applebot'
    . '|bingpreview|yandex|baiduspider|duckduckbot|petalbot|semrush|ahrefs'
    . '|mj12bot|dotbot|screaming\s?frog|headless|phantomjs|python-requests'
    . '|\bcurl\b|wget|go-http-client|axios|node-fetch|libwww-perl|okhttp'
    . '|java/|scrapy|masscan|zgrab|censys|monitoring|uptime|pingdom'
    . '|statuscake|gtmetrix|lighthouse|pagespeed|feedfetcher|feedburner~i',
    $ua
  );
}

/**
 * Reduce any host or URL string to a bare, comparable hostname:
 * lowercased, scheme/port/path stripped, and a leading "www." removed.
 */
function analytics_normalize_host(string $value): string
{
  $value = strtolower(trim($value));
  if ($value === '' || $value === 'null') {
    return '';
  }
  if (!str_contains($value, '://')) {
    $value = 'http://' . $value;
  }
  $host = (string) (parse_url($value, PHP_URL_HOST) ?: '');
  if (str_starts_with($host, 'www.')) {
    $host = substr($host, 4);
  }
  return $host;
}

/**
 * Hosts whose beacons we accept, derived automatically from the configured
 * site_url so stats only ever count the customer's own site. Returns an empty
 * list only when site_url is unset — in that case we accept everything rather
 * than silently dropping all traffic.
 *
 * @return list<string>
 */
function analytics_allowed_hosts(): array
{
  $siteHost = analytics_normalize_host((string) (analytics_config()['site_url'] ?? ''));
  return $siteHost === '' ? [] : [$siteHost];
}

/**
 * Best-effort origin of the current beacon: prefer the page that sent it
 * (Origin, then Referer) and fall back to the request Host.
 */
function analytics_request_host(): string
{
  foreach ([($_SERVER['HTTP_ORIGIN'] ?? ''), ($_SERVER['HTTP_REFERER'] ?? '')] as $candidate) {
    $host = analytics_normalize_host((string) $candidate);
    if ($host !== '') {
      return $host;
    }
  }
  return analytics_normalize_host((string) ($_SERVER['HTTP_HOST'] ?? ''));
}

/**
 * Whether the current request's origin is permitted. An empty allowlist lets
 * everything through; otherwise the origin must match a listed host exactly or
 * be a subdomain of one.
 */
function analytics_host_allowed(): bool
{
  $allowed = analytics_allowed_hosts();
  if ($allowed === []) {
    return true;
  }
  $host = analytics_request_host();
  if ($host === '') {
    return false;
  }
  foreach ($allowed as $entry) {
    if ($host === $entry || str_ends_with($host, '.' . $entry)) {
      return true;
    }
  }
  return false;
}

/**
 * Whether a normalised path falls under any configured excluded prefix
 * (e.g. "/admin" excludes "/admin" and "/admin/anything").
 */
function analytics_path_excluded(string $path): bool
{
  $list = analytics_config()['excluded_paths'] ?? [];
  if (!is_array($list)) {
    return false;
  }
  foreach ($list as $prefix) {
    $prefix = trim((string) $prefix);
    if ($prefix === '') {
      continue;
    }
    if ($prefix[0] !== '/') {
      $prefix = '/' . $prefix;
    }
    $prefix = rtrim($prefix, '/');
    if ($prefix === '') {
      continue;
    }
    if ($path === $prefix || str_starts_with($path, $prefix . '/')) {
      return true;
    }
  }
  return false;
}

/**
 * Known referrer-spam domains plus any the admin has added. Kept first-party;
 * dropping these keeps the referrers report clean.
 *
 * @return list<string>
 */
function analytics_referrer_blocklist(): array
{
  static $builtin = [
    'semalt.com', 'buttons-for-website.com', 'darodar.com', 'best-seo-offer.com',
    'free-share-buttons.com', 'event-tracking.com', 'get-free-traffic-now.com',
    'sitevaluation.org', 'trafficmonetizer.org', 'simple-share-buttons.com',
    '4webmasters.org', 'ilovevitaly.com', 'econom.co', 'priceg.com',
    'o-o-6-o-o.com', '7makemoneyonline.com', 'floating-share-buttons.com',
    'video--production.com', 'social-buttons.com', 'guardlink.org',
  ];

  $list = $builtin;
  $extra = analytics_config()['referrer_blocklist'] ?? [];
  if (is_array($extra)) {
    foreach ($extra as $entry) {
      $host = analytics_normalize_host((string) $entry);
      if ($host !== '') {
        $list[] = $host;
      }
    }
  }
  return $list;
}

/** Whether a referrer host is on the (built-in + custom) spam blocklist. */
function analytics_referrer_blocked(string $referrerHost): bool
{
  $host = analytics_normalize_host($referrerHost);
  if ($host === '') {
    return false;
  }
  foreach (analytics_referrer_blocklist() as $entry) {
    if ($host === $entry || str_ends_with($host, '.' . $entry)) {
      return true;
    }
  }
  return false;
}

/**
 * Stable cookieless visitor id for the current request.
 * Same IP + user agent (+ site salt) → same hash across days, so period
 * uniques and returning visitors mean distinct people, not visitor-days.
 * Raw IP is never stored — only this hash.
 *
 * Returns null when visitor IP processing is disabled in Settings (no unique /
 * returning / live visitor identity without an IP).
 */
function analytics_client_hash(): ?string
{
  if (!analytics_process_visitor_ip()) {
    return null;
  }

  $ip = analytics_client_ip();
  if ($ip === '') {
    $ip = 'unknown';
  }

  $ua = trim(analytics_user_agent());
  if ($ua === '') {
    $ua = 'unknown';
  }
  // Cap UA length so extreme/garbage headers can't bloat the hash input.
  if (strlen($ua) > 300) {
    $ua = substr($ua, 0, 300);
  }

  return hash('sha256', $ip . '|' . $ua . '|' . analytics_salt());
}

/**
 * Whether visitor IP may be read for hashing and country lookup. Default on.
 * When off, uniques / returning / live map / country stats are unavailable;
 * pageviews and other aggregates still work. Raw IP is never stored either way.
 */
function analytics_process_visitor_ip(): bool
{
  $cfg = analytics_config();
  if (array_key_exists('process_visitor_ip', $cfg)) {
    return !empty($cfg['process_visitor_ip']);
  }
  // Older installs may only have country_detection; that was geo-only, so IP
  // hashing stayed on. Default to processing IP unless the new key says otherwise.
  return true;
}

/**
 * Rate-limit bucket key for the current request. Uses the visitor hash when IP
 * processing is on; otherwise a non-stored UA-derived key (still no IP).
 */
function analytics_request_rate_key(string $prefix): string
{
  $hash = analytics_client_hash();
  if ($hash !== null) {
    return $prefix . $hash;
  }

  $ua = trim(analytics_user_agent());
  if ($ua === '') {
    $ua = 'unknown';
  }
  if (strlen($ua) > 300) {
    $ua = substr($ua, 0, 300);
  }

  return $prefix . hash('sha256', 'noip|' . $ua . '|' . analytics_salt());
}

function analytics_timezone(): DateTimeZone
{
  $tz = (string) (analytics_config()['timezone'] ?? 'UTC');
  try {
    return new DateTimeZone($tz);
  } catch (Throwable $e) {
    return new DateTimeZone('UTC');
  }
}

function analytics_now(): DateTimeImmutable
{
  return new DateTimeImmutable('now', analytics_timezone());
}

function analytics_today(): string
{
  return analytics_now()->format('Y-m-d');
}

function analytics_connect(): PDO
{
  $path = analytics_db_path();
  $dir = dirname($path);
  if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
    throw new RuntimeException('Unable to create analytics data directory.');
  }

  $pdo = new PDO('sqlite:' . $path, null, null, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  ]);

  // SQLite locking. In the default rollback-journal mode a writer takes an
  // exclusive lock that blocks every reader, so a tracking beacon writing a hit
  // (triggered by visiting the tracked site) can stall a dashboard read and
  // make the page appear to hang. WAL lets readers and the single writer run
  // concurrently — readers see the last committed snapshot instead of waiting.
  // The busy timeout absorbs the brief moments two writers overlap rather than
  // failing immediately. journal_mode is persistent on the file; busy_timeout
  // and synchronous are per-connection, so they are set on every connect.
  $pdo->exec('PRAGMA busy_timeout = 5000');
  $pdo->exec('PRAGMA journal_mode = WAL');
  $pdo->exec('PRAGMA synchronous = NORMAL');

  analytics_ensure_schema($pdo);

  return $pdo;
}

function analytics_ensure_schema(PDO $pdo): void
{
  $pdo->exec(
    'CREATE TABLE IF NOT EXISTS page_views (
      date TEXT NOT NULL,
      path TEXT NOT NULL,
      device TEXT NOT NULL,
      referrer TEXT NOT NULL,
      country TEXT NOT NULL,
      views INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (date, path, device, referrer, country)
    )'
  );

  $pdo->exec(
    'CREATE TABLE IF NOT EXISTS events (
      date TEXT NOT NULL,
      event_name TEXT NOT NULL,
      count INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (date, event_name)
    )'
  );

  $pdo->exec(
    'CREATE TABLE IF NOT EXISTS not_found (
      date TEXT NOT NULL,
      path TEXT NOT NULL,
      count INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (date, path)
    )'
  );

  $pdo->exec(
    'CREATE TABLE IF NOT EXISTS daily_visitors (
      date TEXT NOT NULL,
      client_hash TEXT NOT NULL,
      country TEXT NOT NULL,
      device TEXT NOT NULL,
      page_views INTEGER NOT NULL DEFAULT 1,
      PRIMARY KEY (date, client_hash)
    )'
  );
  // Returning-visitor lookups join on client_hash then check an earlier date;
  // the PK is (date, client_hash) so this secondary index keeps that cheap
  // once retention grows past a few weeks.
  $pdo->exec(
    'CREATE INDEX IF NOT EXISTS idx_daily_visitors_hash_date
     ON daily_visitors (client_hash, date)'
  );

  // Pageviews by hour of day (site timezone). Used for the Peak Times chart.
  $pdo->exec(
    'CREATE TABLE IF NOT EXISTS hourly_views (
      date TEXT NOT NULL,
      hour INTEGER NOT NULL,
      views INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (date, hour)
    )'
  );

  // Distinct visitors by hour of day (site timezone). Powers the Today traffic chart.
  $pdo->exec(
    'CREATE TABLE IF NOT EXISTS hourly_visitors (
      date TEXT NOT NULL,
      hour INTEGER NOT NULL,
      client_hash TEXT NOT NULL,
      PRIMARY KEY (date, hour, client_hash)
    )'
  );

  // Pageviews by browser family (Chrome, Safari, …). Powers the Browsers chart.
  $pdo->exec(
    'CREATE TABLE IF NOT EXISTS browser_views (
      date TEXT NOT NULL,
      browser TEXT NOT NULL,
      views INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (date, browser)
    )'
  );

  $pdo->exec(
    'CREATE TABLE IF NOT EXISTS rate_limits (
      bucket TEXT NOT NULL PRIMARY KEY,
      hits INTEGER NOT NULL DEFAULT 0,
      expires_at INTEGER NOT NULL
    )'
  );

  $pdo->exec(
    'CREATE TABLE IF NOT EXISTS live_visitors (
      client_hash TEXT NOT NULL PRIMARY KEY,
      country TEXT NOT NULL,
      lat REAL,
      lng REAL,
      last_seen INTEGER NOT NULL
    )'
  );

  $liveCols = array_column($pdo->query('PRAGMA table_info(live_visitors)')->fetchAll(), 'name');
  if (!in_array('lat', $liveCols, true)) {
    $pdo->exec('ALTER TABLE live_visitors ADD COLUMN lat REAL');
  }
  if (!in_array('lng', $liveCols, true)) {
    $pdo->exec('ALTER TABLE live_visitors ADD COLUMN lng REAL');
  }
}

function analytics_detect_country(): string
{
  return analytics_detect_geo()['country'];
}

/**
 * Resolve country + approximate coordinates for the current request.
 *
 * The country comes only from a server/CDN-provided header or env var
 * (e.g. Apache mod_geoip's GEOIP_COUNTRY_CODE). Coordinates are always the
 * country centroid, so there are no city-level details and, crucially, no
 * third-party calls. If the host provides no geo variable, the country is
 * simply "unknown". When visitor IP processing is disabled, always returns
 * unknown with no coordinates.
 *
 * @return array{country: string, lat: ?float, lng: ?float}
 */
function analytics_detect_geo(): array
{
  if (!analytics_process_visitor_ip()) {
    return ['country' => 'unknown', 'lat' => null, 'lng' => null];
  }

  if (analytics_is_local_request()) {
    return ['country' => 'local', 'lat' => null, 'lng' => null];
  }

  $country = analytics_geo_country_from_server();
  if ($country === '') {
    $country = analytics_geo_country_from_db(analytics_client_ip());
  }
  if ($country === '') {
    return ['country' => 'unknown', 'lat' => null, 'lng' => null];
  }

  $centroid = analytics_country_centroid($country);
  return [
    'country' => $country,
    'lat' => $centroid['lat'] ?? null,
    'lng' => $centroid['lng'] ?? null,
  ];
}

/**
 * Read a two-letter country code from a server/CDN-provided variable.
 * No third-party calls are made. Returns '' when nothing usable is present.
 */
function analytics_geo_country_from_server(): string
{
  $keys = [
    'GEOIP_COUNTRY_CODE',      // Apache mod_geoip (env var, no HTTP_ prefix)
    'GEOIP_COUNTRY_CODE_V6',
    'MM_COUNTRY_CODE',         // some mod_maxminddb configs
    'MMDB_ADDR_COUNTRY_CODE',
    'HTTP_X_COUNTRY_CODE',     // upstream proxy passthrough header
    'HTTP_X_GEO_COUNTRY',
  ];

  foreach ($keys as $key) {
    $code = strtoupper(trim((string) ($_SERVER[$key] ?? '')));
    if ($code !== '' && $code !== 'XX' && preg_match('/^[A-Z]{2}$/', $code)) {
      return $code;
    }
  }

  return '';
}

/**
 * Resolve a country from the visitor's IP using the self-hosted IP database
 * (includes/geoip/ip-country.dat). No third-party calls. Returns '' when the
 * file is missing, the IP is unusable, or the range is unallocated.
 */
function analytics_geo_country_from_db(string $ip): string
{
  $ip = trim($ip);
  if ($ip === '') {
    return '';
  }

  $packed = @inet_pton($ip);
  if ($packed === false) {
    return '';
  }

  $meta = analytics_geoip_open();
  if ($meta === null) {
    return '';
  }

  // Treat IPv4-mapped IPv6 (::ffff:a.b.c.d) as plain IPv4.
  if (strlen($packed) === 16
      && substr($packed, 0, 12) === "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff") {
    $packed = substr($packed, 12);
  }

  if (strlen($packed) === 4) {
    $idx = analytics_geoip_search($meta, 'v4', unpack('N', $packed)[1]);
  } elseif (strlen($packed) === 16) {
    $idx = analytics_geoip_search($meta, 'v6', $packed);
  } else {
    return '';
  }

  if ($idx === null) {
    return '';
  }

  $code = $meta['codes'][$idx] ?? '';
  return ($code === '' || $code === 'ZZ') ? '' : $code;
}

/**
 * Open and cache the GeoIP data file header. Returns null when unavailable.
 *
 * @return array{fh: resource, codes: array<int,string>, v4_off: int, v4_count: int, v6_off: int, v6_count: int}|null
 */
function analytics_geoip_open(): ?array
{
  static $meta = null;
  static $tried = false;
  if ($tried) {
    return $meta;
  }
  $tried = true;

  $file = __DIR__ . '/geoip/ip-country.dat';
  $fh = @fopen($file, 'rb');
  if ($fh === false) {
    return null;
  }

  if (fread($fh, 8) !== 'DBIPCX01') {
    fclose($fh);
    return null;
  }

  $codeCount = unpack('n', fread($fh, 2))[1];
  $codesBlob = (string) fread($fh, $codeCount * 2);
  $codes = [];
  for ($i = 0; $i < $codeCount; $i++) {
    $codes[$i] = substr($codesBlob, $i * 2, 2);
  }

  $v4Count = unpack('N', fread($fh, 4))[1];
  $v6Count = unpack('N', fread($fh, 4))[1];
  $v4Off = 8 + 2 + $codeCount * 2 + 8;

  $meta = [
    'fh' => $fh,
    'codes' => $codes,
    'v4_off' => $v4Off,
    'v4_count' => $v4Count,
    'v6_off' => $v4Off + $v4Count * 6,
    'v6_count' => $v6Count,
  ];
  return $meta;
}

/**
 * Binary search a block for the record whose range covers $key.
 * Records are sorted by start; a record's range runs until the next start.
 *
 * @param array{fh: resource, v4_off: int, v4_count: int, v6_off: int, v6_count: int} $meta
 * @param int|string $key uint32 for v4, 16-byte binary string for v6
 */
function analytics_geoip_search(array $meta, string $block, int|string $key): ?int
{
  if ($block === 'v4') {
    $offset = $meta['v4_off'];
    $count = $meta['v4_count'];
    $recSize = 6;
  } else {
    $offset = $meta['v6_off'];
    $count = $meta['v6_count'];
    $recSize = 18;
  }

  $fh = $meta['fh'];
  $lo = 0;
  $hi = $count - 1;
  $found = null;

  while ($lo <= $hi) {
    $mid = intdiv($lo + $hi, 2);
    fseek($fh, $offset + $mid * $recSize);
    $rec = fread($fh, $recSize);
    if ($rec === false || strlen($rec) < $recSize) {
      break;
    }

    if ($block === 'v4') {
      $start = unpack('N', substr($rec, 0, 4))[1];
      $covers = $start <= $key;
      $codeAt = 4;
    } else {
      $start = substr($rec, 0, 16);
      $covers = strcmp($start, (string) $key) <= 0;
      $codeAt = 16;
    }

    if ($covers) {
      $found = unpack('n', substr($rec, $codeAt, 2))[1];
      $lo = $mid + 1;
    } else {
      $hi = $mid - 1;
    }
  }

  return $found;
}

/**
 * ISO country code => ['name' => string, 'lat' => float, 'lng' => float].
 * Generated by scripts/build-geoip.php; empty if the file is absent.
 *
 * @return array<string, array{name: string, lat: float, lng: float}>
 */
function analytics_country_data(): array
{
  static $data = null;
  if ($data === null) {
    $file = __DIR__ . '/geoip/countries.php';
    $loaded = is_file($file) ? require $file : [];
    $data = is_array($loaded) ? $loaded : [];
  }
  return $data;
}

/**
 * Human label for an ISO country code (chart axes, map tooltips, top country).
 * Uses intl Locale::getDisplayRegion when available, driven by ui_language;
 * otherwise the built-in English maps / geoip names.
 */
function analytics_country_label(string $code): string
{
  $raw = strtolower(trim($code));
  if ($raw === 'local') {
    return 'Local';
  }
  if ($raw === '' || $raw === 'unknown') {
    return function_exists('t') ? t('js.map.unknown_country') : 'Unknown';
  }

  $code = strtoupper(trim($code));
  $lang = function_exists('i18n_language') ? i18n_language() : 'en';

  static $cache = [];
  $cacheKey = $lang . ':' . $code;
  if (isset($cache[$cacheKey])) {
    return $cache[$cacheKey];
  }

  if (extension_loaded('intl') && class_exists('Locale')) {
    $displayLocale = str_replace('-', '_', $lang);
    $name = \Locale::getDisplayRegion('und_' . $code, $displayLocale);
    if (is_string($name)) {
      $name = trim($name);
      // ICU returns the raw code when the region is unknown.
      if ($name !== '' && strtoupper($name) !== $code) {
        $cache[$cacheKey] = $name;
        return $name;
      }
    }
  }

  static $labels = [
    'JE' => 'Jersey',
    'GB' => 'United Kingdom',
    'GG' => 'Guernsey',
    'IM' => 'Isle of Man',
    'IE' => 'Ireland',
    'FR' => 'France',
    'DE' => 'Germany',
    'US' => 'United States',
    'ES' => 'Spain',
    'PT' => 'Portugal',
    'NL' => 'Netherlands',
    'BE' => 'Belgium',
    'IT' => 'Italy',
    'CH' => 'Switzerland',
    'AT' => 'Austria',
    'PL' => 'Poland',
    'SE' => 'Sweden',
    'NO' => 'Norway',
    'DK' => 'Denmark',
    'FI' => 'Finland',
    'AU' => 'Australia',
    'CA' => 'Canada',
    'NZ' => 'New Zealand',
    'ZA' => 'South Africa',
    'AE' => 'United Arab Emirates',
    'IN' => 'India',
    'SG' => 'Singapore',
    'HK' => 'Hong Kong',
    'JP' => 'Japan',
    'BR' => 'Brazil',
  ];

  if (isset($labels[$code])) {
    $cache[$cacheKey] = $labels[$code];
    return $labels[$code];
  }

  $name = analytics_country_data()[$code]['name'] ?? '';
  if ($name !== '') {
    $cache[$cacheKey] = $name;
    return $name;
  }

  $fallback = $code !== '' ? $code : (function_exists('t') ? t('js.map.unknown_country') : 'Unknown');
  $cache[$cacheKey] = $fallback;
  return $fallback;
}

/**
 * Approximate country centroid for the live map.
 *
 * @return array{lat: float, lng: float}|null
 */
function analytics_country_centroid(string $code): ?array
{
  static $map = [
    'JE' => ['lat' => 49.2144, 'lng' => -2.1313],
    'GB' => ['lat' => 54.7024, 'lng' => -3.2766],
    'GG' => ['lat' => 49.4600, 'lng' => -2.5800],
    'IM' => ['lat' => 54.2361, 'lng' => -4.5481],
    'IE' => ['lat' => 53.4129, 'lng' => -8.2439],
    'FR' => ['lat' => 46.2276, 'lng' => 2.2137],
    'DE' => ['lat' => 51.1657, 'lng' => 10.4515],
    'US' => ['lat' => 39.8283, 'lng' => -98.5795],
    'ES' => ['lat' => 40.4637, 'lng' => -3.7492],
    'PT' => ['lat' => 39.3999, 'lng' => -8.2245],
    'NL' => ['lat' => 52.1326, 'lng' => 5.2913],
    'BE' => ['lat' => 50.5039, 'lng' => 4.4699],
    'AU' => ['lat' => -25.2744, 'lng' => 133.7751],
    'CA' => ['lat' => 56.1304, 'lng' => -106.3468],
    'NZ' => ['lat' => -40.9006, 'lng' => 174.8860],
    'IT' => ['lat' => 41.8719, 'lng' => 12.5674],
    'CH' => ['lat' => 46.8182, 'lng' => 8.2275],
    'AT' => ['lat' => 47.5162, 'lng' => 14.5501],
    'PL' => ['lat' => 51.9194, 'lng' => 19.1451],
    'SE' => ['lat' => 60.1282, 'lng' => 18.6435],
    'NO' => ['lat' => 60.4720, 'lng' => 8.4689],
    'DK' => ['lat' => 56.2639, 'lng' => 9.5018],
    'FI' => ['lat' => 61.9241, 'lng' => 25.7482],
    'ZA' => ['lat' => -30.5595, 'lng' => 22.9375],
    'AE' => ['lat' => 23.4241, 'lng' => 53.8478],
    'IN' => ['lat' => 20.5937, 'lng' => 78.9629],
    'SG' => ['lat' => 1.3521, 'lng' => 103.8198],
    'HK' => ['lat' => 22.3193, 'lng' => 114.1694],
    'JP' => ['lat' => 36.2048, 'lng' => 138.2529],
    'BR' => ['lat' => -14.2350, 'lng' => -51.9253],
  ];

  $code = strtoupper(trim($code));
  if (isset($map[$code])) {
    return $map[$code];
  }

  $data = analytics_country_data()[$code] ?? null;
  if (is_array($data) && isset($data['lat'], $data['lng'])) {
    return ['lat' => (float) $data['lat'], 'lng' => (float) $data['lng']];
  }

  return null;
}

function analytics_date_range(int $days): array
{
  $days = max(1, min($days, 90));
  $today = analytics_now()->setTime(0, 0);
  $dates = [];
  for ($i = $days - 1; $i >= 0; $i--) {
    $dates[] = $today->modify('-' . $i . ' days')->format('Y-m-d');
  }
  return $dates;
}

function analytics_period_bounds(int $days): array
{
  $dates = analytics_date_range($days);
  return [
    'from' => $dates[0],
    'to' => $dates[count($dates) - 1],
    'dates' => $dates,
  ];
}

/**
 * The equal-length window immediately before the current period.
 * E.g. last 7 days → the 7 days before that; today → yesterday.
 */
function analytics_previous_period_bounds(int $days): array
{
  $days = max(1, min($days, 90));
  $current = analytics_period_bounds($days);
  $tz = analytics_timezone();
  $prevEnd = (new DateTimeImmutable($current['from'], $tz))->modify('-1 day');
  $prevStart = $prevEnd->modify('-' . ($days - 1) . ' days');
  $dates = [];
  for ($i = 0; $i < $days; $i++) {
    $dates[] = $prevStart->modify('+' . $i . ' days')->format('Y-m-d');
  }
  return [
    'from' => $dates[0],
    'to' => $dates[count($dates) - 1],
    'dates' => $dates,
  ];
}

/**
 * Percent change from previous → current, rounded to a whole number.
 * Null when previous is 0 (can't divide).
 */
function analytics_percent_change(int $current, int $previous): ?int
{
  if ($previous <= 0) {
    return null;
  }
  return (int) round((($current - $previous) / $previous) * 100);
}

/**
 * Pageview totals for a date range (inclusive).
 */
function analytics_views_between(string $from, string $to): int
{
  $stmt = analytics_connect()->prepare(
    'SELECT COALESCE(SUM(views), 0) FROM page_views WHERE date BETWEEN :from AND :to'
  );
  $stmt->execute(['from' => $from, 'to' => $to]);
  return (int) $stmt->fetchColumn();
}

/**
 * Compare the selected period against the prior window of the same length.
 *
 * If older history is shorter than the selected range (new install, retention
 * trim, etc.), fall back to an equal-length slice of whatever we still have:
 * match N prior days against the most recent N days so the Up/Down % stays fair.
 *
 * When the selected range itself is longer than stored history, split the
 * available days in half (recent vs older) instead of giving up.
 *
 * @return array{
 *   previous_views: int,
 *   compare_views: int,
 *   views_change_percent: ?int,
 *   compare_days: int,
 *   fallback: bool
 * }
 */
function analytics_period_performance(int $days): array
{
  $days = max(1, min($days, 90));
  $pdo = analytics_connect();
  $tz = analytics_timezone();
  $today = analytics_now()->setTime(0, 0);
  $current = analytics_period_bounds($days);
  $idealPrev = analytics_previous_period_bounds($days);

  $empty = [
    'previous_views' => 0,
    'compare_views' => 0,
    'views_change_percent' => null,
    'compare_days' => 0,
    'fallback' => false,
  ];

  $earliestRaw = $pdo->query('SELECT MIN(date) FROM page_views')->fetchColumn();
  if (!is_string($earliestRaw) || $earliestRaw === '') {
    return $empty;
  }
  $earliest = new DateTimeImmutable($earliestRaw, $tz);
  $historyDays = (int) $earliest->diff($today)->days + 1;
  if ($historyDays < 2) {
    return $empty;
  }

  $currentFrom = new DateTimeImmutable($current['from'], $tz);

  if ($earliest < $currentFrom) {
    // History exists before the selected period — clip previous window if needed.
    $prevFromDt = new DateTimeImmutable(
      $idealPrev['from'] > $earliestRaw ? $idealPrev['from'] : $earliestRaw,
      $tz
    );
    $prevToDt = new DateTimeImmutable($idealPrev['to'], $tz);
    $compareDays = (int) $prevFromDt->diff($prevToDt)->days + 1;
    $fallback = $compareDays < $days;
  } else {
    // Selected range reaches the start of stored history — split what we have.
    $compareDays = intdiv($historyDays, 2);
    $fallback = true;
    if ($compareDays < 1) {
      return $empty;
    }
    $prevToDt = $today->modify('-' . $compareDays . ' days');
    $prevFromDt = $prevToDt->modify('-' . ($compareDays - 1) . ' days');
    if ($prevFromDt < $earliest) {
      $prevFromDt = $earliest;
      $compareDays = (int) $prevFromDt->diff($prevToDt)->days + 1;
    }
  }

  if ($compareDays < 1) {
    return $empty;
  }

  $prevFrom = $prevFromDt->format('Y-m-d');
  $prevTo = $prevToDt->format('Y-m-d');
  $curTo = $today->format('Y-m-d');
  $curFrom = $today->modify('-' . ($compareDays - 1) . ' days')->format('Y-m-d');

  $previousViews = analytics_views_between($prevFrom, $prevTo);
  $compareViews = analytics_views_between($curFrom, $curTo);

  return [
    'previous_views' => $previousViews,
    'compare_views' => $compareViews,
    'views_change_percent' => analytics_percent_change($compareViews, $previousViews),
    'compare_days' => $compareDays,
    'fallback' => $fallback,
  ];
}

function analytics_period_params(array $bounds): array
{
  return ['from' => $bounds['from'], 'to' => $bounds['to']];
}

function analytics_period_label(int $days): string
{
  $bounds = analytics_period_bounds($days);
  if ($days === 1) {
    return i18n_format_date($bounds['to'], 'period');
  }
  return i18n_format_date($bounds['from'], 'period')
    . ' – '
    . i18n_format_date($bounds['to'], 'period');
}

function analytics_normalize_path(string $path): ?string
{
  $path = trim($path);
  if ($path === '') {
    return '/';
  }
  if (!str_starts_with($path, '/')) {
    $path = '/' . $path;
  }
  if (str_contains($path, '..') || str_contains($path, '\\')) {
    return null;
  }
  if (!preg_match('#^/[A-Za-z0-9._/-]*$#', $path)) {
    return null;
  }
  if ($path !== '/' && str_ends_with($path, '/')) {
    $path = rtrim($path, '/');
  }
  if ($path !== '/' && str_ends_with($path, '.html')) {
    $path = substr($path, 0, -5) ?: '/';
  }
  if ($path === '/index') {
    $path = '/';
  }
  return $path;
}

function analytics_normalize_device(string $device): string
{
  return match ($device) {
    'mobile', 'tablet', 'desktop' => $device,
    default => 'desktop',
  };
}

/**
 * Map a User-Agent to a coarse browser family for the Top browsers chart.
 * Order matters (Edge before Chrome, Chrome before Safari). Raw UA is not stored.
 */
function analytics_detect_browser_family(string $ua = ''): string
{
  if ($ua === '') {
    $ua = analytics_user_agent();
  }
  $ua = trim($ua);
  if ($ua === '') {
    return 'Unknown';
  }

  // Check distinctive tokens before Chromium / Safari substrings.
  if (preg_match('/\bEdg(?:e|A|iOS)?\//i', $ua)) {
    return 'Edge';
  }
  if (preg_match('/\bOPR\/|\bOpera\b/i', $ua)) {
    return 'Opera';
  }
  if (preg_match('/\bSamsungBrowser\//i', $ua)) {
    return 'Samsung Internet';
  }
  if (preg_match('/\bUCBrowser\//i', $ua)) {
    return 'UC Browser';
  }
  if (preg_match('/\bYaBrowser\//i', $ua)) {
    return 'Yandex';
  }
  if (preg_match('/\bFirefox\/|\bFxiOS\//i', $ua)) {
    return 'Firefox';
  }
  if (preg_match('/\b(?:Chrome|CriOS|Chromium)\//i', $ua)) {
    return 'Chrome';
  }
  if (preg_match('/\bSafari\//i', $ua) && preg_match('/\bVersion\//i', $ua)) {
    return 'Safari';
  }
  if (preg_match('/\b(?:MSIE |Trident\/)/i', $ua)) {
    return 'Internet Explorer';
  }

  return 'Unknown';
}

function analytics_normalize_referrer(string $referrer): string
{
  $referrer = trim($referrer);
  if ($referrer === '') {
    return 'direct';
  }

  $host = parse_url($referrer, PHP_URL_HOST);
  if (!is_string($host) || $host === '') {
    return 'direct';
  }

  $host = strtolower($host);
  if (str_starts_with($host, 'www.')) {
    $host = substr($host, 4);
  }

  $siteHost = parse_url((string) (analytics_config()['site_url'] ?? ''), PHP_URL_HOST);
  if (is_string($siteHost) && strtolower($siteHost) === $host) {
    return 'direct';
  }

  return substr($host, 0, 120);
}

function analytics_rate_limit_ok(string $bucket, int $maxHits, int $windowSeconds): bool
{
  $pdo = analytics_connect();
  $now = time();
  $pdo->prepare('DELETE FROM rate_limits WHERE expires_at < :now')->execute(['now' => $now]);

  $stmt = $pdo->prepare('SELECT hits FROM rate_limits WHERE bucket = :bucket');
  $stmt->execute(['bucket' => $bucket]);
  $row = $stmt->fetch();

  if ($row === false) {
    $pdo->prepare(
      'INSERT INTO rate_limits (bucket, hits, expires_at) VALUES (:bucket, 1, :expires_at)'
    )->execute([
      'bucket' => $bucket,
      'expires_at' => $now + $windowSeconds,
    ]);
    return true;
  }

  if ((int) $row['hits'] >= $maxHits) {
    return false;
  }

  $pdo->prepare('UPDATE rate_limits SET hits = hits + 1 WHERE bucket = :bucket')
    ->execute(['bucket' => $bucket]);

  return true;
}

/**
 * How many days of aggregated stats to keep (default 45, hard cap 90).
 */
function analytics_retention_days(): int
{
  $days = (int) (analytics_config()['retention_days'] ?? 45);
  if ($days < 1) {
    return 45;
  }
  // Cap at 90 so installs stay within a predictable storage window.
  return min(90, $days);
}

/**
 * Delete aggregated rows older than the retention window. Cheap, and called at
 * most once per day via a rate-limit guard, so the dated tables never grow
 * without bound. (live_visitors and rate_limits already self-prune.)
 */
function analytics_prune_old_data(PDO $pdo): void
{
  $cutoff = analytics_now()
    ->sub(new DateInterval('P' . analytics_retention_days() . 'D'))
    ->format('Y-m-d');

  foreach (['page_views', 'events', 'not_found', 'daily_visitors', 'hourly_views', 'hourly_visitors', 'browser_views'] as $table) {
    $pdo->prepare("DELETE FROM {$table} WHERE date < :cutoff")
      ->execute(['cutoff' => $cutoff]);
  }
}

function analytics_record_pageview(string $path, string $device, string $referrer): bool
{
  if (analytics_should_skip_tracking()) {
    return false;
  }

  $path = analytics_normalize_path($path);
  if ($path === null) {
    return false;
  }
  if (analytics_path_excluded($path)) {
    return false;
  }

  $device = analytics_normalize_device($device);
  $referrer = analytics_normalize_referrer($referrer);
  if ($referrer !== 'direct' && analytics_referrer_blocked($referrer)) {
    return false;
  }
  $date = analytics_today();
  $hour = (int) analytics_now()->format('G'); // 0–23 in the site timezone
  $clientHash = analytics_client_hash();
  $trackVisitors = $clientHash !== null;

  if (!analytics_rate_limit_ok(analytics_request_rate_key('pv:'), 120, 3600)) {
    return false;
  }

  $pdo = analytics_connect();

  $country = 'unknown';
  $lat = null;
  $lng = null;

  if ($trackVisitors) {
    // Reuse coordinates already resolved for this visitor to avoid repeat geo work.
    $existing = $pdo->prepare('SELECT country, lat, lng FROM live_visitors WHERE client_hash = :h');
    $existing->execute(['h' => $clientHash]);
    $known = $existing->fetch();

    if (is_array($known) && $known['lat'] !== null && $known['lng'] !== null && (string) $known['country'] !== '') {
      $country = (string) $known['country'];
      $lat = (float) $known['lat'];
      $lng = (float) $known['lng'];
    } else {
      $geo = analytics_detect_geo();
      $country = $geo['country'];
      $lat = $geo['lat'];
      $lng = $geo['lng'];
    }
  }

  $pdo->prepare(
    'INSERT INTO page_views (date, path, device, referrer, country, views)
     VALUES (:date, :path, :device, :referrer, :country, 1)
     ON CONFLICT(date, path, device, referrer, country) DO UPDATE SET views = views + 1'
  )->execute([
    'date' => $date,
    'path' => $path,
    'device' => $device,
    'referrer' => $referrer,
    'country' => $country,
  ]);

  $pdo->prepare(
    'INSERT INTO hourly_views (date, hour, views)
     VALUES (:date, :hour, 1)
     ON CONFLICT(date, hour) DO UPDATE SET views = views + 1'
  )->execute([
    'date' => $date,
    'hour' => $hour,
  ]);

  $browser = analytics_detect_browser_family();
  $pdo->prepare(
    'INSERT INTO browser_views (date, browser, views)
     VALUES (:date, :browser, 1)
     ON CONFLICT(date, browser) DO UPDATE SET views = views + 1'
  )->execute([
    'date' => $date,
    'browser' => $browser,
  ]);

  if ($trackVisitors) {
    $pdo->prepare(
      'INSERT INTO hourly_visitors (date, hour, client_hash)
       VALUES (:date, :hour, :client_hash)
       ON CONFLICT(date, hour, client_hash) DO NOTHING'
    )->execute([
      'date' => $date,
      'hour' => $hour,
      'client_hash' => $clientHash,
    ]);

    $pdo->prepare(
      'INSERT INTO daily_visitors (date, client_hash, country, device, page_views)
       VALUES (:date, :client_hash, :country, :device, 1)
       ON CONFLICT(date, client_hash) DO UPDATE SET
          page_views = page_views + 1,
          country = excluded.country,
          device = excluded.device'
    )->execute([
      'date' => $date,
      'client_hash' => $clientHash,
      'country' => $country,
      'device' => $device,
    ]);

    $pdo->prepare(
      'INSERT INTO live_visitors (client_hash, country, lat, lng, last_seen)
       VALUES (:client_hash, :country, :lat, :lng, :last_seen)
       ON CONFLICT(client_hash) DO UPDATE SET
          country = excluded.country,
          lat = excluded.lat,
          lng = excluded.lng,
          last_seen = excluded.last_seen'
    )->execute([
      'client_hash' => $clientHash,
      'country' => $country,
      'lat' => $lat,
      'lng' => $lng,
      'last_seen' => time(),
    ]);

    // Keep the live table compact.
    $pdo->prepare('DELETE FROM live_visitors WHERE last_seen < :cutoff')
      ->execute(['cutoff' => time() - 86400]);
  }

  // Prune aggregated tables beyond the retention window, at most once a day.
  if (analytics_rate_limit_ok('prune', 1, 86400)) {
    analytics_prune_old_data($pdo);
  }

  return true;
}

function analytics_record_event(string $eventName): bool
{
  if (analytics_should_skip_tracking()) {
    return false;
  }

  // Event names are human-friendly labels the customer chooses (e.g.
  // "New Signup"), shown verbatim in the dashboard, so keep the original casing
  // and spaces. Collapse whitespace, drop control characters and anything
  // outside letters/numbers/space/_/-/., and cap the length. The dashboard
  // escapes on output, so this is about tidiness, not the only safety layer.
  $eventName = (string) preg_replace('/\s+/u', ' ', trim($eventName));
  $eventName = (string) preg_replace('/[^\p{L}\p{N} _.\-]/u', '', $eventName);
  $eventName = trim(mb_substr($eventName, 0, 64));
  if ($eventName === '') {
    return false;
  }

  if (!analytics_rate_limit_ok(analytics_request_rate_key('ev:'), 60, 3600)) {
    return false;
  }

  $pdo = analytics_connect();
  $pdo->prepare(
    'INSERT INTO events (date, event_name, count)
     VALUES (:date, :event_name, 1)
     ON CONFLICT(date, event_name) DO UPDATE SET count = count + 1'
  )->execute([
    'date' => analytics_today(),
    'event_name' => $eventName,
  ]);

  return true;
}

/**
 * Tidy a requested path for the not_found table. Unlike the pageview
 * normaliser this tolerates odd paths (that is the point of a 404), but strips
 * the query string, control characters, and caps the length.
 */
function analytics_normalize_not_found_path(string $path): string
{
  $path = trim($path);
  if ($path === '') {
    return '';
  }

  $path = (string) preg_replace('/[?#].*$/', '', $path);
  $path = (string) preg_replace('/[\x00-\x1f\x7f]/', '', $path);
  $path = trim($path);
  if ($path === '') {
    return '';
  }

  if ($path[0] !== '/') {
    $path = '/' . $path;
  }
  if (strlen($path) > 300) {
    $path = substr($path, 0, 300);
  }

  return $path;
}

/**
 * Record a 404 for a requested path. Rate limited per visitor to blunt
 * scanners hammering random URLs.
 */
function analytics_record_not_found(string $path): bool
{
  if (analytics_should_skip_tracking()) {
    return false;
  }

  $path = analytics_normalize_not_found_path($path);
  if ($path === '') {
    return false;
  }
  if (analytics_path_excluded($path)) {
    return false;
  }

  if (!analytics_rate_limit_ok(analytics_request_rate_key('404:'), 60, 3600)) {
    return false;
  }

  $pdo = analytics_connect();
  $pdo->prepare(
    'INSERT INTO not_found (date, path, count)
     VALUES (:date, :path, 1)
     ON CONFLICT(date, path) DO UPDATE SET count = count + 1'
  )->execute([
    'date' => analytics_today(),
    'path' => $path,
  ]);

  return true;
}

/**
 * Most-hit 404 paths for the period.
 *
 * @return list<array{path:string,count:int}>
 */
function analytics_not_found_rows(int $days = 7, int $limit = 15): array
{
  $pdo = analytics_connect();
  $bounds = analytics_period_bounds($days);
  $stmt = $pdo->prepare(
    'SELECT path, COALESCE(SUM(count), 0) AS count
     FROM not_found WHERE date BETWEEN :from AND :to
     GROUP BY path ORDER BY count DESC, path ASC LIMIT :limit'
  );
  $stmt->bindValue('from', $bounds['from']);
  $stmt->bindValue('to', $bounds['to']);
  $stmt->bindValue('limit', $limit, PDO::PARAM_INT);
  $stmt->execute();

  $rows = [];
  foreach ($stmt->fetchAll() as $row) {
    $rows[] = [
      'path' => (string) $row['path'],
      'count' => (int) $row['count'],
    ];
  }
  return $rows;
}

/**
 * Whether any pageviews have ever been recorded. Used to show first-run
 * onboarding until the tracker is installed and sending data.
 */
function analytics_has_any_pageviews(): bool
{
  try {
    $pdo = analytics_connect();
    return (bool) $pdo->query('SELECT 1 FROM page_views LIMIT 1')->fetchColumn();
  } catch (Throwable $e) {
    return false;
  }
}

function analytics_dashboard_summary(int $days = 7): array
{
  $pdo = analytics_connect();
  $bounds = analytics_period_bounds($days);
  $period = analytics_period_params($bounds);

  $viewsStmt = $pdo->prepare(
    "SELECT COALESCE(SUM(views), 0) FROM page_views WHERE date BETWEEN :from AND :to"
  );
  $viewsStmt->execute($period);
  $totalViews = (int) $viewsStmt->fetchColumn();

  $visitorsStmt = $pdo->prepare(
    "SELECT COUNT(DISTINCT client_hash) FROM daily_visitors WHERE date BETWEEN :from AND :to"
  );
  $visitorsStmt->execute($period);
  $uniqueVisitors = (int) $visitorsStmt->fetchColumn();

  // Returning = seen in this period and on at least one other day up to the
  // period end (today: today + an earlier day; 7/30: 2+ days in range or a
  // day before it; all: 2+ days in retained data).
  $returningStmt = $pdo->prepare(
    "SELECT COUNT(DISTINCT dv.client_hash)
     FROM daily_visitors dv
     WHERE dv.date BETWEEN :from AND :to
       AND (
         SELECT COUNT(DISTINCT earlier.date)
         FROM daily_visitors earlier
         WHERE earlier.client_hash = dv.client_hash
           AND earlier.date <= :to
       ) >= 2"
  );
  $returningStmt->execute($period);
  $returningVisitors = (int) $returningStmt->fetchColumn();

  $deviceStmt = $pdo->prepare(
    "SELECT device, COALESCE(SUM(views), 0) AS views
     FROM page_views WHERE date BETWEEN :from AND :to GROUP BY device"
  );
  $deviceStmt->execute($period);
  $devices = ['mobile' => 0, 'desktop' => 0, 'tablet' => 0];
  foreach ($deviceStmt->fetchAll() as $row) {
    $devices[$row['device']] = (int) $row['views'];
  }
  $deviceTotal = max(1, array_sum($devices));

  $topCountryStmt = $pdo->prepare(
    "SELECT country, COUNT(DISTINCT client_hash) AS visitors
     FROM daily_visitors
     WHERE date BETWEEN :from AND :to AND country NOT IN ('local', 'unknown')
     GROUP BY country ORDER BY visitors DESC, country ASC LIMIT 1"
  );
  $topCountryStmt->execute($period);
  $topCountryRow = $topCountryStmt->fetch();
  $topCountry = is_array($topCountryRow)
    ? analytics_country_label((string) $topCountryRow['country'])
    : '—';
  $topCountryVisitors = is_array($topCountryRow) ? (int) $topCountryRow['visitors'] : 0;

  // Performance vs prior window (falls back to a shorter equal-length slice if
  // older history is incomplete).
  $performance = analytics_period_performance($days);

  return [
    'days' => $days,
    'label' => analytics_period_label($days),
    'total_views' => $totalViews,
    'unique_visitors' => $uniqueVisitors,
    'returning_visitors' => $returningVisitors,
    'pages_per_visitor' => $uniqueVisitors > 0 ? round($totalViews / $uniqueVisitors, 1) : 0.0,
    'mobile_percent' => (int) round(($devices['mobile'] / $deviceTotal) * 100),
    'top_country' => $topCountry,
    'top_country_visitors' => $topCountryVisitors,
    'previous_views' => $performance['previous_views'],
    'views_change_percent' => $performance['views_change_percent'],
    'views_change_fallback' => $performance['fallback'],
    'devices' => $devices,
  ];
}

function analytics_daily_series(int $days = 7): array
{
  // A single day can't draw a line chart — use today's hourly series instead.
  if ($days === 1) {
    $hourly = analytics_hourly_series(1);
    return [
      'labels' => $hourly['labels'],
      'views' => $hourly['values'],
      'visitors' => $hourly['visitors'],
      'granularity' => 'hour',
    ];
  }

  $pdo = analytics_connect();
  $bounds = analytics_period_bounds($days);
  $period = analytics_period_params($bounds);

  $viewsStmt = $pdo->prepare(
    "SELECT date, COALESCE(SUM(views), 0) AS views
     FROM page_views WHERE date BETWEEN :from AND :to GROUP BY date"
  );
  $viewsStmt->execute($period);
  $viewsMap = [];
  foreach ($viewsStmt->fetchAll() as $row) {
    $viewsMap[$row['date']] = (int) $row['views'];
  }

  $visitorsStmt = $pdo->prepare(
    "SELECT date, COUNT(DISTINCT client_hash) AS visitors
     FROM daily_visitors WHERE date BETWEEN :from AND :to GROUP BY date"
  );
  $visitorsStmt->execute($period);
  $visitorsMap = [];
  foreach ($visitorsStmt->fetchAll() as $row) {
    $visitorsMap[$row['date']] = (int) $row['visitors'];
  }

  $labels = [];
  $views = [];
  $visitors = [];
  foreach ($bounds['dates'] as $date) {
    $labels[] = i18n_format_date($date, 'chart');
    $views[] = $viewsMap[$date] ?? 0;
    $visitors[] = $visitorsMap[$date] ?? 0;
  }

  return [
    'labels' => $labels,
    'views' => $views,
    'visitors' => $visitors,
    'granularity' => 'day',
  ];
}

/**
 * Pageviews and unique visitors by hour of day (0–23) across the selected
 * period, in the site timezone. Always returns 24 buckets so charts stay stable.
 *
 * @return array{labels: list<string>, values: list<int>, visitors: list<int>}
 */
function analytics_hourly_series(int $days = 7): array
{
  $pdo = analytics_connect();
  $bounds = analytics_period_bounds($days);
  $period = analytics_period_params($bounds);

  $viewsStmt = $pdo->prepare(
    "SELECT hour, COALESCE(SUM(views), 0) AS views
     FROM hourly_views
     WHERE date BETWEEN :from AND :to
     GROUP BY hour"
  );
  $viewsStmt->execute($period);
  $viewsByHour = [];
  foreach ($viewsStmt->fetchAll() as $row) {
    $h = (int) $row['hour'];
    if ($h >= 0 && $h <= 23) {
      $viewsByHour[$h] = (int) $row['views'];
    }
  }

  $visitorsStmt = $pdo->prepare(
    "SELECT hour, COUNT(DISTINCT client_hash) AS visitors
     FROM hourly_visitors
     WHERE date BETWEEN :from AND :to
     GROUP BY hour"
  );
  $visitorsStmt->execute($period);
  $visitorsByHour = [];
  foreach ($visitorsStmt->fetchAll() as $row) {
    $h = (int) $row['hour'];
    if ($h >= 0 && $h <= 23) {
      $visitorsByHour[$h] = (int) $row['visitors'];
    }
  }

  $labels = [];
  $values = [];
  $visitors = [];
  for ($h = 0; $h < 24; $h++) {
    $labels[] = i18n_format_hour($h);
    $values[] = $viewsByHour[$h] ?? 0;
    $visitors[] = $visitorsByHour[$h] ?? 0;
  }

  return ['labels' => $labels, 'values' => $values, 'visitors' => $visitors];
}

/**
 * Browser family pageviews for the selected period as Chart.js data.
 * Top $limit families by views (same pattern as visitors-by-country).
 *
 * @return array{labels: list<string>, values: list<int>}
 */
function analytics_browsers_chart(int $days = 7, int $limit = 10): array
{
  $pdo = analytics_connect();
  $bounds = analytics_period_bounds($days);
  $stmt = $pdo->prepare(
    "SELECT browser, COALESCE(SUM(views), 0) AS views
     FROM browser_views
     WHERE date BETWEEN :from AND :to AND browser NOT IN ('Unknown', 'Other')
     GROUP BY browser
     ORDER BY views DESC, browser ASC
     LIMIT :limit"
  );
  $stmt->bindValue('from', $bounds['from']);
  $stmt->bindValue('to', $bounds['to']);
  $stmt->bindValue('limit', max(1, $limit), PDO::PARAM_INT);
  $stmt->execute();

  $labels = [];
  $values = [];
  foreach ($stmt->fetchAll() as $row) {
    $views = (int) $row['views'];
    if ($views <= 0) {
      continue;
    }
    $labels[] = (string) $row['browser'];
    $values[] = $views;
  }

  return ['labels' => $labels, 'values' => $values];
}

function analytics_top_pages(int $days = 7, int $limit = 10): array
{
  $pdo = analytics_connect();
  $stmt = $pdo->prepare(
    "SELECT path, COALESCE(SUM(views), 0) AS views
     FROM page_views WHERE date BETWEEN :from AND :to
     GROUP BY path ORDER BY views DESC, path ASC LIMIT :limit"
  );
  $bounds = analytics_period_bounds($days);
  $stmt->bindValue('from', $bounds['from']);
  $stmt->bindValue('to', $bounds['to']);
  $stmt->bindValue('limit', $limit, PDO::PARAM_INT);
  $stmt->execute();
  return $stmt->fetchAll();
}

function analytics_top_referrers(int $days = 7, int $limit = 8): array
{
  $pdo = analytics_connect();
  $stmt = $pdo->prepare(
    "SELECT referrer, COALESCE(SUM(views), 0) AS views
     FROM page_views WHERE date BETWEEN :from AND :to
     GROUP BY referrer ORDER BY views DESC, referrer ASC LIMIT :limit"
  );
  $bounds = analytics_period_bounds($days);
  $stmt->bindValue('from', $bounds['from']);
  $stmt->bindValue('to', $bounds['to']);
  $stmt->bindValue('limit', $limit, PDO::PARAM_INT);
  $stmt->execute();
  return $stmt->fetchAll();
}

/** Daily page views as {labels, values} for Chart.js. */
function analytics_daily_views(int $days = 7): array
{
  $series = analytics_daily_series($days);
  return ['labels' => $series['labels'], 'values' => $series['views']];
}

/** Daily unique visitors as {labels, values} for Chart.js. */
function analytics_daily_unique_visitors(int $days = 7): array
{
  $series = analytics_daily_series($days);
  return ['labels' => $series['labels'], 'values' => $series['visitors']];
}

function analytics_visitors_by_country(int $days = 7, int $limit = 10): array
{
  $pdo = analytics_connect();
  $bounds = analytics_period_bounds($days);
  $stmt = $pdo->prepare(
    "SELECT country, COUNT(DISTINCT client_hash) AS visitors
     FROM daily_visitors
     WHERE date BETWEEN :from AND :to AND country NOT IN ('local', 'unknown')
     GROUP BY country ORDER BY visitors DESC, country ASC LIMIT :limit"
  );
  $stmt->bindValue('from', $bounds['from']);
  $stmt->bindValue('to', $bounds['to']);
  $stmt->bindValue('limit', $limit, PDO::PARAM_INT);
  $stmt->execute();

  $labels = [];
  $values = [];
  foreach ($stmt->fetchAll() as $row) {
    $labels[] = analytics_country_label((string) $row['country']);
    $values[] = (int) $row['visitors'];
  }
  return ['labels' => $labels, 'values' => $values];
}

function analytics_views_by_country(int $days = 7, int $limit = 10): array
{
  $pdo = analytics_connect();
  $bounds = analytics_period_bounds($days);
  $stmt = $pdo->prepare(
    "SELECT country, COALESCE(SUM(views), 0) AS views
     FROM page_views
     WHERE date BETWEEN :from AND :to AND country NOT IN ('local', 'unknown')
     GROUP BY country ORDER BY views DESC, country ASC LIMIT :limit"
  );
  $stmt->bindValue('from', $bounds['from']);
  $stmt->bindValue('to', $bounds['to']);
  $stmt->bindValue('limit', $limit, PDO::PARAM_INT);
  $stmt->execute();

  $labels = [];
  $values = [];
  foreach ($stmt->fetchAll() as $row) {
    $labels[] = analytics_country_label((string) $row['country']);
    $values[] = (int) $row['views'];
  }
  return ['labels' => $labels, 'values' => $values];
}

/** Top pages as {labels, values} for Chart.js. */
function analytics_top_pages_chart(int $days = 7, int $limit = 10): array
{
  $labels = [];
  $values = [];
  foreach (analytics_top_pages($days, $limit) as $row) {
    $labels[] = (string) $row['path'];
    $values[] = (int) $row['views'];
  }
  return ['labels' => $labels, 'values' => $values];
}

/** Top referrers (excluding direct) as {labels, values} for Chart.js. */
function analytics_top_referrers_chart(int $days = 7, int $limit = 8): array
{
  $pdo = analytics_connect();
  $bounds = analytics_period_bounds($days);
  $stmt = $pdo->prepare(
    "SELECT referrer, COALESCE(SUM(views), 0) AS views
     FROM page_views
     WHERE date BETWEEN :from AND :to AND referrer != 'direct'
     GROUP BY referrer ORDER BY views DESC, referrer ASC LIMIT :limit"
  );
  $stmt->bindValue('from', $bounds['from']);
  $stmt->bindValue('to', $bounds['to']);
  $stmt->bindValue('limit', $limit, PDO::PARAM_INT);
  $stmt->execute();

  $labels = [];
  $values = [];
  foreach ($stmt->fetchAll() as $row) {
    $labels[] = (string) $row['referrer'];
    $values[] = (int) $row['views'];
  }
  return ['labels' => $labels, 'values' => $values];
}

/** Product page interest as {labels, values} for Chart.js. */
function analytics_top_product_pages_chart(int $days = 7, int $limit = 10): array
{
  $pdo = analytics_connect();
  $bounds = analytics_period_bounds($days);
  $stmt = $pdo->prepare(
    "SELECT path, COALESCE(SUM(views), 0) AS views
     FROM page_views
     WHERE date BETWEEN :from AND :to AND path LIKE '/Products/%'
     GROUP BY path ORDER BY views DESC, path ASC LIMIT :limit"
  );
  $stmt->bindValue('from', $bounds['from']);
  $stmt->bindValue('to', $bounds['to']);
  $stmt->bindValue('limit', $limit, PDO::PARAM_INT);
  $stmt->execute();

  $labels = [];
  $values = [];
  foreach ($stmt->fetchAll() as $row) {
    $labels[] = analytics_product_page_label((string) $row['path']);
    $values[] = (int) $row['views'];
  }
  return ['labels' => $labels, 'values' => $values];
}

function analytics_product_page_label(string $path): string
{
  $slug = trim($path, '/');
  $slug = (string) (array_slice(explode('/', $slug), -1)[0] ?? $slug);
  if ($slug === '' || $slug === 'Products') {
    return $path;
  }
  return ucwords(str_replace('-', ' ', $slug));
}

function analytics_event_label(string $eventName): string
{
  return ucwords(str_replace(['_', '-'], ' ', $eventName));
}

/**
 * All recorded events for the period, friendly-labelled and sorted by count.
 *
 * @return list<array{name:string,label:string,count:int}>
 */
function analytics_event_rows(int $days = 7): array
{
  $pdo = analytics_connect();
  $bounds = analytics_period_bounds($days);
  $stmt = $pdo->prepare(
    'SELECT event_name, COALESCE(SUM(count), 0) AS count
     FROM events WHERE date BETWEEN :from AND :to
     GROUP BY event_name ORDER BY count DESC, event_name ASC'
  );
  $stmt->execute(analytics_period_params($bounds));

  $rows = [];
  foreach ($stmt->fetchAll() as $row) {
    $rows[] = [
      'name' => (string) $row['event_name'],
      'label' => analytics_event_label((string) $row['event_name']),
      'count' => (int) $row['count'],
    ];
  }
  return $rows;
}

/**
 * Active visitors grouped by country for the live map.
 * Positions use the canonical country centroid (not averaged stored coords),
 * so seed jitter / per-visitor noise cannot drift dots off the map.
 *
 * @return list<array{country_code:string,country_label:string,visitors:int,lat:float,lng:float}>
 */
function analytics_active_visitors_map(int $windowSeconds = 300): array
{
  $windowSeconds = max(60, min($windowSeconds, 3600));
  $pdo = analytics_connect();
  $cutoff = time() - $windowSeconds;

  $stmt = $pdo->prepare(
    'SELECT country, COUNT(*) AS visitors
     FROM live_visitors
     WHERE last_seen >= :cutoff AND lat IS NOT NULL AND lng IS NOT NULL
     GROUP BY country ORDER BY visitors DESC, country ASC'
  );
  $stmt->execute(['cutoff' => $cutoff]);

  $rows = [];
  foreach ($stmt->fetchAll() as $row) {
    $code = strtoupper((string) ($row['country'] ?? ''));
    $centroid = analytics_country_centroid($code);
    if ($centroid === null) {
      continue;
    }
    $rows[] = [
      'country_code' => $code,
      'country_label' => analytics_country_label($code),
      'visitors' => (int) $row['visitors'],
      'lat' => $centroid['lat'],
      'lng' => $centroid['lng'],
    ];
  }
  return $rows;
}

/**
 * @return array{total:int,mapped:int,unknown_or_unmapped:int}
 */
function analytics_active_visitors_summary(int $windowSeconds = 300): array
{
  $windowSeconds = max(60, min($windowSeconds, 3600));
  $pdo = analytics_connect();
  $cutoff = time() - $windowSeconds;

  $totalStmt = $pdo->prepare('SELECT COUNT(*) FROM live_visitors WHERE last_seen >= :cutoff');
  $totalStmt->execute(['cutoff' => $cutoff]);
  $total = (int) $totalStmt->fetchColumn();

  $mapped = 0;
  foreach (analytics_active_visitors_map($windowSeconds) as $row) {
    $mapped += (int) ($row['visitors'] ?? 0);
  }

  return [
    'total' => $total,
    'mapped' => $mapped,
    'unknown_or_unmapped' => max(0, $total - $mapped),
  ];
}

function analytics_escape(string $value): string
{
  return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
