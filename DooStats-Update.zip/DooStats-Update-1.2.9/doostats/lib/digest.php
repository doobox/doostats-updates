<?php

declare(strict_types=1);

/**
 * Opt-in weekly email digest. Triggered lazily after collect.php returns 204 —
 * no cron. Settings: digest_enabled + digest_email (+ optional SMTP) in config.php.
 * Runtime status: data/digest-state.json.
 */

require_once __DIR__ . '/analytics.php';
require_once __DIR__ . '/i18n.php';
require_once __DIR__ . '/install-path.php';
require_once __DIR__ . '/smtp.php';
require_once __DIR__ . '/ui-theme.php';

const DOOSTATS_DIGEST_INTERVAL_SECONDS = 604800; // 7 days

function doostats_digest_data_dir(): string
{
    $cfg = analytics_config();
    return rtrim((string) ($cfg['data_dir'] ?? dirname(__DIR__) . '/data'), '/\\');
}

function doostats_digest_state_path(): string
{
    return doostats_digest_data_dir() . '/digest-state.json';
}

/**
 * @return array{last_sent_at: string, last_attempt_at: string, last_ok: bool, last_error: string, last_to: string}
 */
function doostats_digest_state(): array
{
    $empty = [
        'last_sent_at' => '',
        'last_attempt_at' => '',
        'last_ok' => false,
        'last_error' => '',
        'last_to' => '',
    ];
    $path = doostats_digest_state_path();
    if (!is_file($path)) {
        return $empty;
    }
    $raw = @file_get_contents($path);
    $data = is_string($raw) ? json_decode($raw, true) : null;
    if (!is_array($data)) {
        return $empty;
    }
    $attempt = trim((string) ($data['last_attempt_at'] ?? ''));
    if ($attempt === '') {
        $attempt = trim((string) ($data['last_sent_at'] ?? ''));
    }
    return [
        'last_sent_at' => trim((string) ($data['last_sent_at'] ?? '')),
        'last_attempt_at' => $attempt,
        'last_ok' => !empty($data['last_ok']),
        'last_error' => trim((string) ($data['last_error'] ?? '')),
        'last_to' => trim((string) ($data['last_to'] ?? '')),
    ];
}

/**
 * @param array{last_sent_at?: string, last_attempt_at?: string, last_ok?: bool, last_error?: string, last_to?: string} $state
 */
function doostats_digest_write_state(array $state): bool
{
    $dir = doostats_digest_data_dir();
    if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
        return false;
    }
    $current = doostats_digest_state();
    $merged = array_merge($current, $state);
    $json = json_encode([
        'last_sent_at' => (string) ($merged['last_sent_at'] ?? ''),
        'last_attempt_at' => (string) ($merged['last_attempt_at'] ?? ''),
        'last_ok' => !empty($merged['last_ok']),
        'last_error' => (string) ($merged['last_error'] ?? ''),
        'last_to' => (string) ($merged['last_to'] ?? ''),
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n";

    $path = doostats_digest_state_path();
    $tmp = $path . '.' . bin2hex(random_bytes(4)) . '.tmp';
    if (@file_put_contents($tmp, $json, LOCK_EX) === false) {
        @unlink($tmp);
        return false;
    }
    if (!@rename($tmp, $path)) {
        @unlink($tmp);
        return false;
    }
    @chmod($path, 0644);
    return true;
}

function doostats_digest_enabled(): bool
{
    return !empty(analytics_config()['digest_enabled']);
}

function doostats_digest_email(): string
{
    return trim((string) (analytics_config()['digest_email'] ?? ''));
}

function doostats_digest_email_valid(?string $email = null): bool
{
    $email = $email ?? doostats_digest_email();
    return $email !== '' && (bool) filter_var($email, FILTER_VALIDATE_EMAIL);
}

function doostats_digest_dashboard_url(): string
{
    $cfg = analytics_config();
    $site = rtrim((string) ($cfg['site_url'] ?? ''), '/');
    if ($site === '') {
        $site = rtrim(doostats_detect_site_url(), '/');
    }
    return $site . doostats_install_path() . '/dashboard/';
}

/** @return 'php'|'smtp' */
function doostats_mail_transport(?array $cfg = null): string
{
    $cfg = $cfg ?? analytics_config();
    $transport = strtolower(trim((string) ($cfg['mail_transport'] ?? 'php')));
    return $transport === 'smtp' ? 'smtp' : 'php';
}

/**
 * Validate SMTP settings when transport is smtp.
 *
 * @param array<string, mixed> $cfg
 * @return list<string>
 */
function doostats_mail_smtp_errors(array $cfg): array
{
    if (doostats_mail_transport($cfg) !== 'smtp') {
        return [];
    }
    $errors = [];
    $host = trim((string) ($cfg['smtp_host'] ?? ''));
    $port = (int) ($cfg['smtp_port'] ?? 0);
    $enc = strtolower(trim((string) ($cfg['smtp_encryption'] ?? 'tls')));
    $user = trim((string) ($cfg['smtp_username'] ?? ''));
    $pass = (string) ($cfg['smtp_password'] ?? '');
    $from = trim((string) ($cfg['smtp_from'] ?? ''));

    if ($host === '') {
        $errors[] = t('settings.reports.error.smtp_host');
    }
    if ($port < 1 || $port > 65535) {
        $errors[] = t('settings.reports.error.smtp_port');
    }
    if (!in_array($enc, ['tls', 'ssl', 'none'], true)) {
        $errors[] = t('settings.reports.error.smtp_encryption');
    }
    if ($user === '') {
        $errors[] = t('settings.reports.error.smtp_auth');
    }
    if ($pass === '') {
        $errors[] = t('settings.reports.error.smtp_password');
    }
    if ($from === '' || !filter_var($from, FILTER_VALIDATE_EMAIL)) {
        $errors[] = t('settings.reports.error.smtp_from');
    }
    return $errors;
}

/**
 * Merge mail/SMTP fields from a reports POST into $cfg.
 * Blank smtp_password keeps the previous value.
 *
 * @param array<string, mixed> $cfg
 * @param array<string, mixed> $post
 * @return array<string, mixed>
 */
function doostats_mail_apply_post(array $cfg, array $post): array
{
    $transport = strtolower(trim((string) ($post['mail_transport'] ?? 'php')));
    $cfg['mail_transport'] = $transport === 'smtp' ? 'smtp' : 'php';

    $enc = strtolower(trim((string) ($post['smtp_encryption'] ?? 'tls')));
    if (!in_array($enc, ['tls', 'ssl', 'none'], true)) {
        $enc = 'tls';
    }
    $port = (int) ($post['smtp_port'] ?? 587);
    if ($port < 1 || $port > 65535) {
        $port = 587;
    }

    $cfg['smtp_host'] = trim((string) ($post['smtp_host'] ?? ''));
    $cfg['smtp_port'] = $port;
    $cfg['smtp_encryption'] = $enc;
    $cfg['smtp_username'] = trim((string) ($post['smtp_username'] ?? ''));
    $cfg['smtp_from'] = trim((string) ($post['smtp_from'] ?? ''));

    $postedPass = (string) ($post['smtp_password'] ?? '');
    if ($postedPass !== '') {
        $cfg['smtp_password'] = $postedPass;
    } elseif (!isset($cfg['smtp_password'])) {
        $cfg['smtp_password'] = '';
    }

    return $cfg;
}

function doostats_digest_from_address(?array $cfg = null): string
{
    $cfg = $cfg ?? analytics_config();
    if (doostats_mail_transport($cfg) === 'smtp') {
        $from = trim((string) ($cfg['smtp_from'] ?? ''));
        if ($from !== '' && filter_var($from, FILTER_VALIDATE_EMAIL)) {
            return $from;
        }
    }
    $host = '';
    $siteUrl = trim((string) ($cfg['site_url'] ?? ''));
    if ($siteUrl !== '') {
        $host = (string) (parse_url($siteUrl, PHP_URL_HOST) ?: '');
    }
    if ($host === '') {
        $host = trim((string) ($_SERVER['HTTP_HOST'] ?? ''));
    }
    if ($host === '') {
        $host = trim((string) ($_SERVER['SERVER_NAME'] ?? ''));
    }
    $host = preg_replace('/:\d+$/', '', $host) ?: 'localhost';
    // Strip brackets from IPv6 literals for a safer From header.
    $host = trim($host, '[]');
    return 'doostats@' . $host;
}

function doostats_digest_is_due(array $state): bool
{
    $sent = trim((string) ($state['last_sent_at'] ?? ''));
    if ($sent === '') {
        return true;
    }
    try {
        $dt = new DateTimeImmutable($sent);
    } catch (Exception $e) {
        return true;
    }
    return (time() - $dt->getTimestamp()) >= DOOSTATS_DIGEST_INTERVAL_SECONDS;
}

/**
 * Non-blocking exclusive lock. Returns a file handle to keep until unlock, or null.
 *
 * @return resource|null
 */
function doostats_digest_acquire_lock()
{
    $dir = doostats_digest_data_dir();
    if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
        return null;
    }
    $path = $dir . '/digest.lock';
    $fh = @fopen($path, 'c+');
    if ($fh === false) {
        return null;
    }
    if (!flock($fh, LOCK_EX | LOCK_NB)) {
        fclose($fh);
        return null;
    }
    return $fh;
}

/**
 * @param resource $fh
 */
function doostats_digest_release_lock($fh): void
{
    flock($fh, LOCK_UN);
    fclose($fh);
}

/**
 * Lazy weekly send after a beacon. Safe to call on every collect.php request.
 * Never throws.
 */
function doostats_digest_maybe_send(): void
{
    try {
        if (!doostats_digest_enabled() || !doostats_digest_email_valid()) {
            return;
        }
        $state = doostats_digest_state();
        if (!doostats_digest_is_due($state)) {
            return;
        }
        $lock = doostats_digest_acquire_lock();
        if ($lock === null) {
            return;
        }
        try {
            // Re-check under lock (another beacon may have just sent).
            $state = doostats_digest_state();
            if (!doostats_digest_is_due($state)) {
                return;
            }
            doostats_digest_send(doostats_digest_email(), false);
        } finally {
            doostats_digest_release_lock($lock);
        }
    } catch (Throwable $e) {
        // Never break tracking.
    }
}

/**
 * Manual / test send from Settings. Updates status.
 *
 * @return array{ok: bool, message: string}
 */
function doostats_digest_send_now(bool $isTest = true): array
{
    if (!doostats_digest_email_valid()) {
        return ['ok' => false, 'message' => t('settings.reports.error.email')];
    }
    if (!doostats_digest_enabled() && !$isTest) {
        return ['ok' => false, 'message' => t('settings.reports.error.disabled')];
    }
    $smtpErrors = doostats_mail_smtp_errors(analytics_config());
    if ($smtpErrors !== []) {
        return ['ok' => false, 'message' => $smtpErrors[0]];
    }

    $lock = doostats_digest_acquire_lock();
    if ($lock === null) {
        return ['ok' => false, 'message' => t('settings.reports.error.busy')];
    }

    try {
        if ($isTest) {
            $state = doostats_digest_state();
            $result = doostats_digest_send(doostats_digest_email(), true);
            // A first test establishes the weekly schedule. Without this, the
            // next pageview sees "never sent" and immediately sends a second,
            // non-test copy.
            if ($result['ok'] && trim((string) ($state['last_sent_at'] ?? '')) === '') {
                doostats_digest_write_state(['last_sent_at' => gmdate('Y-m-d\TH:i:s\Z')]);
            }
            return $result;
        }

        return doostats_digest_send(doostats_digest_email(), false);
    } finally {
        doostats_digest_release_lock($lock);
    }
}

/**
 * Build and send one digest email. Writes last_sent status (weekly and test).
 *
 * @return array{ok: bool, message: string}
 */
function doostats_digest_send(string $to, bool $isTest): array
{
    try {
        $payload = doostats_digest_build_message($isTest);
    } catch (Throwable $e) {
        $now = gmdate('Y-m-d\TH:i:s\Z');
        $stateUpdate = [
            'last_attempt_at' => $now,
            'last_ok' => false,
            'last_error' => t('settings.reports.error.build'),
            'last_to' => $to,
        ];
        if (!$isTest) {
            $stateUpdate['last_sent_at'] = $now;
        }
        doostats_digest_write_state($stateUpdate);
        return ['ok' => false, 'message' => t('settings.reports.error.build')];
    }

    $cfg = analytics_config();
    $boundary = 'digest-' . bin2hex(random_bytes(12));
    $from = doostats_digest_from_address($cfg);
    $host = substr(strrchr($from, '@') ?: '@localhost', 1);
    $fromName = trim((string) ($cfg['site_name'] ?? ''));
    if ($fromName === '') {
        $fromName = t('nav.brand_fallback');
    }
    $fromName = str_replace(["\r", "\n"], '', $fromName);
    if (function_exists('mb_encode_mimeheader')) {
        $fromHeaderName = mb_encode_mimeheader($fromName, 'UTF-8', 'B', "\r\n");
    } else {
        $fromHeaderName = $fromName;
    }
    $subject = str_replace(["\r", "\n"], '', $payload['subject']);
    if (function_exists('mb_encode_mimeheader')) {
        $subject = mb_encode_mimeheader($subject, 'UTF-8', 'B', "\r\n");
    }
    $headers = [
        'Date: ' . date(DATE_RFC2822),
        'Message-ID: <' . bin2hex(random_bytes(12)) . '@' . $host . '>',
        'MIME-Version: 1.0',
        'Content-Type: multipart/alternative; boundary="' . $boundary . '"',
        'From: ' . $fromHeaderName . ' <' . $from . '>',
        'Auto-Submitted: auto-generated',
    ];
    $body = '--' . $boundary . "\r\n"
        . "Content-Type: text/plain; charset=UTF-8\r\n"
        . "Content-Transfer-Encoding: base64\r\n\r\n"
        . chunk_split(base64_encode($payload['text']))
        . '--' . $boundary . "\r\n"
        . "Content-Type: text/html; charset=UTF-8\r\n"
        . "Content-Transfer-Encoding: base64\r\n\r\n"
        . chunk_split(base64_encode($payload['html']))
        . '--' . $boundary . "--\r\n";

    $ok = false;
    $error = '';
    if (doostats_mail_transport($cfg) === 'smtp') {
        $smtp = doostats_smtp_send(
            (string) ($cfg['smtp_host'] ?? ''),
            (int) ($cfg['smtp_port'] ?? 587),
            (string) ($cfg['smtp_encryption'] ?? 'tls'),
            (string) ($cfg['smtp_username'] ?? ''),
            (string) ($cfg['smtp_password'] ?? ''),
            $from,
            $to,
            $subject,
            implode("\r\n", $headers),
            $body
        );
        $ok = $smtp['ok'];
        $error = $ok ? '' : $smtp['message'];
    } else {
        $ok = @mail(
            $to,
            $subject,
            $body,
            implode("\r\n", $headers)
        );
        $error = $ok ? '' : t('settings.reports.error.mail');
    }

    $now = gmdate('Y-m-d\TH:i:s\Z');
    $stateUpdate = [
        'last_attempt_at' => $now,
        'last_ok' => $ok,
        'last_error' => $error,
        'last_to' => $to,
    ];
    // Weekly sends advance the due clock. A first successful test establishes
    // the initial schedule in doostats_digest_send_now().
    if (!$isTest) {
        $stateUpdate['last_sent_at'] = $now;
    }
    doostats_digest_write_state($stateUpdate);

    if ($ok) {
        return [
            'ok' => true,
            'message' => $isTest
                ? t('settings.reports.notice.test_sent')
                : t('settings.reports.notice.sent'),
        ];
    }
    return ['ok' => false, 'message' => $error];
}

/**
 * @return array{subject: string, html: string, text: string}
 */
function doostats_digest_build_message(bool $isTest): array
{
    $cfg = analytics_config();
    $siteName = trim((string) ($cfg['site_name'] ?? ''));
    if ($siteName === '') {
        $siteName = t('nav.brand_fallback');
    }
    $brand = (string) ($cfg['brand_hex'] ?? '#3b82f6');
    if (!preg_match('/^#[0-9a-fA-F]{6}$/', $brand)) {
        $brand = '#3b82f6';
    }

    $summary = analytics_dashboard_summary(7);
    $pages = analytics_top_pages(7, 5);
    $referrers = analytics_top_referrers(7, 5);
    $notFound = analytics_not_found_rows(7, 5);
    $dashboardUrl = doostats_digest_dashboard_url();
    $trackVisitors = analytics_process_visitor_ip();

    $visitors = (int) ($summary['unique_visitors'] ?? 0);
    $views = (int) ($summary['total_views'] ?? 0);
    $returning = (int) ($summary['returning_visitors'] ?? 0);
    $ppv = (float) ($summary['pages_per_visitor'] ?? 0);
    $change = $summary['views_change_percent'] ?? null;
    if (!$trackVisitors) {
        $visitors = 0;
        $returning = 0;
        $ppv = 0.0;
    }

    if ($trackVisitors) {
        $subject = t('digest.email.subject', [
            'site' => $siteName,
            'visitors' => i18n_format_number($visitors),
        ]);
    } else {
        $subject = t('digest.email.subject_views', [
            'site' => $siteName,
            'views' => i18n_format_number($views),
        ]);
    }
    if (is_int($change)) {
        $subject .= ' (' . ($change >= 0 ? '+' : '') . i18n_format_percent($change) . ')';
    }
    if ($isTest) {
        $subject = t('digest.email.subject_test_prefix') . ' ' . $subject;
    }

    $esc = static fn (string $s): string => htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
    $theme = doostats_ui_theme($cfg);
    $forceDark = $theme === 'dark';
    $forceLight = $theme === 'light';
    $colorSchemeMeta = $forceDark ? 'dark' : ($forceLight ? 'light' : 'light dark');
    $colorSchemeCss = $forceDark ? 'dark' : ($forceLight ? 'light' : 'light dark');

    // Palette: light defaults; dark either forced as base or via prefers-color-scheme.
    $pageBg = $forceDark ? '#12151a' : '#f4f6fa';
    $ink = $forceDark ? '#e8eaed' : '#1a1f2c';
    $muted = $forceDark ? '#9aa3b2' : '#5c6575';
    $cardBg = $forceDark ? '#1a1f27' : '#ffffff';
    $line = $forceDark ? '#2c3340' : '#e4e7ee';
    $up = $forceDark ? '#4ade80' : '#15803d';
    $down = $forceDark ? '#f87171' : '#b91c1c';

    $changeHtml = '';
    if (is_int($change)) {
        $label = ($change >= 0 ? '+' : '') . i18n_format_percent($change);
        $changeHtml = ' <span class="ds-delta' . ($change >= 0 ? '-up' : '-down') . '" style="color:' . ($change >= 0 ? $up : $down) . '">('
            . $esc($label) . ' ' . $esc(t('digest.email.vs_previous')) . ')</span>';
    }

    $rows = static function (array $items, string $keyLabel, string $keyCount) use ($esc, $muted, $line, $ink): string {
        if ($items === []) {
            return '<tr><td colspan="2" class="ds-muted" style="padding:0.55rem 0;color:' . $muted . ';">'
                . $esc(t('digest.email.empty')) . '</td></tr>';
        }
        $html = '';
        $last = count($items) - 1;
        foreach ($items as $i => $row) {
            $label = (string) ($row[$keyLabel] ?? '');
            if ($label === 'direct') {
                $label = t('digest.email.direct');
            }
            $count = (int) ($row[$keyCount] ?? $row['views'] ?? $row['count'] ?? 0);
            $border = $i === $last ? 'none' : '1px solid ' . $line;
            $html .= '<tr>'
                . '<td class="ds-rule ds-ink" style="padding:0.55rem 0.75rem 0.55rem 0;border-bottom:' . $border . ';color:' . $ink . ';">'
                . $esc($label) . '</td>'
                . '<td class="ds-rule ds-ink" style="padding:0.55rem 0;border-bottom:' . $border . ';text-align:right;'
                . 'font-variant-numeric:tabular-nums;font-weight:600;white-space:nowrap;color:' . $ink . ';">'
                . $esc(i18n_format_number($count)) . '</td>'
                . '</tr>';
        }
        return $html;
    };

    if ($trackVisitors) {
        $heroLabel = t('digest.email.visitors');
        $heroValue = i18n_format_number($visitors);
        $subMetricsHtml = '<tr>'
            . '<td style="padding:0.45rem 0.75rem 0 0;vertical-align:top;width:33%;">'
            . '<div class="ds-muted" style="font-size:12px;letter-spacing:0.02em;text-transform:uppercase;color:' . $muted . ';">'
            . $esc(t('digest.email.pageviews')) . '</div>'
            . '<div class="ds-ink" style="margin-top:0.2rem;font-size:1.05rem;font-weight:600;color:' . $ink . ';">' . $esc(i18n_format_number($views)) . '</div></td>'
            . '<td style="padding:0.45rem 0.75rem 0;vertical-align:top;width:33%;">'
            . '<div class="ds-muted" style="font-size:12px;letter-spacing:0.02em;text-transform:uppercase;color:' . $muted . ';">'
            . $esc(t('digest.email.returning')) . '</div>'
            . '<div class="ds-ink" style="margin-top:0.2rem;font-size:1.05rem;font-weight:600;color:' . $ink . ';">' . $esc(i18n_format_number($returning)) . '</div></td>'
            . '<td style="padding:0.45rem 0 0;vertical-align:top;width:33%;">'
            . '<div class="ds-muted" style="font-size:12px;letter-spacing:0.02em;text-transform:uppercase;color:' . $muted . ';">'
            . $esc(t('digest.email.pages_per_visitor')) . '</div>'
            . '<div class="ds-ink" style="margin-top:0.2rem;font-size:1.05rem;font-weight:600;color:' . $ink . ';">' . $esc(i18n_format_number($ppv, 1)) . '</div></td>'
            . '</tr>';
        $textMetrics = t('digest.email.visitors') . ': ' . i18n_format_number($visitors) . "\n"
            . t('digest.email.pageviews') . ': ' . i18n_format_number($views) . "\n"
            . t('digest.email.returning') . ': ' . i18n_format_number($returning) . "\n"
            . t('digest.email.pages_per_visitor') . ': ' . i18n_format_number($ppv, 1) . "\n\n";
    } else {
        $heroLabel = t('digest.email.pageviews');
        $heroValue = i18n_format_number($views);
        $subMetricsHtml = '';
        $textMetrics = t('digest.email.pageviews') . ': ' . i18n_format_number($views) . "\n\n";
    }

    $darkMediaCss = '';
    if (!$forceLight) {
        // System follows OS; forced dark also lists these so clients that only
        // honour prefers-color-scheme still match the admin’s dark preference.
        $darkMediaCss = '@media (prefers-color-scheme: dark) {'
            . '.ds-body{background:#12151a!important;color:#e8eaed!important;}'
            . '.ds-card{background:#1a1f27!important;border-color:#2c3340!important;}'
            . '.ds-ink{color:#e8eaed!important;}'
            . '.ds-muted{color:#9aa3b2!important;}'
            . '.ds-rule{border-color:#2c3340!important;}'
            . '.ds-delta-up{color:#4ade80!important;}'
            . '.ds-delta-down{color:#f87171!important;}'
            . '}';
    }
    if ($forceDark) {
        // Prefer dark when the admin chose dark (Apple Mail / macOS).
        $darkMediaCss = 'html,body,.ds-body{background:#12151a!important;color:#e8eaed!important;}'
            . '.ds-card{background:#1a1f27!important;border-color:#2c3340!important;}'
            . '.ds-ink{color:#e8eaed!important;}'
            . '.ds-muted{color:#9aa3b2!important;}'
            . '.ds-rule{border-color:#2c3340!important;}'
            . $darkMediaCss;
    }

    $section = static function (string $title, string $bodyHtml) use ($esc, $cardBg, $line, $ink): string {
        return '<table role="presentation" class="ds-card" width="100%" cellpadding="0" cellspacing="0" border="0" '
            . 'style="width:100%;border-collapse:separate;background:' . $cardBg . ';border:1px solid ' . $line
            . ';border-radius:12px;margin:0 0 14px;">'
            . '<tr><td style="padding:16px 18px;">'
            . '<div class="ds-ink" style="margin:0 0 10px;font-size:13px;font-weight:700;letter-spacing:0.04em;'
            . 'text-transform:uppercase;color:' . $ink . ';">' . $esc($title) . '</div>'
            . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" '
            . 'style="width:100%;border-collapse:collapse;">' . $bodyHtml . '</table>'
            . '</td></tr></table>';
    };

    $html = '<!DOCTYPE html>'
        . '<html lang="' . $esc(i18n_html_lang()) . '" xmlns="http://www.w3.org/1999/xhtml">'
        . '<head>'
        . '<meta charset="utf-8" />'
        . '<meta name="viewport" content="width=device-width, initial-scale=1" />'
        . '<meta name="color-scheme" content="' . $esc($colorSchemeMeta) . '" />'
        . '<meta name="supported-color-schemes" content="' . $esc($colorSchemeMeta) . '" />'
        . '<title>' . $esc(t('digest.email.heading')) . '</title>'
        . '<style type="text/css">'
        . ':root{color-scheme:' . $colorSchemeCss . ';}'
        . $darkMediaCss
        . '</style>'
        . '</head>'
        . '<body class="ds-body" style="margin:0;padding:0;background:' . $pageBg . ';color:' . $ink . ';'
        . 'font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,Helvetica,Arial,sans-serif;'
        . 'font-size:16px;line-height:1.5;-webkit-text-size-adjust:100%;">'
        . '<div style="display:none;max-height:0;overflow:hidden;opacity:0;mso-hide:all;">'
        . $esc($heroLabel) . ': ' . $esc($heroValue)
        . (is_int($change) ? ' (' . ($change >= 0 ? '+' : '') . i18n_format_percent($change) . ')' : '')
        . '</div>'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" class="ds-body" '
        . 'style="width:100%;border-collapse:collapse;background:' . $pageBg . ';">'
        . '<tr><td align="center" style="padding:28px 16px 36px;">'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" '
        . 'style="width:100%;max-width:560px;border-collapse:collapse;margin:0 auto;text-align:left;">'

        // Brand header — site name + Stats (brand colour), not the product name.
        . '<tr><td style="padding:0 0 18px;">'
        . '<div class="ds-ink" style="font-size:22px;font-weight:700;letter-spacing:-0.03em;line-height:1.2;color:' . $ink . ';">'
        . $esc($siteName) . '<span style="color:' . $esc($brand) . ';"> Stats</span></div>'
        . '<div class="ds-ink" style="margin-top:6px;font-size:18px;font-weight:600;letter-spacing:-0.02em;color:' . $ink . ';">'
        . $esc(t('digest.email.heading')) . '</div>'
        . '<div class="ds-muted" style="margin-top:6px;font-size:14px;color:' . $muted . ';">'
        . $esc(t('digest.email.lede')) . '</div>'
        . '</td></tr>'

        // Hero metrics card.
        . '<tr><td>'
        . '<table role="presentation" class="ds-card" width="100%" cellpadding="0" cellspacing="0" border="0" '
        . 'style="width:100%;border-collapse:separate;background:' . $cardBg . ';border:1px solid ' . $line
        . ';border-radius:12px;margin:0 0 14px;">'
        . '<tr><td style="padding:18px 20px;">'
        . '<div class="ds-muted" style="font-size:12px;letter-spacing:0.04em;text-transform:uppercase;color:' . $muted . ';">'
        . $esc($heroLabel) . '</div>'
        . '<div class="ds-ink" style="margin-top:4px;font-size:32px;font-weight:700;letter-spacing:-0.03em;line-height:1.15;color:' . $ink . ';">'
        . $esc($heroValue) . $changeHtml . '</div>'
        . ($subMetricsHtml !== ''
            ? '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" '
            . 'style="width:100%;border-collapse:collapse;margin-top:14px;border-top:1px solid ' . $line . ';" class="ds-rule">'
            . $subMetricsHtml . '</table>'
            : '')
        . '</td></tr></table>'
        . '</td></tr>'

        . '<tr><td>' . $section(t('digest.email.top_pages'), $rows($pages, 'path', 'views')) . '</td></tr>'
        . '<tr><td>' . $section(t('digest.email.top_referrers'), $rows($referrers, 'referrer', 'views')) . '</td></tr>'
        . '<tr><td>' . $section(t('digest.email.not_found'), $rows($notFound, 'path', 'count')) . '</td></tr>'

        . '<tr><td style="padding:8px 0 0;">'
        . '<a href="' . $esc($dashboardUrl) . '" style="display:inline-block;padding:12px 18px;'
        . 'background:' . $esc($brand) . ';color:#ffffff;font-size:15px;font-weight:600;'
        . 'text-decoration:none;border-radius:10px;letter-spacing:-0.01em;">'
        . $esc(t('digest.email.view_dashboard')) . '</a>'
        . '</td></tr>'

        . '<tr><td class="ds-muted" style="padding:20px 0 0;font-size:13px;line-height:1.45;color:' . $muted . ';">'
        . $esc(t('digest.email.footer', ['site' => $siteName . ' Stats'])) . '</td></tr>'

        . '</table></td></tr></table>'
        . '</body></html>';

    $textRows = static function (array $items, string $keyLabel, string $keyCount): string {
        if ($items === []) {
            return t('digest.email.empty') . "\n";
        }
        $text = '';
        foreach ($items as $row) {
            $label = (string) ($row[$keyLabel] ?? '');
            if ($label === 'direct') {
                $label = t('digest.email.direct');
            }
            $count = (int) ($row[$keyCount] ?? $row['views'] ?? $row['count'] ?? 0);
            $text .= '- ' . $label . ': ' . i18n_format_number($count) . "\n";
        }
        return $text;
    };
    $text = $siteName . " Stats\n"
        . t('digest.email.heading') . "\n"
        . t('digest.email.lede') . "\n\n"
        . $textMetrics
        . t('digest.email.top_pages') . "\n" . $textRows($pages, 'path', 'views') . "\n"
        . t('digest.email.top_referrers') . "\n" . $textRows($referrers, 'referrer', 'views') . "\n"
        . t('digest.email.not_found') . "\n" . $textRows($notFound, 'path', 'count') . "\n"
        . t('digest.email.view_dashboard') . ': ' . $dashboardUrl . "\n\n"
        . t('digest.email.footer', ['site' => $siteName . ' Stats']) . "\n";

    return ['subject' => $subject, 'html' => $html, 'text' => $text];
}

/** Human-readable status line for Settings. */
function doostats_digest_status_label(): string
{
    $state = doostats_digest_state();
    $sent = trim((string) ($state['last_attempt_at'] ?? ''));
    if ($sent === '') {
        return t('settings.reports.status.never');
    }
    try {
        $dt = new DateTimeImmutable($sent);
        $tz = analytics_timezone();
        $when = i18n_format_date($dt->setTimezone($tz), 'datetime', $tz);
    } catch (Exception $e) {
        $when = $sent;
    }
    if (!empty($state['last_ok'])) {
        return t('settings.reports.status.ok', ['when' => $when]);
    }
    $err = trim((string) ($state['last_error'] ?? ''));
    if ($err === '') {
        $err = t('settings.reports.error.mail');
    }
    return t('settings.reports.status.fail', ['when' => $when, 'error' => $err]);
}
